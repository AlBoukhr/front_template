import axios, { AxiosInstance, AxiosRequestConfig, AxiosResponse } from 'axios';

export abstract class Service<T> {
  protected axiosInstance: AxiosInstance;

  constructor(axiosInstance: AxiosInstance) {
    this.axiosInstance = axiosInstance;
  }

  protected abstract getResourceName(): string;
  protected abstract getMethodName(): string;
  protected abstract newMethodName(): string;
  protected abstract setMethodName(): string;
  protected abstract delMethodName(): string;

  async getAll(config?: AxiosRequestConfig): Promise<T[]> {
    const response: AxiosResponse<T[]> = await this.axiosInstance.get<T[]>(`/${this.getResourceName()}/${this.getMethodName()}`, config);
    return response.data;
  }

  async getAllByFilter(strfilter?: string,resourcename? :string, methodname? :string, config?: AxiosRequestConfig): Promise<T[]> {
    let url = `/${resourcename || this.getResourceName()}/${methodname ||this.getMethodName()}`;
    if (strfilter) {
      url += `?${strfilter}`;
    }
    const response: AxiosResponse<T[]> = await this.axiosInstance.get<T[]>(url, config);
    return response.data;
  }

  async getSpecificData(methodName: string, config?: AxiosRequestConfig): Promise<T[]> {
    const response: AxiosResponse<T[]> = await this.axiosInstance.get<T[]>(`/${this.getResourceName()}/${methodName}/`, config);
    return response.data;
  }

  async getById(id: number, config?: AxiosRequestConfig): Promise<T> {
    const response: AxiosResponse<T> = await this.axiosInstance.get<T>(`/${this.getResourceName()}/${this.getMethodName()}/${id}`, config);
    return response.data;
  }

  async getByFilter(filter: T, methodname? :string,config?: AxiosRequestConfig): Promise<T[]> {
    const response: AxiosResponse<T[]> = await this.axiosInstance.post<T[]>(`/${this.getResourceName()}/${methodname || this.getMethodName()}`, filter, config);
    return response.data;
  }

  async create(item: T, config?: AxiosRequestConfig): Promise<T> {
    const response: AxiosResponse<T> = await this.axiosInstance.post<T>(`/${this.getResourceName()}/${this.newMethodName()}`, item, config);
    return response.data;
  }

  async updateByItem( item: T, config?: AxiosRequestConfig): Promise<T> {
    const response: AxiosResponse<T> = await this.axiosInstance.put<T>(`/${this.getResourceName()}/${this.setMethodName()}`, item, config);
    return response.data;
  }

  async update(id: number, item: T, config?: AxiosRequestConfig): Promise<T> {
    const response: AxiosResponse<T> = await this.axiosInstance.put<T>(`/${this.getResourceName()}/${this.setMethodName()}/${id}`, item, config);
    return response.data;
  }


  async remove(idColumnName: string, idOrParams: number | { [key: string]: any }, config?: AxiosRequestConfig): Promise<boolean> {
    let queryString: string;

    if (typeof idOrParams === 'number') {
      queryString = `${idColumnName}=${idOrParams}`;
    } else if (typeof idOrParams === 'object') {
      queryString = new URLSearchParams(idOrParams).toString();
    } else {
      throw new Error('Le paramètre idOrParams doit être un nombre ou un objet.');
    }

    const response: AxiosResponse<boolean> = await this.axiosInstance.delete<boolean>(`/${this.getResourceName()}/${this.delMethodName()}?${queryString}`, config);
    return response.data;
  }
  // async remove(id: number, config?: AxiosRequestConfig): Promise<boolean> {
  //   const response: AxiosResponse<boolean> = await this.axiosInstance.delete<boolean>(`/${this.getResourceName()}/${this.delMethodName()}?id=${id}`, config);
  //   return response.data;
  // }

  // async remove(params: { [key: string]: any }, config?: AxiosRequestConfig): Promise<boolean> {
  //   const queryString = new URLSearchParams(params).toString();
  //   const response: AxiosResponse<boolean> = await this.axiosInstance.delete<boolean>(`/${this.getResourceName()}/${this.delMethodName()}?${queryString}`, config);
  //   return response.data;
  // }
}
