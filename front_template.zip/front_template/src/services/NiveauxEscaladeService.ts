import { Service } from './Service';
import { NiveauxEscalade } from '../models/NiveauxEscalade';

export class NiveauxEscaladeService extends Service<NiveauxEscalade> {
  getResourceName(): string {
    return "NiveauxEscalade";
  }

  getMethodName(): string {
    return "GetBiblioMail";
  }

  newMethodName(): string {
    return "NewBiblioMail";
  }

  setMethodName(): string {
    return "SetBiblioMail";
  }

  delMethodName(): string {
    return "DelBiblioMail";
  }
}
