import { Dsp } from '../models/Dsp';
import { Service } from './Service';

export class DspService extends Service<Dsp> {
  getResourceName(): string {
    return "Dsp";
  }

  getMethodName(): string {
    return "GetDspByOpe";
  }


  newMethodName(): string {
    return "NewDspOpe";
  }

  setMethodName(): string {
    return "SetDspOpe";
  }

  delMethodName(): string {
    return "DelDspOpe";
  }
}
