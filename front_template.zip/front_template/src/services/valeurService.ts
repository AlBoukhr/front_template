import { Service } from './Service'
import {  Valeur } from './../models/Valeur';
import { AxiosResponse } from 'axios';
 
export class  ValeurService extends Service<Valeur> {
  
  
  protected getResourceName(): string {
    throw new Error('Method not implemented.');
  }
  protected getMethodName(): string {
    throw new Error('Method not implemented.');
  }
  protected newMethodName(): string {
    throw new Error('Method not implemented.');
  }
  protected setMethodName(): string {
    throw new Error('Method not implemented.');
  }
  protected delMethodName(): string {
    throw new Error('Method not implemented.');
  }
  
  async getAll(): Promise<Valeur[]> {

    let url = '/Valeurs/GetValeurs';
     

      try {
        const response: AxiosResponse<Valeur[]> = await this.axiosInstance.get<Valeur[]>(url);
        return response.data;
      } catch (error) {
        console.error('Erreur lors de la récupération des listes des valeurs :', error);
        throw error; // Relancer l'erreur après journalisation
      }


     
  }

  

  async getOneList(P_LSTVAL_ID: string): Promise<Valeur[]> {

    let url = `/Valeurs/GetValeurs?P_LSTVAL_ID=${P_LSTVAL_ID}`;
     

    try {
      const response: AxiosResponse<Valeur[]> = await this.axiosInstance.get<Valeur[]>(url);
      return response.data;
    } catch (error) {
      console.error('Erreur lors de la récupération des listes des valeurs :', error);
      throw error; // Relancer l'erreur après journalisation
    }

    
  }
}

 