import axios, { AxiosError, AxiosResponse, InternalAxiosRequestConfig } from 'axios';

interface ExtendedAxiosRequestConfig<D = any> extends InternalAxiosRequestConfig<D> {
  logId?: number;
}

const axiosInstance = axios.create({
  baseURL: 'https://vabe1-apisir.adb.dev.euw1.nbyt.fr/bte/ApiSGA/api/', // Remplacez par votre configuration réelle
  // autres configurations comme les headers, les timeout, etc.
});

interface ServerCall {
  id: number;
  method: string;
  url: string;
  type: 'Request' | 'Request Error' | 'Response' | 'Response Error';
  timestamp: number;
  duration?: number; // Optionnel, seulement pour les réponses
  errorDetails?: string; // Détails de l'erreur
}

const serverCalls: ServerCall[] = [];

let callId = 0;

// Intercepteur de requête Axios
axiosInstance.interceptors.request.use(
  (request: ExtendedAxiosRequestConfig) => {
    const method = request.method ? request.method.toUpperCase() : 'UNKNOWN METHOD';
    const url = request.url || 'UNKNOWN URL';
    const log: ServerCall = {
      id: callId++,
      method,
      url,
      type: 'Request',
      timestamp: Date.now()
    };
    serverCalls.push(log);
    request.logId = log.id;
    return request;
  },
  (error: AxiosError) => {
    const method = error.config?.method ? error.config.method.toUpperCase() : 'UNKNOWN METHOD';
    const url = error.config?.url || 'UNKNOWN URL';
    const log: ServerCall = {
      id: callId++,
      method,
      url,
      type: 'Request Error',
      timestamp: Date.now(),
      errorDetails: error.message // Détails de l'erreur
    };
    serverCalls.push(log);
    return Promise.reject(error);
  }
);

// Intercepteur de réponse Axios
axiosInstance.interceptors.response.use(
  (response: AxiosResponse) => {
    const method = response.config.method ? response.config.method.toUpperCase() : 'UNKNOWN METHOD';
    const url = response.config.url || 'UNKNOWN URL';
    const timestamp = Date.now();
    const duration = timestamp - (serverCalls.find(log => log.id === (response.config as ExtendedAxiosRequestConfig).logId)?.timestamp ?? 0);
    const log: ServerCall = {
      id: callId++,
      method,
      url,
      type: 'Response',
      timestamp,
      duration
    };
    serverCalls.push(log);
    return response;
  },
  (error: AxiosError) => {
    const method = error.config?.method ? error.config.method.toUpperCase() : 'UNKNOWN METHOD';
    const url = error.config?.url || 'UNKNOWN URL';
    const timestamp = Date.now();
    const duration = timestamp - (serverCalls.find(log => log.id === (error.config as ExtendedAxiosRequestConfig).logId)?.timestamp ?? 0);
    const log: ServerCall = {
      id: callId++,
      method,
      url,
      type: 'Response Error',
      timestamp,
      duration,
      errorDetails: error.message // Détails de l'erreur
    };
    serverCalls.push(log);
    return Promise.reject(error);
  }
);

export { axiosInstance, serverCalls };
export type { ServerCall };
