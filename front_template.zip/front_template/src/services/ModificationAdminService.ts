import {  Service } from './Service';
import { ModificationAdmin } from '../models/ModificationAdmin';

export class ModificationAdminService extends Service<ModificationAdmin> {
  protected getMethodName(): string {
    throw new Error('Method not implemented.');
  }
  protected newMethodName(): string {
    throw new Error('Method not implemented.');
  }
  protected delMethodName(): string {
    throw new Error('Method not implemented.');
  }
  getResourceName(): string {
    return "ModificationAdmin";
  }

  setMethodName(): string {
    return "SetQosStatut";
  }
}
