import { Service } from './Service';
import { ContactOperateur } from '../models/ContactOperateur';
import { ListInd } from '../models/ListInd';

export class ListIndivService extends Service<ListInd> {
  protected newMethodName(): string {
    throw new Error('Method not implemented.');
  }
  protected delMethodName(): string {
    throw new Error('Method not implemented.');
  }
  getResourceName(): string {
    return "ContactsOperateurs";
  }

  getMethodName(): string {
    return "GetContactOPe";
  }


  // getMethodName(): string {
  //   return "GetListInd";
  // }

  setMethodName(): string {
    return "SetContactOpe";
  }
}
