import {  Service } from './Service';
import { Equipement } from '../models/Equipement';

export class EquipementService extends Service<Equipement> {
  protected newMethodName(): string {
    throw new Error('Method not implemented.');
  }
  protected setMethodName(): string {
    throw new Error('Method not implemented.');
  }
  protected delMethodName(): string {
    throw new Error('Method not implemented.');
  }
  getResourceName(): string {
    return "Equipement";
  }

  getMethodName(): string {
    return "GetEquipements";
  }
}
