import { Service } from './Service'; 
import { Facturation } from '../models/Facturation';

export class FacturationsService extends Service<Facturation> {
  getResourceName(): string {
    return "Facturations";
  }

  getMethodName(): string {
    return "GetFacturations";
  }

  newMethodName(): string {
    return "NewFacturation";
  }

  setMethodName(): string {
    return "SetFacturation";
  }

  delMethodName(): string {
    return "DelFacturation";
  }
}
