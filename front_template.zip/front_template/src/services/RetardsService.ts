import { Service } from './Service';
import { Retard } from '../models/Retard';

export class RetardsService extends Service<Retard> {
  getResourceName(): string {
    return "Retards";
  }

  getMethodName(): string {
    return "GetRetards";
  }

  newMethodName(): string {
    return "NewRetard";
  }

  setMethodName(): string {
    return "SetRetard";
  }

  delMethodName(): string {
    return "DelRetard";
  }
}
