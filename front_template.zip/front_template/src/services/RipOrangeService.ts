import {  Service } from './Service';
import { Rip } from '../models/Rip';

export class RipOrangeService extends  Service<Rip> {
  getResourceName(): string {
    return "Rip";
  }
 
  getMethodName(): string {
    return "GetRipOrange";
  }

  delMethodName(): string {
    return "DelRipOrange";
  }

  newMethodName(): string {
    return "NewRipOrange";
  }

  setMethodName(): string {
    return "SetRipOrange";
  }
}
