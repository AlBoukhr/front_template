// cacheService.js
const dataCache = {};

const cacheData = (key, data) => {
    dataCache[key] = data;
};

const getCachedData = (key) => {
    return dataCache[key];
};

export { cacheData, getCachedData };