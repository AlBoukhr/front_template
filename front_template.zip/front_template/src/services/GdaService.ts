import {  Service } from './Service';
import { Gda } from '../models/Gda';

export class GdaService extends Service<Gda> {
  protected setMethodName(): string {
    throw new Error('Method not implemented.');
  }
  getResourceName(): string {
    return "Gda";
  }

  getMethodName(): string {
    return "GetAagOffrTyplie";
  }

  newMethodName(): string {
    return "NewAffAutoGda";
  }

  delMethodName(): string {
    return "DelAffAutoGda";
  } 

  async getGDAAffecte(filter : Gda): Promise<Gda[] | null> {
    return await this.getByFilter(filter, "GetAffAutoGda");
  }

  
  async getGDANonAffecte(filter : Gda): Promise<Gda[]| null> {
    return await this.getByFilter(filter,"GetGdaNonAffecte");
  }

}
