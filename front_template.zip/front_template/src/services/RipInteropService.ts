import {  Service } from './Service';
import { RipInteropVersion } from '../models/RipInteropVersion';

export class RipInteropService extends Service<RipInteropVersion> {
  getResourceName(): string {
    return "Rip";
  }
 
  
  getMethodName(): string {
    return "GetRipInteropVersion";
  } 

  delMethodName(): string {
    return "DelRipInterop";
  }

  GetVersionsFluxMediation(): string {
    return "GetVersionsFluxMediation";
  }

  newMethodName(): string {
    return "NewRipInterop";
  }

  setMethodName(): string {
    return "SetRipInterop";
  }
}
