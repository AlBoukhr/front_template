import { Service } from './Service';
import { AdminParam } from '../models/AdminParam';

export class AutresParametresService extends Service<AdminParam> {
 
 
  protected newMethodName(): string {
    throw new Error('Method not implemented.');
  }
  protected delMethodName(): string {
    throw new Error('Method not implemented.');
  }
  getResourceName(): string {
    return "AutresParametres";
  }

  getMethodName(): string {
    return "GetAdminParam";
  }

  setMethodName(): string {
    return "SetAdminParam";
  }
}
