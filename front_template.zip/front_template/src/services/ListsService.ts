import { AxiosResponse } from 'axios';
import { Cause } from '../models/Cause';
import { OperateurImmeuble } from '../models/OperateurImmeuble';
import { Service } from './Service' 
 
export class  ListsOperateurImmeubleService extends Service<OperateurImmeuble> {
  protected getResourceName(): string {
    throw new Error('Method not implemented.');
  }
  protected getMethodName(): string {
    throw new Error('Method not implemented.');
  }
  protected newMethodName(): string {
    throw new Error('Method not implemented.');
  }
  protected setMethodName(): string {
    throw new Error('Method not implemented.');
  }
  protected delMethodName(): string {
    throw new Error('Method not implemented.');
  }
   

  async getOperateurImmeuble(): Promise<OperateurImmeuble[]> {
      
    let url = '/Facturations/GetModOprImb';
     

      try {
        const response: AxiosResponse<OperateurImmeuble[]> = await this.axiosInstance.get<OperateurImmeuble[]>(url);
        return response.data;
      } catch (error) {
        console.error('Erreur lors de la récupération des opérateurs immeubles:', error);
        throw error; // Relancer l'erreur après journalisation
      }
 
  }
 
  
}

export class  ListsCauseService extends Service<Cause> {
  protected getResourceName(): string {
    throw new Error('Method not implemented.');
  }
  protected getMethodName(): string {
    throw new Error('Method not implemented.');
  }
  protected newMethodName(): string {
    throw new Error('Method not implemented.');
  }
  protected setMethodName(): string {
    throw new Error('Method not implemented.');
  }
  protected delMethodName(): string {
    throw new Error('Method not implemented.');
  }
  
  async getCausesByType(type: string): Promise<Cause[]> {
    if (!type) {
      // Retourner une promesse résolue avec un tableau vide si le type est null ou vide
      return Promise.resolve([]);
    }


    let url = `/ComptesRendus/GetCauseByType?P_TYP_CSE=${type}`;
     
     

    try {
      const response: AxiosResponse<Cause[]> = await this.axiosInstance.get<Cause[]>(url);
      return response.data;
    } catch (error) {
      console.error('Erreur lors de la récupération des causes par type:', error);
      throw error; // Relancer l'erreur après journalisation
    }
  }
 
  
}