import { Service } from './Service';
import { CodeTransformation } from '../models/CodeTransformation';

export class CodesTransformationsService extends Service<CodeTransformation> {
  getResourceName(): string {
    return "CodesTransformations";
  }

  getMethodName(): string {
    return "GetCmtTransVg";
  }

  
  // getMethodName(): string {
  //   return "GetCmtTransVgByCriteria";
  // }


  newMethodName(): string {
    return "NewCmtTransVg";
  }

  setMethodName(): string {
    return "SetCmtTransVg";
  }

  delMethodName(): string {
    return "DelCmtTransVg";
  }
}
