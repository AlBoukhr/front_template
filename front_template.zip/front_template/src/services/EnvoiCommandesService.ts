import { Service } from './Service';
import { EnvoiCommande } from '../models/EnvoiCommande';

export class EnvoiCommandesService extends Service<EnvoiCommande> {
  getResourceName(): string {
    return "EnvoiCommandes";
  }

  getMethodName(): string {
    return "GetBiblioEnvoiMail";
  }

  newMethodName(): string {
    return "NewBiblioEnvoiMail";
  }

  setMethodName(): string {
    return "SetBiblioEnvoiMail";
  }

  delMethodName(): string {
    return "DelBiblioEnvoiMail";
  }
}
