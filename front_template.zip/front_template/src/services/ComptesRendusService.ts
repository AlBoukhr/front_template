 
import { CompteRendu } from '../models/CompteRendu';
import { Service } from './Service';

export class ComptesRendusService extends Service<CompteRendu> {
  getResourceName(): string {
    return "ComptesRendus";
  }

  getMethodName(): string {
    return "GetBiblioCr";
  }

  newMethodName(): string {
    return "NewBiblioCr";
  }

  setMethodName(): string {
    return "SetBiblioCr";
  }

  delMethodName(): string {
    return "DelBiblioCr";
  }
}
