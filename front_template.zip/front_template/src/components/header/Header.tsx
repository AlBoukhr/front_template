import React, { useEffect, useState } from 'react';
import Toolbar, { Item } from 'devextreme-react/toolbar';
import Button from 'devextreme-react/button';
import UserPanel from '../user-panel/UserPanel';
import './Header.scss';
import { Template } from 'devextreme-react/core/template';
import type { HeaderProps } from '../../types';
import { ServerCall, serverCalls } from '../../services/configaxios';
import ServerCallsPopup from '../monitoring/servercallspopup';

export default function Header({ menuToggleEnabled, title, toggleMenu }: HeaderProps) {

  const [isPopupVisible, setIsPopupVisible] = useState(false);
  const [serverLogs, setServerLogs] = useState<ServerCall[]>([]);

  // Utiliser useEffect pour mettre à jour serverLogs lorsque serverCalls change
  useEffect(() => {
    const interval = setInterval(() => setServerLogs([...serverCalls]), 1000); // Branchez sur serverCalls toutes les secondes
    return () => clearInterval(interval);
  }, []);

  const togglePopup = () => {
    setIsPopupVisible(!isPopupVisible);
  };

  const clearLogs = () => {
    serverCalls.length = 0; // Effacer les logs
    setServerLogs([]); // Mettre à jour l'état pour refléter les logs effacés
  };

 
 

  
  return (
    <header className={'header-component'}>
      <Toolbar className={'header-toolbar'}>
        <Item
          visible={menuToggleEnabled}
          location={'before'}
          widget={'dxButton'}
          cssClass={'menu-button'}
        >
          <Button icon="menu" stylingMode="text" onClick={toggleMenu} />
        </Item>
        <Item
          location={'before'}
          cssClass={'header-title'}
          text={title}
          visible={!!title}
        />
        <Item
          location={'after'}
          locateInMenu={'auto'}
          menuItemTemplate={'userPanelTemplate'}
        >
          <Button
            className={'user-button authorization'}
            width={210}
            height={'100%'}
            stylingMode={'text'}
          >
            <UserPanel menuMode={'context'} />
          </Button>

          </Item>
          <Item
          location={'after'}
          locateInMenu={'auto'}
          menuItemTemplate={'userPanelTemplate'}
        >
     <Button icon='isnotblank' onClick={togglePopup} />
      {isPopupVisible && (
        <ServerCallsPopup
          isVisible={isPopupVisible}
          onClose={togglePopup}
          serverCalls={serverLogs}
          clearLogs={clearLogs}
        />
      )}
     


  
        </Item>
        <Template name={'userPanelTemplate'}>
          <UserPanel menuMode={'list'} />
        </Template>
      </Toolbar>
    </header>
)}
