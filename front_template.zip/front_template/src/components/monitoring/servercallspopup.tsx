// ServerCallsPopup.tsx
import React from 'react';
import { Popup, List, Button } from 'devextreme-react';
import { ServerCall } from '../../services/configaxios';
 // Assurez-vous que le chemin est correct

interface ServerCallsPopupProps {
  isVisible: boolean;
  onClose: () => void;
  serverCalls: ServerCall[];
  clearLogs: () => void;
}

const getLogColor = (type: string) => {
  switch (type) {
    case 'Request':
      return 'orange';
    case 'Response':
      return 'green';
    case 'Request Error':
    case 'Response Error':
      return 'red';
    default:
      return 'black';
  }
};

const ServerCallsPopup: React.FC<ServerCallsPopupProps> = ({ isVisible, onClose, serverCalls, clearLogs }) => {
  return (
    <Popup
      visible={isVisible}
      onHiding={onClose}
      dragEnabled={true}
      resizeEnabled={true}
      showTitle={true}
      title="Appels au serveur"
      width={800}
      height={450}
      closeOnOutsideClick={true}
    >
      <div className="popup-content">
        <Button text="Clear Logs" onClick={clearLogs} />
        <List
          dataSource={serverCalls}
          height={400}
          width={780}
          itemRender={(item: ServerCall) => (
            <div style={{ color: getLogColor(item.type) }}>
              {item.type}: {item.method} {item.url} - {item.duration != null ? `${item.duration}ms` : 'En cours'} - {new Date(item.timestamp).toLocaleString()}
              {item.type.includes('Error') && (
                <>
                  <br />
                  <strong>Détails de l'erreur:</strong> {item.errorDetails}
                </>
              )}
            </div>
          )}
        />
      </div>
    </Popup>
  );
};

export default ServerCallsPopup;
