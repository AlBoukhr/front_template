import { Valeur } from "../models/Valeur";

 
export type  ColumnDefinition = {
    name: string;
    caption: string;
    editable?: boolean;
    required?: boolean;
    readOnly?: boolean;
    width?: number;
    visible :boolean;
    typeField?: 'text' | 'textarea' | 'checkbox' | 'lookup' | 'date'; // ou tout autre type personnalisé que vous avez défini
    options?: any[] | null ; 
    optionValueField?: string;
    optionLabelField?: string;
  }
  
  
  export type  ColumnEditorDefinition = {
    name: string;
    caption: string;
    typeEdit :'edit'|'required'| 'readOnly'; 
    typeField?: 'text' | 'textarea' | 'checkbox' | 'lookup' | 'date'; // ou tout autre type personnalisé que vous avez défini
    options?: Valeur[] | null ; // Optionnel si la colonne est de type 'select'
    optionValueField : string;
    optionLabelField: string;
    isRequired : boolean;
  }


  export type  FilterFieldDefinition = {
    dataField: string;
    caption: string; 
    dataType: 'text' | 'checkedit' | 'date' | 'lookup'; // ou tout autre type personnalisé que vous avez défini
    options?: any[] | null | ((filter: any) => Promise<any[]>); // Permet des options statiques ou une fonction
    optionValueField? : string;
    optionLabelField?: string;
   
  }
  

  
   
  
  
