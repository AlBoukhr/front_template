import React, { useState, useEffect } from 'react';
import { CheckBox, DateBox, SelectBox, TextBox } from 'devextreme-react';
import { FilterFieldDefinition } from '../../components/interfaces';
import { Valeur } from '../../models/Valeur';

interface SegaFilterProps<T extends GenericFilter> {
  FilterFields: FilterFieldDefinition[];
  onFilterChange: (newFilter: T) => Promise<void>;
  Filter: T;
  columnCount: number;
}

interface GenericFilter {
  [key: string]: any;
}

function SegaFilter<T extends GenericFilter>({ FilterFields, onFilterChange, Filter, columnCount }: SegaFilterProps<T>) {
  const [localFilter, setLocalFilter] = useState<T>(Filter);
  const [dynamicOptions, setDynamicOptions] = useState<{ [key: string]: Valeur[] | null }>({});


  useEffect(() => {
    onFilterChange(localFilter);
  }, [localFilter]);

  
  const handleInputChange = async (dataField: string, value: any) => {
    const updatedFilter = { ...localFilter, [dataField]: value };
    setLocalFilter(updatedFilter);

    // Si le champ entré a des dépendances dynamiques, mettez à jour ses options dynamiques
    FilterFields.forEach(async field => {
      if (typeof field.options === 'function') {
        const options = await field.options(updatedFilter);
        setDynamicOptions(prevOptions => ({
          ...prevOptions,
          [field.dataField]: options
        }));
      }
    });
  };


  const renderItem = (ed: FilterFieldDefinition) => {
    switch (ed.dataType) {
      case "date":
        return (
          <div className="filter-item" key={ed.dataField}>
            <DateBox
              value={localFilter[ed.dataField]}
              onValueChanged={(e) => handleInputChange(ed.dataField, e.value)}
              label={ed.caption}
              type="date"
            />
          </div>
        );
      case "text":
        return (
          <div className="filter-item" key={ed.dataField}>
            <TextBox
              value={localFilter[ed.dataField]}
              onValueChanged={(e) => handleInputChange(ed.dataField, e.value)}
              label={ed.caption}
            />
          </div>
        );
      case "checkedit":
        return (
          <div className="filter-item" key={ed.dataField}>
            <CheckBox
              value={localFilter[ed.dataField]}
              onValueChanged={(e) => handleInputChange(ed.dataField, e.value)}
              text={ed.caption}
              defaultValue={true}
            />
          </div>
        );
        case "lookup":
            const options = typeof ed.options === 'function' ? dynamicOptions[ed.dataField] : ed.options;
            return (
              <div className="filter-item" key={ed.dataField}>
                <SelectBox
                  label={ed.caption}
                  dataSource={options || []}
                  value={localFilter[ed.dataField]}
                  valueExpr={ed.optionValueField}
                  displayExpr={ed.optionLabelField}
                  onValueChanged={(e) => handleInputChange(ed.dataField, e.value)}
                />
              </div>
            );
      default:
        return null;
    }
  };

  return (
    <div className="filter-container" style={{ display: 'grid', gridTemplateColumns: `repeat(${columnCount}, 1fr)`, gap: '16px' }}>
      {FilterFields.map((ed: FilterFieldDefinition) => renderItem(ed))}
    </div>
  );
}

export default SegaFilter;
