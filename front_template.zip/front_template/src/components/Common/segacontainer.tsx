import React, { useEffect, useState, useCallback } from "react"; 
import { ColumnDefinition, FilterFieldDefinition } from "./../interfaces"; // Vos interfaces
import SegaDataGrid from "../segadevextreme/datagrid";
import SegaFilter from "./segafilter";

export interface SegaContainerProps<T, F extends GenericFilter> {
  getAll: (filter: F) => Promise<T[]>;
  createItemInstance: () => T;
  renderDetailPage: (item: T | null, onSave: (item: T) => Promise<void>, onDelete: (id: number) => Promise<void>, onCancel: () => void) => React.ReactNode;
  columns: ColumnDefinition[];
  filterFields?: FilterFieldDefinition[];
  pageSize?: number;
  idField: keyof T;
}

interface GenericFilter {
  [key: string]: any;
}

export function SegaContainer<T extends { [key: string]: any }, F extends GenericFilter>(props: SegaContainerProps<T, F>) {
  const { getAll, createItemInstance, renderDetailPage, columns, filterFields, pageSize = 10, idField } = props;

  const [dataSource, setDataSource] = useState<T[] | null>(null);
  const [selectedItem, setSelectedItem] = useState<T | null>(null);
  const [filter, setFilter] = useState<F | null>(null);
  const [pageIndex, setPageIndex] = useState<number | undefined>();
  const [rowIndex, setRowIndex] = useState<number | undefined>();
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const refreshList = useCallback(async (activeFilter: F) => {
    setIsLoading(true);
    try {
      const data = await getAll(activeFilter);
      setDataSource(data);
    } catch (error) {
      console.error('Erreur lors du chargement des données', error);
    } finally {
      setIsLoading(false);
    }
  }, [getAll]);

  useEffect(() => {
    if (filter) {
      refreshList(filter);
    }
  }, [refreshList, filter]);

  useEffect(() => {
    if (dataSource && dataSource.length > 0) {
      setSelectedItem(dataSource[0]);
    } else {
      setSelectedItem(createItemInstance());
    }
  }, [dataSource, createItemInstance]);

  const handleAdd = () => {
    const newItem = createItemInstance();
    setDataSource(prev => [...(prev || []), newItem]);
    const newSelectedIndex = dataSource ? (dataSource.length - 1) : 0;
    setSelectedItem(newItem);
    setPageIndex(Math.floor(newSelectedIndex / pageSize));
    setRowIndex(newSelectedIndex);
  };

  const handleDelete = async (id: number) => {
    // Suppression de l'élément ici (appel API)
    await refreshList(filter as F);
  };

  const handleSave = async (data: T) => {
    // Création ou mise à jour de l'élément ici (appel API)
    await refreshList(filter as F);
  };

  return (
    <React.Fragment>
      {filterFields && (
        // eslint-disable-next-line react/jsx-no-undef
        <SegaFilter
          columnCount={4}
          Filter={filter as F}
          onFilterChange={(newFilter: F) => {
            setFilter(newFilter);
            return Promise.resolve();
          }}
          FilterFields={filterFields}
        />
      )}
      <div className="content-block dx-card responsive-paddings">
        <SegaDataGrid
          idName={idField as string}
          type={createItemInstance}
          dataSource={dataSource}
          ColumnDefinition={columns}
          onAdd={handleAdd}
          canEdit={true}
          canAdd={true}
          onRowClick={async (id: number) => {
            const selected = dataSource?.find(item => item[idField] === id);
            setSelectedItem(selected || null);
          }}
          pageIndex={pageIndex}
          rowIndex={rowIndex}
        />
      </div>
      <div className="content-block dx-card responsive-paddings">
        {renderDetailPage(selectedItem, handleSave, handleDelete, () => {
          setSelectedItem(null);
          refreshList(filter as F);
        })}
        {isLoading && <div>Loading...</div>}
      </div>
    </React.Fragment>
  );
}
