import React from "react";
import { Button, TextArea, TextBox } from "devextreme-react";

export interface SegaDetailProps<T> {
  item: T;
  onSave: (item: T) => Promise<void>;
  onDelete: (id: number) => Promise<void>;
  onCancel: () => void;
  renderFields: (item: T, handleChange: (field: keyof T, value: any) => void) => React.ReactNode;
}

export class SegaDetail<T extends { id: number | undefined }> extends React.Component<SegaDetailProps<T>> {
  handleChange = (field: keyof T, value: any) => {
    this.props.item[field] = value;
    this.forceUpdate(); // Pour forcer le re-render après changement de valeur
  };

  render() {
    const { item, onSave, onDelete, onCancel, renderFields } = this.props;

    if (!item) {
      return <div>Sélectionnez un élément pour voir les détails</div>;
    }

    return (
      <React.Fragment>
        <div className="settings">
          {renderFields(item, this.handleChange)}
        </div>
        <div className="button-row">
          <Button onClick={() => onDelete(item.id || -1)} icon="trash" hint="Supprimer" />
          <Button onClick={() => onSave(item)} icon="save" hint="Enregistrer" />
          <Button onClick={onCancel} icon="clear" hint="Annuler" />
        </div>
      </React.Fragment>
    );
  }
}
