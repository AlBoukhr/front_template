import React, { createRef } from 'react';
import DataGrid, {
  Column, Paging, ColumnChooser, FilterRow, SearchPanel, Toolbar, Button, Grouping, Scrolling, RequiredRule, ToolbarItem
} from 'devextreme-react/data-grid';
import { CheckBox, SelectBox, SpeedDialAction } from 'devextreme-react';
import { ColumnDefinition } from '../interfaces';
import dxDataGrid from 'devextreme/ui/data_grid';

interface DataGridProps<T> {
  type: () => T;
  dataSource: T[] | null;
  idName: string;
  ColumnDefinition: ColumnDefinition[];
  canEdit: boolean;
  canAdd: boolean;
  onRowClick: (id: number) => Promise<void>;
  onAdd?: () => void;
  pageIndex?: number;
  rowIndex?: number;
}

interface DataGridState {
  lastAddedRowKey: number | string | null;
}

class SegaDataGrid<T> extends React.Component<DataGridProps<T>, DataGridState> {
  dataGridRef: React.RefObject<any>;

  constructor(props: DataGridProps<T>) {
    super(props);
    this.dataGridRef = createRef();
    this.state = {
      lastAddedRowKey: null
    };
  }

  // componentDidUpdate(prevProps: DataGridProps<T>) {
  //   const { pageIndex, rowIndex } = this.props;

  //   if (pageIndex !== undefined && pageIndex !== prevProps.pageIndex && this.dataGridRef.current) {
  //     this.dataGridRef.current.instance.pageIndex(pageIndex);
  //   }

  //   if (rowIndex !== undefined && rowIndex !== prevProps.rowIndex && this.dataGridRef.current) {
  //     this.dataGridRef.current.instance.option('focusedRowIndex', rowIndex);
  //   }

  //   if (this.state.lastAddedRowKey !== null) {
  //     const instance = this.dataGridRef.current.instance;
  //     if (typeof instance.pageIndex === 'function' && typeof instance.pageCount === 'function') {
  //       instance.pageIndex(instance.pageCount() - 1).then(() => {
  //         instance.option('focusedRowKey', this.state.lastAddedRowKey);
  //         if (typeof instance.navigateToRow === 'function') {
  //           instance.navigateToRow(this.state.lastAddedRowKey);
  //         }
  //       });
  //     }
  //   }
  // }

  onContextMenuPreparing = (e: any) => {
    if (e.row.rowType === 'data' && this.dataGridRef.current) {
      const instance = this.dataGridRef.current.instance;

      e.items = [
        {
          text: 'Ajouter',
          onItemClick: this.props.onAdd,
        },
        {
          text: 'Supprimer',
          onItemClick: () => instance.deleteRow(e.row.rowIndex),
        },
      ];
    }
  };

  renderCell = (col: ColumnDefinition, record: T) => {
    switch (col.typeField) {
      case 'checkbox':
        return (
          <CheckBox
            value={(record as any)[col.name]}
            onValueChanged={(e) => {
              (record as any)[col.name] = e.value ? 1 : 0;
            }}
          />
        );
      case 'lookup':
        return (
          <SelectBox
            dataSource={col.options}
            value={(record as any)[col.name]}
            valueExpr={col.optionValueField}
            displayExpr={col.optionLabelField}
          />
        );
      default:
        return (record as any)[col.name];
    }
  };

  onInitNewRow = async (e: any) => {
    if (this.props.onAdd) {
      await this.props.onAdd();

      // const newRowKey = this.props.dataSource
      //   ? (this.props.dataSource[this.props.dataSource.length - 1] as any)[this.props.idName]
      //   : null;

      // this.setState({ lastAddedRowKey: newRowKey });

      // if (this.dataGridRef.current && typeof this.dataGridRef.current.navigateToRow === 'function') {
      //   this.dataGridRef.current.navigateToRow(newRowKey);
      // }


      
    //   setTimeout(() => {
    //     if (this.dataGridRef.current) {
    //       const instance = this.dataGridRef.current.instance;
    //       if (typeof instance.pageIndex === 'function' && typeof instance.pageCount === 'function') {
    //         instance.pageIndex(instance.pageCount() - 1).then(() => {
    //           instance.option('focusedRowKey', newRowKey);
    //           if (typeof instance.navigateToRow === 'function') {
    //             instance.navigateToRow(newRowKey);
    //           }
    //         });
    //       }
    //     }
    //   }, 100);
    }
  };

  render() {
    const { dataSource, idName, ColumnDefinition, onRowClick, canAdd, onAdd, pageIndex, rowIndex } = this.props;

    return (
      <div>
        <DataGrid
          ref={this.dataGridRef}
          dataSource={dataSource}
          keyExpr={idName}
          showBorders={true}
          allowColumnReordering={true}
          highlightChanges={true}
          autoNavigateToFocusedRow={true}
          focusedRowEnabled={true}
          columnAutoWidth={true}
          onContextMenuPreparing={this.onContextMenuPreparing}
          onRowClick={async (e) => await onRowClick(e.key)}
          onInitNewRow={this.onInitNewRow}
          paging={{ pageIndex: pageIndex ?? undefined, pageSize: 10 }}
           focusedRowIndex={rowIndex ?? undefined}
        >
          {ColumnDefinition.map((col) => (
            <Column
              key={col.name}
              dataField={col.name}
              caption={col.caption}
              visible={col.visible}
              width={col.width ? col.width : 200}
              allowEditing={col.editable || col.required}
              cellRender={(cellData) => this.renderCell(col, cellData.data)}
            >
              {col.required && <RequiredRule />}
            </Column>
          ))}

          <ColumnChooser enabled={true} />
          <FilterRow visible={true} />
          <SearchPanel visible={true} />
          <Grouping autoExpandAll={true} />

          <Toolbar visible={true}>
            <ToolbarItem>
              <Button text="Ajouter" icon="add" onClick={onAdd} />
            </ToolbarItem>
            {/* <ToolbarItem name="exportButton" />
            <ToolbarItem name="columnChooserButton" />
            <ToolbarItem name="searchPanel" /> */}
          </Toolbar>

          <Paging defaultPageSize={10} enabled={true} />
          <Scrolling useNative={true} />
        </DataGrid>
        {canAdd && <SpeedDialAction icon="add" label="Ajouter" index={1} onClick={this.onInitNewRow} />}
      </div>
    );
  }
}

export default SegaDataGrid;
