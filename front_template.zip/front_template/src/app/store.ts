// store.ts
import { configureStore, ThunkAction, Action } from '@reduxjs/toolkit';
import { persistStore, persistReducer, FLUSH, REHYDRATE, PAUSE, PERSIST, PURGE, REGISTER } from 'redux-persist';
import storage from 'redux-persist/lib/storage';
import { applyMiddleware, combineReducers } from 'redux';
import dashboardReducer from '../features/dashboardSlice';
import kanbanReducer from '../features/kanbanSlice';
import commandesReducer from '../features/commandesSlice';
import logger from 'redux-logger';
import {composeWithDevTools} from 'redux-devtools-extension';

import { createAsyncThunk } from '@reduxjs/toolkit'; 

const persistConfig = {
  key: 'root',
  storage,
  whitelist: ['commandes','dashboard', 'kanban'] // Specify which reducers you want to persist
};

const rootReducer = combineReducers({
    commandes: commandesReducer,
  dashboard: dashboardReducer,
  kanban: kanbanReducer
});

const persistedReducer = persistReducer(persistConfig, rootReducer);

export const store = configureStore({
  reducer: persistedReducer,  
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware( {serializableCheck: false} ).concat(logger),
    devTools: process.env.NODE_ENV !== 'production',
    
});

export const persistor = persistStore(store);

export type AppDispatch = typeof store.dispatch;
export type RootState = ReturnType<typeof store.getState>;
export type AppThunk<ReturnType = void> = ThunkAction<
  ReturnType,
  RootState,
  unknown,
  Action<string>
>;
 