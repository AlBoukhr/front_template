const appInfo = {
    title: 'SEGA'
};
export default appInfo;

