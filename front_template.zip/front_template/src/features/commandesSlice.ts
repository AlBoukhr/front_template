// commandesSlice.ts
import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { Commande } from '../pages/dashboard/api';
import { useDispatch } from 'react-redux';
 

interface CommandesState {
  data: Commande[];
  selectedRows: Commande[];
  loading: boolean;
}

const initialState: CommandesState = {
  data: [],
  selectedRows: [],
  loading: true,
};



const commandesSlice = createSlice({
  name: 'commandes',
  initialState,
  reducers: {
    setData: (state, action: PayloadAction<Commande[]>) => {
      state.data = action.payload;
    },
    setSelectedRows: (state, action: PayloadAction<Commande[]>) => {
      state.selectedRows = action.payload;
    },
    setLoading: (state, action: PayloadAction<boolean>) => {
      state.loading = action.payload;
    },
    removeSelectedRow: (state, action: PayloadAction<number>) => {
      state.selectedRows = state.selectedRows.filter(
        commande => commande.commandeId !== action.payload
      );
    } ,addRow: (state, action: PayloadAction<Commande>) => { 
 
      state.data.push(action.payload); 
    }
  }
});

export const { setData, setSelectedRows, setLoading, removeSelectedRow ,addRow} = commandesSlice.actions;

export default commandesSlice.reducer;
