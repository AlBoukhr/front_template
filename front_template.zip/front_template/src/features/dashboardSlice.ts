// dashboardSlice.ts
import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { Commande } from '../pages/dashboard/api';

interface DashboardState {
  data: Commande[];
  selectedRows: Commande[];
  loading: boolean;
}

const initialState: DashboardState = {
  data: [],
  selectedRows: [],
  loading: true,
};

const dashboardSlice = createSlice({
  name: 'dashboard',
  initialState,
  reducers: {
    setData: (state, action: PayloadAction<Commande[]>) => {
      state.data = action.payload;
    },
    setSelectedRows: (state, action: PayloadAction<Commande[]>) => {
      state.selectedRows = action.payload;
    },
    setLoading: (state, action: PayloadAction<boolean>) => {
      state.loading = action.payload;
    },
    removeSelectedRow: (state, action: PayloadAction<number>) => {
      state.selectedRows = state.selectedRows.filter(
        commande => commande.commandeId !== action.payload
      );
    }
  }
});

export const { setData, setSelectedRows, setLoading, removeSelectedRow } = dashboardSlice.actions;

export default dashboardSlice.reducer;
