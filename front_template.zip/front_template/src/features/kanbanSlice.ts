// kanbanSlice.ts
import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { Commande } from '../pages/dashboard/api';

interface KanbanState {
  state: Commande[];
}

const initialState: KanbanState = {
  state: [],
};

const kanbanSlice = createSlice({
  name: 'kanban',
  initialState,
  reducers: {
    setKanbanState: (state, action: PayloadAction<Commande[]>) => {
      state.state = action.payload;
    }
  }
});

export const { setKanbanState } = kanbanSlice.actions;

export default kanbanSlice.reducer;
