import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { AppDispatch, RootState } from '../../app/store';
import { fetchData, Commande } from './api';
import { DataGrid, Column, Pager, Paging, Selection, SearchPanel, GroupPanel } from 'devextreme-react/data-grid';
import { Chart, Series, Legend, Tooltip, Color } from 'devextreme-react/chart';
import { PieChart, Series as PieSeries, Label } from 'devextreme-react/pie-chart';
import Kanban from './kanban';
import { ModalProvider } from './modalcontext';
import { SpeedDialAction } from 'devextreme-react/speed-dial-action';
import { setData, setSelectedRows, setLoading } from '../../features/dashboardSlice';
import { setKanbanState } from '../../features/kanbanSlice';
import { DataCard } from './datacard';
 

const Dashboard: React.FC = () => {
  const dispatch = useDispatch<AppDispatch>();
  const   dashboardState = useSelector((state: RootState) => state.dashboard);
  const kanbanState = useSelector((state: RootState) => state.kanban.state);
  const navigate = useNavigate();

  const calculateKPIs = (data: Commande[]) => {
    return {
      totalOrders: data.length,
      totalRejected: data.filter(item => item.statutCommande === 'REJETEE').length,
      totalInProgress: data.filter(item => item.statutCommande === 'EN_COURS').length,
      totalAlert: data.filter(item => item.statutCommande === 'ALERTE').length,
    };
  };

  const loadData = async () => {
    try {
      const result = await fetchData();
      dispatch(setData(result));
    } catch (error) {
      console.error(error);
    } finally {
      dispatch(setLoading(false));
    }
  };

  useEffect(() => {
    loadData();
  }, [dispatch]);

  const refreshData = async () => {
    dispatch(setLoading(true));
    await loadData();
    dispatch(setSelectedRows([]));
    dispatch(setKanbanState([]));
  };

  const onSelectionChanged = (e: any) => {
    dispatch(setSelectedRows(e.selectedRowsData));
  };

  const addSelectedToKanban = () => {
    const updatedKanbanState = kanbanState.concat(dashboardState.selectedRows)
      .reduce((acc: Commande[], current: Commande) => {
        if (!acc.find((item : Commande) => item.commandeId === current.commandeId)) {
          acc.push(current);
        }
        return acc;
      }, []);
    dispatch(setKanbanState(updatedKanbanState));
  };

  const clearKanban = () => {
    dispatch(setKanbanState([]));
  };

  const openDetailsView = () => {
    const updatedSelectedRows = [...dashboardState.selectedRows];
    dispatch(setSelectedRows(updatedSelectedRows));

    navigate('/commande');
  };

  if (dashboardState.loading) {
    return <div>Chargement...</div>;
  }

  const kpis = calculateKPIs(dashboardState.data);

  const orderStatuses = dashboardState.data.reduce((acc: any, item: Commande) => {
    acc[item.statutCommande] = acc[item.statutCommande] ? acc[item.statutCommande] + 1 : 1;
    return acc;
  }, {});

  const ordersByDate = dashboardState.data.reduce((acc: any, item: Commande) => {
    const date = new Date(item.dateCommande).toLocaleDateString();
    acc[date] = acc[date] ? acc[date] + 1 : 1;
    return acc;
  }, {});

  return (
    <React.Fragment>
      <ModalProvider>
        <h2 className={'content-block'}>Commandes</h2>
        <div className={'content-block dx-card responsive-paddings'}>
        <div style={{ display: 'flex', justifyContent: 'space-around', marginBottom: '20px' }}>
         <DataCard title='Commandes' value={kpis.totalOrders} tone='info' icon='folder' type='info' percentage={-20}></DataCard>
         <DataCard title='Rejetées' value={kpis.totalRejected}  tone='info'  percentage={30} icon='taskrejected'></DataCard>
         <DataCard title='En Cours' value={kpis.totalInProgress}  tone='info'  percentage={10} icon='checklist'></DataCard>
         <DataCard title='Alertes' value={kpis.totalAlert}  tone='warning' percentage={0}  icon='warning'></DataCard>
          
          </div>
        </div>

        <div className={'content-block dx-card responsive-paddings'}>
          <div style={{ display: 'flex', justifyContent: 'space-around', marginBottom: '20px' }}>
            <PieChart    type="doughnut" dataSource={Object.entries(orderStatuses).map(([key, value]) => ({ status: key, count: value }))}>
              <PieSeries valueField="count" argumentField="status">
                <Label visible={true} connector={{ visible: true }} />
              </PieSeries>
              <Legend verticalAlignment="bottom" horizontalAlignment="center" />
              <Tooltip enabled={true} />
            </PieChart>

            
            <Chart dataSource={Object.entries(ordersByDate).map(([date, count]) => ({ date, count }))}>
              <Series type="bar" valueField="count" argumentField="date">
                <Tooltip enabled={true} />
              </Series>
              <Legend verticalAlignment="bottom" horizontalAlignment="center" />
            </Chart>
          </div>
        </div>

        <div className={'content-block dx-card responsive-paddings'}>
             
       
               
                <DataGrid
                  dataSource={dashboardState.data}
                  keyExpr="commandeId"
                  showBorders={true}
                  onSelectionChanged={onSelectionChanged}  
                >
                  <Selection mode="multiple" />
                  <SearchPanel visible={true}></SearchPanel>
                 <GroupPanel visible={true}></GroupPanel>
                  <Paging defaultPageSize={10} /> 
                  <Pager showPageSizeSelector={true} allowedPageSizes={[5, 10, 20]} showInfo={true} />
                  <Column dataField="commandeId" caption="commandeId" visible={false}/>
                  <Column dataField="msisdn" caption="MSISDN" />
                  <Column dataField="nomCommande" caption="Nom Commande" />
                  <Column dataField="dateCommande" caption="Date Commande" dataType="date" format="dd/MM/yyyy HH:mm:ss" />
                  <Column dataField="statutCommande" caption="Statut Commande" />
                  <Column dataField="offre" caption="Offre" />
                  <Column dataField="typeCommande" caption="Type Commande" />
                </DataGrid>
                
                </div>
           
                <div className={'content-block dx-card responsive-paddings'}>
                <Kanban   selectedOrders={dashboardState.selectedRows} />
              
              
              
          </div>
        
       
          <SpeedDialAction
            icon="activefolder"
            label="Ajouter au Kanban"
            index={1}
          
            onClick={addSelectedToKanban}
          />
          <SpeedDialAction
            icon="clear"
            label="Vider le Kanban"
            index={2}
            onClick={clearKanban}
          />
          <SpeedDialAction
            icon="detailslayout"
            label="Afficher les Détails"
            index={3}
          
            onClick={openDetailsView}
          />
          <SpeedDialAction
            icon="refresh"
            label="Rafraîchir"
            index={4}
            onClick={refreshData}
          />
       
      </ModalProvider>
    </React.Fragment>
  );
};

export default Dashboard;

