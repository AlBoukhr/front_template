import React, { useCallback, useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import ScrollView from 'devextreme-react/scroll-view';
import Sortable from 'devextreme-react/sortable';
import { Commande } from "./api";
import './kanban.css';
import Card from './card';
import { RootState, AppDispatch } from '../../app/store';
import { setKanbanState } from '../../features/kanbanSlice'; 
import { Button } from 'devextreme-react';
import { ClickEvent } from 'devextreme/ui/button';

type KanbanProps = { 
  selectedOrders: Commande[]
}

type ReorderEvent = {
  fromIndex: number;
  toIndex: number;
}

type TaskDropEvent = {
  fromData: number;
  toData: number;
  fromIndex: number;
  toIndex: number;
}

const statutCommandes = ['INITIALISEE', 'EN_COURS', 'REALISEE', 'REJETEE'];

const getLists = (statusArray: string[], taskArray: Commande[]) => {
  const tasksMap = taskArray.reduce((result: { [x: string]: any[] }, task) => {
    if (result[task.statutCommande]) {
      result[task.statutCommande].push(task);
    } else {
      result[task.statutCommande] = [task];
    }
    return result;
  }, {});
  return statusArray.map((status) => tasksMap[status] || []);
}

const uniqueByID = (arr: any[]) => {
    return arr.reduce((acc, obj) => {
      if (!acc.some((item: { [x: string]: any; }) => item['commandeId'] === obj['commandeId'])) {
        acc.push(obj);
      }
      return acc;
    }, []);
  }
  
   
  

const List: React.FC<{ title: any, index: any, tasks: any, onTaskDrop: any, deleteTask: (taskId: number) => void }> = ({
  title, index, tasks, onTaskDrop, deleteTask
}) => {

   

    return (
  <div className="list">
    <div className="list-title">{title}</div>
    <ScrollView className="scrollable-list" direction="vertical" showScrollbar="always">
      <Sortable
        className="sortable-cards"
        group="cardsGroup"
        data={index}
        onReorder={onTaskDrop}
        onAdd={onTaskDrop}
      >
        {tasks.map((task: Commande) => (
          <Card key={task.commandeId} task={task} onDelete={async () => deleteTask(task.commandeId)} />
        ))}
      </Sortable>
    </ScrollView>
  </div>
);

}



const Kanban: React.FC<KanbanProps> = ({  selectedOrders }) => {
  const dispatch = useDispatch<AppDispatch>();
  const kanbanState = useSelector((state: RootState) => state.kanban.state);
  const [lists, setLists] = useState(getLists(statutCommandes, uniqueByID(kanbanState.concat(selectedOrders)).length ? uniqueByID(kanbanState.concat(selectedOrders)) : selectedOrders));

//   useEffect(() => {
//     dispatch(setKanbanState(lists.flat()));
//   }, [lists, dispatch]);

  const onListReorder = useCallback(({ fromIndex, toIndex }: ReorderEvent) => {
    setLists((state) => reorderItem(state, fromIndex, toIndex));
  }, []);

  const onTaskDrop = useCallback(({
    fromData, toData, fromIndex, toIndex,
  }: TaskDropEvent) => {
    const updatedLists = [...lists];
    const item = { ...updatedLists[fromData][fromIndex] }; // Create a copy of the item

    // Update the task status
    item.statutCommande = statutCommandes[toData];

    updatedLists[fromData] = removeItem(updatedLists[fromData], fromIndex);
    updatedLists[toData] = insertItem([...updatedLists[toData]], item, toIndex);

    setLists(updatedLists);
  }, [lists]);

  useEffect(() => {
    setLists(getLists(statutCommandes, uniqueByID(kanbanState.concat(selectedOrders)).length ? uniqueByID(kanbanState.concat(selectedOrders)) : selectedOrders));
  }, [kanbanState, selectedOrders]);

  const deleteTask = useCallback(
    (taskId: number) => {
      setLists((lists) =>
        lists.map((tasks) => tasks.filter((task: Commande) => task.commandeId !== taskId))
      );
    },
    []
  );

  return (
    <div id="kanban"> 
      <ScrollView className="scrollable-board" direction="horizontal" showScrollbar="always">
        <Sortable className="sortable-lists" itemOrientation="horizontal" handle=".list-title" onReorder={onListReorder}>
          {lists.map((tasks, listIndex) => {
            const status = statutCommandes[listIndex];
            return (
              <List
                key={status}
                title={status}
                index={listIndex}
                tasks={tasks}
                onTaskDrop={onTaskDrop}
                deleteTask={deleteTask}
              />
            );
          })}
        </Sortable>
      </ScrollView>
    </div>
  );
};

export default Kanban;

const removeItem = (array: any[], removeIdx: number) => {
  return array.filter((_, idx) => idx !== removeIdx);
}

const insertItem = (array: any[], item: any, insertIdx: number) => {
  const newArray = [...array];
  newArray.splice(insertIdx, 0, item);
  return newArray;
}

const reorderItem = (array: any[], fromIdx: number, toIdx: number) => {
  const item = array[fromIdx];
  const result = removeItem(array, fromIdx);
  return insertItem(result, item, toIdx);
}


