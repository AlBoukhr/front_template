// Card.tsx
import React from 'react';
 import './datacard.scss';

 export const DataCard = ({ title, icon, tone, value, percentage , type }: {
  title: string, icon: string, tone?: 'warning' | 'info', value: number, percentage: number , type?:string
}) => (
  <div className={`ticker ${type ?? ''}`}>
    <div className={`icon-wrapper ${tone || (percentage > 0 ? 'positive' : 'negative')}`}>
      <i className={`dx-icon dx-icon-${icon} `} />
    </div>
    <div className='middle'>
      <div className='title'>
        { title }
      </div>
      <div className='total'>
        {value}
      </div>
    </div>
    <div className={`percentage ${percentage > 0 ? 'positive' : 'negative'}`}>
      <div className={`dx-icon-${percentage > 0 ? 'spinup' : 'spindown'}`} />
      <div className='value'>{`${Math.abs(percentage)}%`}</div>
    </div>
  </div>
);


