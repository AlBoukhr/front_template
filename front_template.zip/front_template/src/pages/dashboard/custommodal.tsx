// CustomModal.tsx
import React from 'react';
import ReactDOM from 'react-dom';
import './modal.css';  // Fichier CSS pour le style du modal
import { Button } from 'devextreme-react';

interface CustomModalProps {
  isOpen: boolean;
  onClose: () => void;
  children: React.ReactNode;
}

const CustomModal: React.FC<CustomModalProps> = ({ isOpen, onClose, children }) => {
  if (!isOpen) {
    return null;
  }

  return ReactDOM.createPortal(
    <div className="modal-overlay">
      <div className="modal-content">
        <Button className="modal-close-button" icon='close' onClick={onClose}></Button>
        {children}
      </div>
    </div>,
    document.body
  );
};

export default CustomModal;
