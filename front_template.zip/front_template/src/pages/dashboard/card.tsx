// Card.tsx
import React, { useState } from 'react';
import { Commande } from "./api";
import { Button } from 'devextreme-react/button';
import CustomModal from './custommodal';  // Assurez-vous d'importer le composant CustomModal
import CommandeDetailPage from '../commande/commande';
 

const Card: React.FC<{ task: Commande, onDelete : (id:number)=> {} }> = ({ task ,onDelete}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const openModal = () => setIsModalOpen(true);
  const closeModal = () => setIsModalOpen(false);

  return (
    <div className="card dx-card">
      <div className="card-subject">Commande: {task.nomCommande}</div>
      <div className="card-assignee">Statut: {task.statutCommande}</div> 
      <Button
         icon='detailslayout' hint='Afficher les Détails'
        onClick={openModal}
        className="details-button"
      />
       <Button 
       icon='trash' hint='Supprimer du Kanban'
        onClick={()=> onDelete(task.commandeId)}
        className="details-button"
      />
      <CustomModal isOpen={isModalOpen} onClose={closeModal}>
        <CommandeDetailPage
        isAdding={false}
        isEditing={false}
          Commande={task}
          onSave={async data => { /* Implémentez la logique d'enregistrement ici */ }}
          onDel={async id => { /* Implémentez la logique de suppression ici */ }}
          onCancel={closeModal}
        />
      </CustomModal>
    </div>
  );
};

export default Card;
