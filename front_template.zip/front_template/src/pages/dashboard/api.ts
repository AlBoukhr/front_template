export interface Commande {
    commandeId: number;
    correlationId: string;
    msisdn: string;
    nomCommande: string;
    dateCommande: string;
    statutCommande: string;
    offre: string;
    typeCommande: string;
  }
  
  export const fetchData = async () => {
    const response = await fetch('https://vabe1-apisir.adb.dev.euw1.nbyt.fr/bte/ws-usi-sgafrontal-in/api/1/WebApi', {
      method: 'POST',
      headers: {
        'Accept': '*/*',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        "st": "FAR",
        "endPointName": "getcmdsftth",
        "dataBase": "DEV08",
        "headers": { "test": "test" },
        "parameters": { "cmsstu": "" },
        "body": {}
      })
    });
  
    if (!response.ok) {
      throw new Error('Failed to fetch data');
    }
  
    const result = await response.json();
  
    // Map over the results to create Commande objects with commandeId
    const commandes = result.results.map((commande: any, index: number) => ({
      commandeId: index,
      correlationId: commande.correlationId,
      msisdn: commande.msisdn,
      nomCommande: commande.nomCommande,
      dateCommande: commande.dateCommande,
      statutCommande: commande.statutCommande,
      offre: commande.offre,
      typeCommande: commande.typeCommande
    })) as Commande[];
  
    return commandes;
  };
  