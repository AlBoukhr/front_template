import React, { useEffect, useState } from 'react'; 
import { useDispatch, useSelector } from 'react-redux';
import { AppDispatch, RootState } from '../../app/store'; 
import { DataGrid, Column, Pager, Paging, Selection, SearchPanel, GroupPanel } from 'devextreme-react/data-grid'; 
import { Button } from 'devextreme-react';
import { Commande } from '../dashboard/api';
 
 

interface CommandeListProps { 
    onSet: (data: Commande[]) => Promise<void>; 
    onClose: () => void;
   
  }
const CommandesListPage: React.FC<CommandeListProps> = ({  onSet, onClose  })  => {
  const dispatch = useDispatch<AppDispatch>();
  const   commandesState = useSelector((state: RootState) => state.commandes); 
  const [Commandes, setCommandes] = useState<Commande[]>(commandesState.selectedRows);

  const onSelectionChanged = (e: any) => {
    const selectedRows = e.selectedRowsData;
    if (selectedRows && !commandesState.selectedRows.some((row: Commande) => row.commandeId === selectedRows[0].commandeId)) {
      setCommandes([...commandesState.selectedRows, ...selectedRows]);
    }
  };

   function onCancel() {
    setCommandes( commandesState.selectedRows );
   }
 
  return (
    <React.Fragment>
      
               
                <DataGrid
                  dataSource={commandesState.data}
                  keyExpr="commandeId"
                  showBorders={true}
                  onSelectionChanged={onSelectionChanged}    
                >
                  <Selection mode="multiple" />
                  <SearchPanel visible={true}></SearchPanel>
                 <GroupPanel visible={true}></GroupPanel>
                  <Paging defaultPageSize={10} /> 
                  <Pager showPageSizeSelector={true} allowedPageSizes={[5, 10, 20]} showInfo={true} />
                  <Column dataField="commandeId" caption="commandeId" visible={false}/>
                  <Column dataField="msisdn" caption="MSISDN" />
                  <Column dataField="nomCommande" caption="Nom Commande" />
                  <Column dataField="dateCommande" caption="Date Commande" dataType="date" format="dd/MM/yyyy HH:mm:ss" />
                  <Column dataField="statutCommande" caption="Statut Commande" />
                  <Column dataField="offre" caption="Offre" />
                  <Column dataField="typeCommande" caption="Type Commande" />
                </DataGrid>
                
                <div className="button-row">
                  <Button onClick={()=>onSet(Commandes)} icon="exportselected" hint="Appliquer"/>
                <Button onClick={onCancel} icon="arrowback" hint="Annuler"/>
                <Button onClick={onClose} icon="clear" hint="Fermer"/>
            </div>
           
                
                 
    </React.Fragment>
  );
};

export default CommandesListPage;

