// CommandeDetailsPage.tsx

import React, { useCallback, useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { RootState, AppDispatch } from '../../app/store';
import { removeSelectedRow, addRow, setSelectedRows, setData, setLoading } from '../../features/commandesSlice';
 

import Sortable, { SortableTypes } from 'devextreme-react/sortable';
import TabPanel, { TabPanelTypes } from 'devextreme-react/tab-panel';
import { Button, SpeedDialAction } from 'devextreme-react';
 
import { Commande, fetchData } from '../dashboard/api';
import CustomModal from '../dashboard/custommodal';
import CommandesList from './commandesList';
import CommandeDetailPage from './commande';
import { ModalProvider } from '../dashboard/modalcontext';


const CommandeDetailsPage: React.FC = () => {
  const dispatch = useDispatch<AppDispatch>();
  const commandesState = useSelector((state: RootState) => state.commandes);
  const [openedCommandes, setopenedCommandes] = useState<Commande[]>([]); 
  const [Commandes, setCommandes] = useState(commandesState.data);
  const [selectedItem, setSelectedItem] = useState<Commande | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isAdding, setIsAdding] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [selektedRowKeys, setSelektedRowKeys] = useState<number[]>([]);
 
 
  //#region hooks

  useEffect(() => {
      if (openedCommandes != null && openedCommandes.length > 0) {
          setSelectedItem(openedCommandes[0]);
      }
  }, [openedCommandes]);

  useEffect(() => {
      if (commandesState.selectedRows != null && commandesState.selectedRows.length > 0) {
          setopenedCommandes(commandesState.selectedRows);
      }
  }, [commandesState.selectedRows]);

  //#endregion

  //#region liste de toutes commandes

  const loadData = async () => {
      try {
        const result = await fetchData();
        dispatch(setData(result));
      } catch (error) {
        console.error(error);
      } finally {
        dispatch(setLoading(false));
      }
    };

  useEffect(() => {
      loadData();
  }, [dispatch]);

  const refreshData = async () => {
      dispatch(setLoading(true));
      await loadData();
      dispatch(setSelectedRows([])); 
    };

  //#endregion

  //#region fonctions locales

  
  function closeAllTabs() { 
    dispatch(setSelectedRows([]));  
    setopenedCommandes([]); 
  }
  
  function createCR() {

    const  newitem : Commande  = {
        commandeId: Commandes.length + 1,
        correlationId:"",
        msisdn:"",
        nomCommande:"",
        dateCommande:"",
        statutCommande:"",
        offre:"",
        typeCommande:"", 
    } 
  
    setopenedCommandes([...openedCommandes, newitem]);
    setSelectedItem(openedCommandes[openedCommandes.length +1]);
    dispatch(addRow(newitem));
    dispatch(setSelectedRows([...(openedCommandes || []), newitem]));
  }

  function createProject() {
    const newItem: Commande = {
        commandeId: commandesState.data.length + 1,
        correlationId: "",
        msisdn: "",
        nomCommande: "Nouvelle Commande " + (commandesState.data.length + 1),
        dateCommande: "",
        statutCommande: "",
        offre: "",
        typeCommande: "",
      };
  
      dispatch(addRow(newItem));
      dispatch(setSelectedRows([...openedCommandes, newItem]));
    //   setopenedCommandes([...openedCommandes, newItem]);
      setSelectedItem(openedCommandes[openedCommandes.length - 1]);
  }

  

  function createNotif() {
    return Commandes.length === commandesState.data.length;
  }
 
  function disableButton() {
    // return (openedCommandes ?? []).length === commandesState.data.length;
  }

  const closeTab = (id: number) => {
    dispatch(removeSelectedRow(id));
  }; 

  const closeButtonHandler = useCallback((item: Commande) => {
    dispatch(removeSelectedRow(item.commandeId));
  }, []);

  const onSelectionChanged = useCallback((args: TabPanelTypes.SelectionChangedEvent) => {
    setSelectedItem(args.addedItems[0]);
  }, [setSelectedItem]);

  const onTabDragStart = useCallback((e: SortableTypes.DragStartEvent) => {
    e.itemData = e.fromData[e.fromIndex];
  }, []);

  const onTabDrop = useCallback((e: SortableTypes.ReorderEvent) => {
    const newCommandes = [...Commandes];

    newCommandes.splice(e.fromIndex, 1);
    newCommandes.splice(e.toIndex, 0, e.itemData);

    setCommandes(newCommandes);
  }, [Commandes, setCommandes]);

  const openModal = () => setIsModalOpen(true);
  const closeModal = () => setIsModalOpen(false);

  //#endregion

  //#region fonctions pour les autres composants

  async function onSet(data: Commande[]): Promise<void> {
    dispatch(setSelectedRows([...(openedCommandes || []), ...data]));
    setopenedCommandes([...(openedCommandes || []), ...data]);
  }

  //#endregion

  const renderTitle = useCallback((data: Commande) => (
    <React.Fragment>
        <span>
          {data.msisdn} : {data.nomCommande}
        </span>
        {openedCommandes.length > 0 && <i className="dx-icon dx-icon-close" onClick={() => { closeButtonHandler(data); }} />}
    </React.Fragment>
  ), [openedCommandes, closeButtonHandler]);

  return (
    <React.Fragment> 
      <ModalProvider>
        <Sortable
          filter=".dx-tab"
          data={openedCommandes}
          itemOrientation="horizontal"
          dragDirection="horizontal"
          onDragStart={onTabDragStart}
          onReorder={onTabDrop} 
        >
          <TabPanel
            dataSource={openedCommandes}
            height={410}
            itemTitleRender={renderTitle}
            deferRendering={false}
            showNavButtons={true}
            selectedItem={selectedItem}
            repaintChangesOnly={true}
            onSelectionChanged={onSelectionChanged}
            itemComponent={() => (
              <CommandeDetailPage
                Commande={selectedItem}
                isAdding={isAdding}
                isEditing={isEditing}
                onSave={async data => { /* Implement save logic here */ }}
                onDel={async id => { /* Implement delete logic here */ }}
                onCancel={() => selectedItem && closeButtonHandler(selectedItem)}
              />
            )}
          />
        </Sortable>  
        <CustomModal isOpen={isModalOpen} onClose={closeModal}>
          <CommandesList onSet={onSet} onClose={closeModal} ></CommandesList>
        </CustomModal>
        <SpeedDialAction
          icon="plus"
          label="Créer Projet"
          index={1}
          onClick={createProject}
        />
        <SpeedDialAction
          icon="remove"
          label="Fermer les détails"
          index={2}
          onClick={closeAllTabs}
        />
        <SpeedDialAction
          icon="detailslayout"
          label="Afficher un Détail"
          index={3}
          onClick={openModal}
        />
        <SpeedDialAction
          icon="file"
          label="Créer un CR"
          index={4}
          onClick={createCR}
        />
        <SpeedDialAction
          icon="email"
          label="Escalader"
          index={5}
          onClick={createNotif}
        />
        
      </ModalProvider>
    </React.Fragment>
  );
}

export default CommandeDetailsPage;
