import React, { useCallback, useEffect, useMemo, useState } from "react";
import SegaDataGrid from "../../../components/segadevextreme/datagrid";
 
import { Valeur } from "../../../models/Valeur";
import { ColumnDefinition, FilterFieldDefinition } from "../../../components/interfaces";
import SegaFilter from "../../../components/Common/segafilter";
 
import { ValeurService } from "../../../services/valeurService";
import { axiosInstance } from '../../../services/configaxios';
import { Commande } from "../../dashboard/api";
import { useSelector } from "react-redux";
import { RootState } from "../../../app/store";

function CommandesPage() {
  const valeurService = useMemo(() => new ValeurService(axiosInstance), []); 
  const   commandesState = useSelector((state: RootState) => state.commandes); 
   
  const [listeCommandes, setListeCommandes] = useState<Commande[] | null>(commandesState.data);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const [filter, setFilter] = useState<Commande>(filtreCommandeInstance());
  const [ofrcom, setOfrcomListe] = useState<Valeur[] | null>(null);
  const [stusga, setStusgaListe] = useState<Valeur[] | null>(null);

  // const rafraichirListeCommandes = useCallback(async (currentFilter: Commande) => {
  //   try {
  //     setIsLoading(true);
  //     const result = await commandeService.getByFilter(currentFilter);
  //     setListeCommandes(result);
  //   } catch (error) {
  //     console.error('Erreur lors du chargement des données', error);
  //   } finally {
  //     setIsLoading(false);
  //   }
  // }, [commandeService]);

  useEffect(() => {
    (async () => {
      try {
        setOfrcomListe(await valeurService.getOneList("OFREQP"));
        setStusgaListe(await valeurService.getOneList("STUSGA"));
        setStusgaListe(await valeurService.getOneList("SGACMD"));
      } catch (error) {
        console.error("Erreur lors du chargement des listes", error);
      }
    })();
  }, [valeurService]);

  // useEffect(() => {
  //   rafraichirListeCommandes(filter);
  // }, [rafraichirListeCommandes, filter]);

  const handleFilterChange = async (newFilter: Commande) => {
    setFilter(newFilter);
  };

  
  function createCommandeInstance() {
    return { 
      commandeId: -1,
    correlationId: "",
    msisdn: "",
    nomCommande: "",
    dateCommande: "",
    statutCommande: "",
    offre: "",
    typeCommande: "",
    } as Commande;
  }

  function filtreCommandeInstance() {
    return { 
      commandeId: -1,
    correlationId: "",
    msisdn: "",
    nomCommande: "",
    dateCommande: "",
    statutCommande: "",
    offre: "",
    typeCommande: "",
    } as Commande;
  }

  const fieldConfig: FilterFieldDefinition[] = [
    { dataField: 'msisdn', caption: 'MSISDN', dataType: 'text' },
    { dataField: 'offre', caption: 'Offre Commerciale', dataType: 'lookup', optionValueField: 'codval', optionLabelField: 'libval', options: ofrcom },
    { dataField: 'nomCommande', caption: 'Nom Commande', dataType: 'text' },
    { dataField: 'statutCommande', caption: 'Statut', dataType: 'lookup', optionValueField: 'codval', optionLabelField: 'libval', options: stusga },
    { dataField: 'typeCommande', caption: 'Statut', dataType: 'lookup', optionValueField: 'codval', optionLabelField: 'libval', options: stusga },
  ];

  const columnsDef: ColumnDefinition[] = [
    { visible: true, caption: 'Offre Commerciale', name: 'offre', required: true, typeField: 'text' },
    { visible: true, caption: 'Statut Commande', name: 'statutCommande', editable: true, typeField: 'text' },
    { visible: true, caption: 'MSISDN', name: 'msisdn', required: true, typeField: 'text' },
    { visible: true, caption: 'Commande', name: 'nomCommande', editable: true, typeField: 'text' },
    { visible: true, caption: 'Correlation ID', name: 'correlationId', editable: true, typeField: 'text' },
    { visible: true, caption: 'Date de Cimmande', name: 'dateCommande', editable: true, typeField: 'text' },
      ];

  const handleRowClick = async (id: number): Promise<void> => {
    console.info('commande actuel ', id);
  };

  return (
    <React.Fragment>
      {/* <h2 className={'content-block'}>Commandes</h2> */}
      <div className={'content-block dx-card responsive-paddings'}>
        <SegaFilter Filter={filter} columnCount={3} onFilterChange={handleFilterChange} FilterFields={fieldConfig} />
      </div>
      <div className={'content-block dx-card responsive-paddings'}>
        <SegaDataGrid
          idName="commandeId"
          type={createCommandeInstance}
          dataSource={listeCommandes}
          ColumnDefinition={columnsDef}
          canEdit={false} canAdd={false}
          onRowClick={handleRowClick}
        />
        {isLoading && <div>Loading...</div>}
      </div>
    </React.Fragment>
  );
}

export default CommandesPage;
