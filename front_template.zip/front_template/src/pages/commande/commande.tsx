import React, { useCallback, useEffect, useMemo, useState } from 'react';
import 'devextreme-react/text-area';
import { Button, CheckBox, SelectBox, TextArea, TextBox } from 'devextreme-react';
import { Commande } from '../dashboard/api';
import { Valeur } from '../../models/Valeur'; 
import { ValeurService } from '../../services/valeurService';
import { axiosInstance } from '../../services/configaxios';
import { cacheData, getCachedData } from '../../services/cacheservice';

interface CommandeDetailPageProps {
  Commande: Commande | null;
  isAdding : boolean ;
  isEditing : boolean;
  onSave: (data: Commande) => Promise<void>; 
  onDel: (id: number) => Promise<void>;
  onCancel: () => void;
}

const CommandeDetailPage: React.FC<CommandeDetailPageProps> = ({ Commande,isAdding,  onSave, onDel, onCancel }) => {
  const valeurService = useMemo(() => new ValeurService(axiosInstance), []); 

  const [state, setState] = useState<Commande>(Commande || {
    commandeId:-1,
    correlationId:"",
    msisdn:"",
    nomCommande:"",
    dateCommande:"",
    statutCommande:"",
    offre:"",
    typeCommande:"",
  });

  const [isLoading, setIsLoading] = useState(false); 
  const [selectData, setSelectData] = useState<{ [key: string]: Valeur[] | null }>({
    stusga: null, 
    ofrcom: null,
    cmdfth: null,
   
  });

   

  useEffect(() => {
    if (Commande) {
      setState(Commande);
      
      // Mettre à jour les filtres lorsque l'instance sélectionnée change
    }
  }, [Commande]);

  const handleChange = useCallback(async (field: keyof Commande, value: any) => {
    setState(prevState => ({ ...prevState, [field]: value }));

    
  }, []);

   

  const chargerListes = useCallback(async () => {
    try {
      const newSelectData = { ...selectData };

      for (const key in newSelectData) {
        const cachedData = getCachedData(key);
        if (cachedData) {
          newSelectData[key] = cachedData;
        } else {
          newSelectData[key] = await valeurService.getOneList(key.toUpperCase());
          cacheData(key, newSelectData[key]);
        }
      }

      setSelectData(newSelectData);
    } catch (erreur) {
      console.error('Erreur lors du chargement de la liste', erreur);
    } finally {
      setIsLoading(false);
    }
  }, [selectData, valeurService]);

  useEffect(() => {
    chargerListes();
  }, [chargerListes]);
 
 
  if (isLoading || !state) {
    return <div>Chargement en cours...</div>;
  }

  return (
    <React.Fragment>
       <div className={'content-block dx-card responsive-paddings'}>
      <div className="settings">
        <div className="column">
          <div className="field">
            <div className="value">
              <SelectBox
                dataSource={selectData.ofrcom}
                value={state.offre}
                valueExpr="libval"
                displayExpr="libval"
                onValueChanged={e => handleChange('offre', e.value)}
                
                className={'required-field'} 
                label="Offre Commerciale"
              />
            </div>
          </div>
          <div className="field">
            <div className="value">
              <SelectBox
                dataSource={selectData.stusga}
                value={state.statutCommande}
                valueExpr="libval"
                displayExpr="libval"
                onValueChanged={e => handleChange('statutCommande', e.value)}
                className={'required-field'} 
                label="Statut Commande"
              />
            </div>
          </div>
        </div>
        <div className="column">
          <div className="field">
            <div className="value">
            <TextBox 
           readOnly={!isAdding}
            value={state.msisdn || ""}
            onValueChanged={e => handleChange('msisdn', e.value)}
            label="MSISDN"
          />
            </div>
          </div>
          <div className="field">
            <div className="value"> 
          <TextBox 
             readOnly={!isAdding}
            value={state.nomCommande || ""}
            onValueChanged={e => handleChange('nomCommande', e.value)}
            label="Nom Commande"
          />
            </div>
            </div>
        </div>
        <div className="column">
          <div className="field">
            <div className="value">
              <SelectBox
                dataSource={selectData.cmdfth}
                value={state.typeCommande}
                valueExpr="libval"
                displayExpr="libval"
                onValueChanged={e => handleChange('typeCommande', e.value)}
                readOnly={true}
                label="Type Commande"
              />
            </div>
          </div>

          {isAdding && (
          <div className="field">
            <div className="label">Colibri</div>
            <div className="value">
              <CheckBox
                value={state.correlationId != null}
                text=""
                onValueChanged={e => handleChange('correlationId', e.value)}
                readOnly={true}
                
              />
            </div>
          </div> )}
        </div>
        <div className="column">
        {isAdding && (
          <div className="field">
            <div className="value">
            <TextBox 
             readOnly={true}
            value={state.correlationId}
            onValueChanged={e => handleChange('correlationId', e.value)}
            label="Correlation ID"
          />
            </div>
          </div>
)}
         
        </div>
        
      </div>
   
     
      <div className="button-row"> 
        <Button onClick={() => onDel(state.commandeId || -1)} icon="trash" hint="Supprimer" />
        <Button onClick={() => onSave(state)} icon="save" hint="Enregistrer" />
        <Button onClick={onCancel} icon="clear" hint="Annuler" />
      </div>
      </div>
    </React.Fragment>
  );
};

export default CommandeDetailPage;
