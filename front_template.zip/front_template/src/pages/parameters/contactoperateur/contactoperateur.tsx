 
 
 
import { ContactsOperateursService } from "../../../services/ContactsOperateursService"; 
import { axiosInstance } from '../../../services/configaxios'; // Assurez-vous du bon chemin d'importation

  
import { ContactOperateur } from '../../../models/ContactOperateur'  
  
import React, { useCallback, useEffect, useMemo, useState } from "react"; 
import SegaDataGrid from "../../../components/segadevextreme/datagrid";
import { ColumnDefinition } from "../../../components/interfaces"; 
import ContactOperateurDetailPage from "./contactoperateurDetail";

function ContactOperateurPage() {
    
  const [listeContactOperateurs, setlisteContactOperateurs] = React.useState<ContactOperateur[] | null>(null)
  const  contactsOperateursService  = useMemo(() => new ContactsOperateursService(axiosInstance), []);
  const [isLoading, setIsLoading] = React.useState<boolean>(false)
   
  const [selectedContactOperateur, setSelectedContactOperateur] = React.useState<ContactOperateur | null>(null);
  const [pageIndex, setPageIndex] = useState<number | undefined>();
  const [rowIndex, setRowIndex] = useState<number | undefined>();
  
  useEffect(() => {
  
    
    rafraichirListeContactOperateurs(); // Appel de la fonction au montage du composant
    setSelectedContactOperateur(createContactOperateurInstance());
  }, []); // Le tableau vide [] indique que l'effet ne dépend d'aucune variable et ne s'exécutera qu'une fois

   
  useEffect(() => {
    if (listeContactOperateurs && listeContactOperateurs.length > 0) {
      setSelectedContactOperateur(listeContactOperateurs[0]);
    }
  }, [listeContactOperateurs]);

  function createContactOperateurInstance() {
    return {
    coP_ID: -1,
    cmD_ORD_COD: "",
    cmD_ORD_LBL: "",
    enT_ID: -1,
    coP_FULLNAME: "",
    coP_PRENOM: "",
    coP_NOM: "",
    coP_NUMTEL: "",
  } as unknown as ContactOperateur;
} 

  const columnsDef : ColumnDefinition[]= [
    { visible :true , caption: 'Ordre', name: 'cmD_ORD_LBL', required: true, typeField:'text'},
    { visible :true, caption: 'Contact Opérateur', name: 'coP_FULLNAME', editable: true, typeField:'text' },
    { visible :true ,caption: 'Tél', name: 'coP_NUMTEL', required: true , typeField:'text'},  
  ];
 
 
  const rafraichirListeContactOperateurs = useCallback(async () => {
    try {
      setIsLoading(true) 
      setlisteContactOperateurs(await contactsOperateursService.getAll())

      if (listeContactOperateurs && listeContactOperateurs.length > 0) {
        setSelectedContactOperateur(listeContactOperateurs[0]);
      }
    } catch (e) {
      console.error('Erreur lors du chargement des données', e)
     
    } finally {
      setIsLoading(false)
    }
  }, [contactsOperateursService, listeContactOperateurs]);

 
  

  const handleclick = async (id: number) => {
    const compteRendu = listeContactOperateurs?.find(cr => cr.coP_ID === id);
    if (compteRendu) {
      setSelectedContactOperateur(compteRendu);
      console.info('contact operateur actuel ', compteRendu.coP_ID);
    }
  };

  const handleSave = async (data:  ContactOperateur) => {
    try {
      if (data.coP_ID === -1 || data.coP_ID === undefined) {
        await contactsOperateursService.create(data);
        // showInfo({ message: "Compte-rendu créé avec succès" ,state:'message'});
      } else {
        await contactsOperateursService.updateByItem(data);
        console.info("update avec ent_id " + data.enT_ID );
      }
      setSelectedContactOperateur(null);  // Réinitialise le compte rendu sélectionné
      rafraichirListeContactOperateurs();
    } catch (erreur) {
      console.error("Erreur lors de la sauvegarde du compte-rendu", erreur);
    }
  };

    
function handelCancel(): void {
  setPageIndex(undefined);
  setRowIndex(undefined);
  rafraichirListeContactOperateurs();
}


  return (
    <React.Fragment>
    {/* <h2 className={'content-block'}>Contacts Opérateurs</h2> */}

    <div className={'content-block dx-card responsive-paddings'}>
    
    <SegaDataGrid 
    idName="coP_ID"
     type={createContactOperateurInstance} 
     dataSource={listeContactOperateurs}
      ColumnDefinition={columnsDef} 
       onRowClick={id => handleclick(id)}
           canEdit={true} 
            canAdd={false}
            pageIndex={pageIndex}
            rowIndex={rowIndex}
   />
    </div>

    <div className={'content-block dx-card responsive-paddings'}>
    {selectedContactOperateur && (
          <ContactOperateurDetailPage
            contactOperateur={selectedContactOperateur}
            onSave={handleSave}
            onCancel={handelCancel}
          />
        )}
         {isLoading && <div>Loading...</div>}
    </div>
    </React.Fragment>
    
 
  )
} 

export default ContactOperateurPage;
