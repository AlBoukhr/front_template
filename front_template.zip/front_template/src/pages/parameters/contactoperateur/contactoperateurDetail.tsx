import React, { useEffect, useMemo, useState } from "react";
import 'devextreme-react/text-area';
import {  Button, SelectBox,   TextBox } from "devextreme-react";
import {  ListIndivService  } from "../../../services/ListIndivService";
import { ContactOperateur } from "../../../models/ContactOperateur";
import { Valeur } from "../../../models/Valeur"; 
import { axiosInstance } from '../../../services/configaxios'; // Assurez-vous du bon chemin d'importation
import { ListInd } from "../../../models/ListInd";

interface ContactOperateurDetailPageProps {
  contactOperateur: ContactOperateur | null;
  onSave: (data: ContactOperateur) => Promise<void>;
  onCancel: () => void;
}
function createFilter(ent_id? :number) {
  return {
    
      "enT_ID": ent_id ?? 0, 
      "codfon": "OVG",
      "soC_ID": "",
      "noment": "",
      "fullname": "",
      "fullvoi": "",
      "numvoient": "",
      "cmpvoient": "",
      "typvoient": "",
      "nomvoient": "",
      "nomvoi": "",
      "cmpadr": "",
      "codptlent": "",
      "coD_INSEE": "",
      "bopent": "",
      "cedent": "",
      "entpaR_ID": 0,
      "civprs": "",
      "pnmprs": "",
      "emaprs": "",
      "nomcmn": "",
      "nomsocapp": "",
      "nomusrmdf": "",
      "datmdf": "",
      "nomenT_SEARCH": "",
      "pnmprS_SEARCH": "",
      "nomsocapsearch": "",
      "nomcmN_SEARCH": "",
      "paycod": "",
      "voI_ID": 0,
      "natind": ""
     
} as unknown as ListInd ;
} 


const ContactOperateurDetailPage: React.FC<ContactOperateurDetailPageProps> = ({ contactOperateur, onSave, onCancel }) => {
  const listIndivService = useMemo(() => new ListIndivService(axiosInstance), []);
  
  const [state, setState] = useState<ContactOperateur | null>(contactOperateur);

  const [listIndiv, setListIndiv] = useState< ListInd[] | null >( );
  
  
  // Mettre à jour l'état local lorsque les props changent
  useEffect(() => {
    setState(contactOperateur);
    
   
    const chargerListes = async () => {
      try {
        const result = await listIndivService.getByFilter(createFilter(contactOperateur?.enT_ID ?? 0), 'GetListInd');
        setListIndiv(result || []);
      } catch (erreur) {
        console.error('Erreur lors du chargement de la liste', erreur);
      }
    };
    chargerListes();
  }, [listIndivService,  contactOperateur]);

  const handleChange = async (field: keyof ContactOperateur, value: any) => {
    setState(prevState => prevState ? ({ ...prevState, [field]: value }) : null);

   
  };

  const isFieldRequired = (field: keyof ContactOperateur): boolean => {
    switch (field) {
      case 'enT_ID':
      
        return true;
      default:
        return false;
    }
  };

  if (!state) {
    return <div>Sélectionnez un compte-rendu pour voir les détails</div>;
  }

  return (
    <React.Fragment>
      <div className="settings">
        <div className="column">
          <div className="field">
            <div className="value">
            <TextBox
          className={'disabled-field'}
          value={state.cmD_ORD_LBL || ""}
          onValueChanged={e => handleChange('cmD_ORD_LBL', e.value)}
          label="Offre Commerciale"
        />
            </div>
          </div>
          <div className="field">
            <div className="value">
              <SelectBox
                dataSource={listIndiv}
                value={state.enT_ID}
                valueExpr="enT_ID"
                displayExpr="fullname"
                text="Operateur"
              
                onValueChanged={e => handleChange('enT_ID', e.value)}
                className={isFieldRequired('enT_ID') ? 'required-field' : ''}
                label="Opérateur"
              />
            </div>
          </div>
        </div> 
      
      </div>
 
      <div className="button-row">
                  <Button onClick={() => onSave(state)} icon="save" hint="Enregistrer"/>
                <Button onClick={onCancel} icon="clear" hint="Annuler"/>
            </div>
    </React.Fragment>
  );
};

export default ContactOperateurDetailPage;
