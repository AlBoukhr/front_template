import React, { useCallback, useEffect, useMemo, useState } from "react";
import SegaDataGrid from "../../../components/segadevextreme/datagrid";
import { Equipement } from '../../../models/Equipement';
import { Valeur } from "../../../models/Valeur";
import { ColumnDefinition, FilterFieldDefinition } from "../../../components/interfaces";
import SegaFilter from "../../../components/Common/segafilter";
import { EquipementService } from "../../../services/EquipementService";
import { ValeurService } from "../../../services/valeurService";
import { axiosInstance } from '../../../services/configaxios';

function EquipementsPage() {
  const valeurService = useMemo(() => new ValeurService(axiosInstance), []);
  const equipementService = useMemo(() => new EquipementService(axiosInstance), []);
  
  const [listeEquipements, setListeEquipements] = useState<Equipement[] | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const [filter, setFilter] = useState<Equipement>(filtreEquipementInstance());
  const [ofrcom, setOfrcomListe] = useState<Valeur[] | null>(null);
  const [stusga, setStusgaListe] = useState<Valeur[] | null>(null);

  const rafraichirListeEquipements = useCallback(async (currentFilter: Equipement) => {
    try {
      setIsLoading(true);
      const result = await equipementService.getByFilter(currentFilter);
      setListeEquipements(result);
    } catch (error) {
      console.error('Erreur lors du chargement des données', error);
    } finally {
      setIsLoading(false);
    }
  }, [equipementService]);

  useEffect(() => {
    (async () => {
      try {
        setOfrcomListe(await valeurService.getOneList("OFREQP"));
        setStusgaListe(await valeurService.getOneList("STUSGA"));
      } catch (error) {
        console.error("Erreur lors du chargement des listes", error);
      }
    })();
  }, [valeurService]);

  useEffect(() => {
    rafraichirListeEquipements(filter);
  }, [rafraichirListeEquipements, filter]);

  const handleFilterChange = async (newFilter: Equipement) => {
    setFilter(newFilter);
  };

  function createEquipementInstance() {
    return {
      liE_MSI: "",
      equipement: "",
      iS_EQUIVIDE: 1,
      ofR_COM: "",
      cmS_STU: "BRO",
      ofR_COM_COD: "FTO",
      cmS_ID: -1,
      cmS_STU_LIBELLE: "",
      clE_EQP: "",
      datE_MAJ: "2023-09-09T00:00:00.000Z",
      resulT_MAJ: "",
    } as Equipement;
  }

  function filtreEquipementInstance() {
    return {
      liE_MSI: "",
      equipement: "",
      iS_EQUIVIDE: 1,
      ofR_COM: "",
      cmS_STU: "BRO",
      ofR_COM_COD: "FTO",
      cmS_ID: -1,
      cmS_STU_LIBELLE: "",
      clE_EQP: "",
      datE_MAJ: "2023-09-09T00:00:00.000Z",
      resulT_MAJ: "",
    } as Equipement;
  }

  const fieldConfig: FilterFieldDefinition[] = [
    { dataField: 'liE_MSI', caption: 'MSISDN', dataType: 'text' },
    { dataField: 'ofR_COM', caption: 'Offre Commerciale', dataType: 'lookup', optionValueField: 'codval', optionLabelField: 'libval', options: ofrcom },
    { dataField: 'equipement', caption: 'Equipement de base', dataType: 'text' },
    { dataField: 'cmS_STU', caption: 'Statut', dataType: 'lookup', optionValueField: 'codval', optionLabelField: 'libval', options: stusga },
    { dataField: 'iS_EQUIVIDE', caption: 'Equipement Vide', dataType: 'checkedit' },
  ];

  const columnsDef: ColumnDefinition[] = [
    { visible: true, caption: 'Offre Commerciale', name: 'ofR_COM', required: true, typeField: 'text' },
    { visible: true, caption: 'Statut Commande', name: 'cmS_STU_LIBELLE', editable: true, typeField: 'text' },
    { visible: true, caption: 'MSISDN', name: 'liE_MSI', required: true, typeField: 'text' },
    { visible: true, caption: 'Equipement de base', name: 'equipement', editable: true, typeField: 'text' },
    { visible: true, caption: 'Clé identification équipement', name: 'clE_EQP', editable: true, typeField: 'text' },
    { visible: true, caption: 'Date de MAJ', name: 'datE_MAJ', editable: true, typeField: 'text' },
    { visible: true, caption: 'Résultat de MAJ', name: 'resulT_MAJ', editable: true, typeField: 'text' },
  ];

  const handleRowClick = async (id: number): Promise<void> => {
    console.info('equipement actuel ', id);
  };

  return (
    <React.Fragment>
      {/* <h2 className={'content-block'}>Equipements</h2> */}
      <div className={'content-block dx-card responsive-paddings'}>
        <SegaFilter Filter={filter} columnCount={3} onFilterChange={handleFilterChange} FilterFields={fieldConfig} />
      </div>
      <div className={'content-block dx-card responsive-paddings'}>
        <SegaDataGrid
          idName="cmS_ID"
          type={createEquipementInstance}
          dataSource={listeEquipements}
          ColumnDefinition={columnsDef}
          canEdit={false} canAdd={false}
          onRowClick={handleRowClick}
        />
        {isLoading && <div>Loading...</div>}
      </div>
    </React.Fragment>
  );
}

export default EquipementsPage;
