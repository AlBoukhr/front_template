import React, { useCallback, useEffect, useMemo, useState } from "react"; 
import { EnvoiCommande, EnvoiCommandeFilter } from '../../../models/EnvoiCommande'; 
import { Valeur } from "../../../models/Valeur";
import { ColumnDefinition, FilterFieldDefinition } from "../../../components/interfaces";
import SegaFilter from "../../../components/Common/segafilter";
import SegaDataGrid from "../../../components/segadevextreme/datagrid";
import { axiosInstance } from '../../../services/configaxios'; 
import { EnvoiCommandesService } from "../../../services/EnvoiCommandesService";
import EnvoiCommandeDetailPage from "./envoicommandeDetail";
import { ValeurService } from "../../../services/valeurService";

function EnvoiCommandePage() {
  const valeurService = useMemo(() => new ValeurService(axiosInstance), []);  
  const envoicommandesService = useMemo(() => new EnvoiCommandesService(axiosInstance), []);
  const [listeEnvoiCommandes, setListeEnvoiCommandes] = useState<EnvoiCommande[] | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [ofrcom, setOfrcomListe] = useState<Valeur[] | null>(null);   
  const [filter, setFilter] = useState<EnvoiCommandeFilter>(filtreEnvoiCommandeInstance());
  const [selectedEnvoiCommande, setSelectedEnvoiCommande] = useState<EnvoiCommande | null>(null);
  const [pageIndex, setPageIndex] = useState<number | undefined>();
  const [rowIndex, setRowIndex] = useState<number | undefined>();
  const rafraichirListeEnvoiCommandes = useCallback(async (activeFilter: EnvoiCommandeFilter) => {
    try {
      setIsLoading(true);
      const filteredData = await envoicommandesService.getAllByFilter(`OFF_COMM=${activeFilter.OFF_COMM}`);
      setListeEnvoiCommandes(filteredData);
    } catch (e) {
      console.error('Erreur lors du chargement des données', e);
    } finally {
      setIsLoading(false);
    }
  }, [envoicommandesService]);

  const chargerListes = useCallback(async () => {
    try {
      const offres = await valeurService.getOneList("OFRCOM");
      setOfrcomListe(offres); 
    } catch (erreur) {
      console.error("Erreur lors du chargement de la liste", erreur);
    }
  }, [valeurService]);

  useEffect(() => {
    chargerListes();
    rafraichirListeEnvoiCommandes(filtreEnvoiCommandeInstance());
    setSelectedEnvoiCommande(createEnvoiCommandeInstance());
  }, [chargerListes, rafraichirListeEnvoiCommandes]);

  useEffect(() => {
    if (listeEnvoiCommandes && listeEnvoiCommandes.length > 0) {
      setSelectedEnvoiCommande(listeEnvoiCommandes[0]);
    }
    else
    setSelectedEnvoiCommande(createEnvoiCommandeInstance());
  }, [listeEnvoiCommandes]);

  function createEnvoiCommandeInstance() {
    return {
      bdS_ID: -1,
      bdS_TYP: "",
      codE_OPE: "",
      bdS_ADR_MAIL: "",
      bdS_ADR_CCI: "",
      bdS_TITRE: "",
      bdS_OBJET: "",
      bdS_TEXT: "",
      ofF_COMM: "",
      naT_LIE: "",
      bdS_ADR_MAIL_EXP: "",
      liB_OPE: "",
      liB_TYP: "",
      liB_LIE: ""
    } as EnvoiCommande;
  }

  function filtreEnvoiCommandeInstance() {
    return { 
      OFF_COMM: "GNR"
    } as EnvoiCommandeFilter;
  }

  const fieldConfig: FilterFieldDefinition[] = [
    { dataField: 'OFF_COMM', caption: 'Offre Commerciale', dataType: 'lookup', optionValueField: 'codval', optionLabelField: 'libval', options: ofrcom }
  ];

  const columnsDef: ColumnDefinition[] = [
    { visible: true, caption: 'Type Commande', name: 'liB_TYP', required: true, typeField: 'text' }, 
    { visible: true, caption: 'Opérateur', name: 'liB_OPE', editable: true, typeField: 'text' },  
    { visible: true, caption: 'Nature de Lien', name: 'liB_LIE', editable: true, typeField: 'text' },  
    { visible: true, caption: 'Titre', name: 'bdS_TITRE', editable: true, typeField: 'text', width:400 },
    { visible: true, caption: 'Objet', name: 'bdS_OBJET', editable: true, typeField: 'text' ,width:400}
  ];

  const handleFilterChange = async (newFilter: EnvoiCommandeFilter) => {
    setFilter(newFilter);
    await rafraichirListeEnvoiCommandes(newFilter);
  };

   
 
  const handleAdd = async () => {
    try {
      const newItem = createEnvoiCommandeInstance();
      
      // Ajout de l'élément et rafraîchissement de la grille en effectuant un changement d'état.
      if (listeEnvoiCommandes) {
        setListeEnvoiCommandes([...listeEnvoiCommandes, newItem]);
      } else {
        setListeEnvoiCommandes([newItem]);
      }

      const newSelected = listeEnvoiCommandes ? listeEnvoiCommandes[(listeEnvoiCommandes.length ?? 0) - 1] : null;
      setSelectedEnvoiCommande(newSelected);
      setPageIndex(Math.floor(((listeEnvoiCommandes?.length ?? 0) - 1) / 10));  // page size  10
      setRowIndex((listeEnvoiCommandes?.length ?? 0) - 1);



    } catch (error) {
      console.error('Erreur lors de la création', error)
      // Gérer l'erreur ici
    }
  };
  const handleDelete = async (id: number) => {
    try {
      await envoicommandesService.remove('BDS_ID',id);
      rafraichirListeEnvoiCommandes(filter);
    } catch (error) {
      console.error('Erreur lors de la suppression', error);
    }
  };

  const handleClick = (id: number) => {
    const selected = listeEnvoiCommandes?.find(cr => cr.bdS_ID === id);
    if (selected) {
      setSelectedEnvoiCommande(selected);
    }
  };

  const handleSave = async (data: EnvoiCommande) => {
    try {
      if (data.bdS_ID === -1 || data.bdS_ID === undefined) {
        await envoicommandesService.create(data);
      } else {
        await envoicommandesService.updateByItem(data);
      }
      setSelectedEnvoiCommande(null);
      rafraichirListeEnvoiCommandes(filter);
    } catch (erreur) {
      console.error("Erreur lors de la sauvegarde du compte-rendu", erreur);
    }
  };

  function handelCancel(): void {
    setPageIndex(undefined);
    setRowIndex(undefined);
    rafraichirListeEnvoiCommandes(filter);
  }

  return (
    <React.Fragment>
      {/* <h2 className={'content-block'}>Envois de Commandes</h2> */}
      <div className={'content-block dx-card responsive-paddings'}>
        <SegaFilter  columnCount={4} Filter={filter} onFilterChange={handleFilterChange} FilterFields={fieldConfig} />    
      </div>
      <div className={'content-block dx-card responsive-paddings'}>
        <SegaDataGrid
          idName="bdS_ID"
          type={createEnvoiCommandeInstance}
          dataSource={listeEnvoiCommandes}
          ColumnDefinition={columnsDef} 
          onAdd={handleAdd}
          canEdit={true} 
          canAdd={true}
          onRowClick={async (id) => handleClick(id)}
          pageIndex={pageIndex}
          rowIndex={rowIndex}
        />
      </div>
      <div className={'content-block dx-card responsive-paddings'}>
        {selectedEnvoiCommande && (
          <EnvoiCommandeDetailPage
       
          onDel={handleDelete}
            envoiCommande={selectedEnvoiCommande}
            onSave={handleSave}
            onCancel={handelCancel}
          />
        )}
        {isLoading && <div>Loading...</div>}
      </div>
    </React.Fragment>
  );
}

export default EnvoiCommandePage;
