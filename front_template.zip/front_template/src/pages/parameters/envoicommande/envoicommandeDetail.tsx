import React, { useEffect, useMemo, useState } from "react";
import { Button, SelectBox, TextArea, TextBox } from "devextreme-react";
import { EnvoiCommande } from "../../../models/EnvoiCommande";
import { ValeurService } from "../../../services/valeurService";
import { Valeur } from "../../../models/Valeur";
import { axiosInstance } from '../../../services/configaxios';

interface EnvoiCommandeDetailPageProps {
  envoiCommande: EnvoiCommande | null;
  onSave: (data: EnvoiCommande) => Promise<void>; 
  onDel: (id: number) => Promise<void>;
  onCancel: () => void;
}

const EnvoiCommandeDetailPage: React.FC<EnvoiCommandeDetailPageProps> = ({ envoiCommande, onSave, onDel, onCancel }) => {
  const valeurService = useMemo(() => new ValeurService(axiosInstance), []);
  const [state, setState] = useState<EnvoiCommande>(envoiCommande || {
    bdS_TYP: '',
    codE_OPE: '',
    bdS_ADR_MAIL: '',
    bdS_ADR_CCI: '',
    bdS_TITRE: '',
    bdS_OBJET: '',
    bdS_TEXT: '',
    ofF_COMM: '',
    naT_LIE: '',
    bdS_ADR_MAIL_EXP: '',
    liB_OPE: '',
    liB_TYP: '',
    liB_LIE: '',
  });

  const [selectData, setSelectData] = useState<{ [key: string]: Valeur[] | null }>({
    ofrcom: null,
    nivesc: null,
    natsga: null,
    natgnr: null,
    natlie: null,
    natfto: null,
    natfte: null,
    typsga: null,
    typgnr: null,
    typdsp: null,
    opedsp: null 
  });

  const [filteredNatLieData, setFilteredNatLieData] = useState<Valeur[] | null>(null);
  const [filteredTypSgaData, setFilteredTypSgaData] = useState<Valeur[] | null>(null);
  const [filteredOperateurData, setFilteredOperateurData] = useState<Valeur[] | null>(null);
  const [isNatLieVisible, setIsNatLieVisible] = useState<boolean>(true);
  const [isOperateurVisible, setIsOperateurVisible] = useState<boolean>(true);
  const [isDataLoaded, setIsDataLoaded] = useState<boolean>(false);

  useEffect(() => {
    const chargerListes = async () => {
      try {
        const newSelectData = {
          ofrcom: await valeurService?.getOneList("OFRCOM") || [],
          nivesc: await valeurService?.getOneList("NIVESC") || [],
          natsga: await valeurService?.getOneList("NATSGA") || [],
          natgnr: await valeurService?.getOneList("NATGNR") || [],
          natlie: await valeurService?.getOneList("NATLIE") || [],
          natfto: await valeurService?.getOneList("NATFTO") || [],
          natfte: await valeurService?.getOneList("NATFTE") || [],
          typsga: await valeurService?.getOneList("TYPSGA") || [],
          typgnr: await valeurService?.getOneList("TYPGNR") || [],
          typdsp: await valeurService?.getOneList("TYPDSP") || [],
          opedsp: await valeurService?.getOneList("OPEDSP") || [], 
        };
        setSelectData(newSelectData);
        setIsDataLoaded(true);
      } catch (erreur) {
        console.error("Erreur lors du chargement de la liste", erreur);
      }
    };

    chargerListes();
  }, [valeurService]);

  const updateFilters = (offCommValue: string) => {
    let updatedFilteredNatLieData;
    let updatedFilteredTypSgaData;
    let updatedFilteredOperateurData;

    switch (offCommValue) {
      case 'DSL':
        updatedFilteredNatLieData = selectData.natlie;
        setIsNatLieVisible(true);
        setIsOperateurVisible(false);
        break;
      case 'VGA':
      case 'FTH':
        setIsNatLieVisible(false);
        setIsOperateurVisible(false);
        break;
      case 'FTO':
        updatedFilteredTypSgaData = selectData.typdsp;
        setIsNatLieVisible(false);
        setIsOperateurVisible(false);
        break;
      case 'FTE':
      case 'DSP':
        updatedFilteredTypSgaData = selectData.typdsp;
        updatedFilteredOperateurData = selectData.opedsp;
        setIsNatLieVisible(false);
        setIsOperateurVisible(true);
        break;
      case 'GNR':
        updatedFilteredNatLieData = selectData.natgnr;
        updatedFilteredTypSgaData = selectData.typsga;
        updatedFilteredOperateurData = selectData.opedsp;
        setIsNatLieVisible(true);
        setIsOperateurVisible(true);
        break;
      default:
        updatedFilteredNatLieData = selectData.natsga;
        updatedFilteredTypSgaData = selectData.typsga;
        updatedFilteredOperateurData = selectData.opedsp;
        setIsNatLieVisible(true);
        setIsOperateurVisible(false);
    }

    setFilteredNatLieData(updatedFilteredNatLieData || []);
    setFilteredTypSgaData(updatedFilteredTypSgaData || []);
    setFilteredOperateurData(updatedFilteredOperateurData || []);
  };

  const handleChange = (field: keyof EnvoiCommande, value: any) => {
    setState(prevState => ({
      ...prevState,
      [field]: value
    }));
  };

  useEffect(() => {
    if (envoiCommande && isDataLoaded) {
      setState(envoiCommande);
      updateFilters(envoiCommande.ofF_COMM || '');
    }
  }, [envoiCommande, isDataLoaded]);

  const isFieldRequired = (field: keyof EnvoiCommande): boolean => {
    switch (field) {
      case 'bdS_TYP':
      case 'naT_LIE':
      case 'codE_OPE':
      case 'bdS_ADR_MAIL':
      case 'bdS_TITRE':
      case 'bdS_OBJET':
      case 'bdS_TEXT':
        return true;
      default:
        return false;
    }
  };

  if (!envoiCommande) {
    return <div>Sélectionnez un niveau d'escalade pour voir les détails</div>;
  }

  return (
    <React.Fragment>
      <div className="settings">
        <div className="column">
          <div className="field">
            <div className="value">
              <SelectBox
                dataSource={filteredTypSgaData}
                value={state.bdS_TYP}
                valueExpr="codval"
                displayExpr="libval"
                text="Offre Commerciale"
                onValueChanged={e => handleChange('bdS_TYP', e.value)}
                className={isFieldRequired('bdS_TYP') ? 'required-field' : ''}
                label="Type Commande"
              />
            </div>
          </div>
        </div>
        {isNatLieVisible && (
          <div className="column">
            <div className="field">
              <div className="value">
                <SelectBox
                  dataSource={filteredNatLieData}
                  value={state.naT_LIE}
                  valueExpr="codval"
                  displayExpr="libval"
                  text="Niveau Escalade"
                  onValueChanged={e => handleChange('naT_LIE', e.value)}
                  className={isFieldRequired('naT_LIE') ? 'required-field' : ''}
                  label="Nature Lien"
                />
              </div>
            </div>
          </div>
        )}
        {isOperateurVisible && (
          <div className="column">
            <div className="field">
              <div className="value">
                <SelectBox
                  dataSource={filteredOperateurData}
                  value={state.codE_OPE}
                  valueExpr="codval"
                  displayExpr="libval"
                  text="Nature Lien"
                  onValueChanged={e => handleChange('codE_OPE', e.value)}
                  className={isFieldRequired('codE_OPE') ? 'required-field' : ''}
                  label="Opérateur"
                />
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="bottom-row">
        <TextBox
          className={`full-width-input ${isFieldRequired('bdS_ADR_MAIL') ? 'required-field' : ''}`}
          value={state.bdS_ADR_MAIL || ""}
          onValueChanged={e => handleChange('bdS_ADR_MAIL', e.value)}
          label="Adresse Mail"
        />
        <TextBox
          className="full-width-input"
          value={state.bdS_ADR_CCI || ""}
          onValueChanged={e => handleChange('bdS_ADR_CCI', e.value)}
          label="CCI"
        />
        <TextBox
          className={`full-width-input ${isFieldRequired('bdS_ADR_MAIL_EXP') ? 'required-field' : ''}`}
          value={state.bdS_ADR_MAIL_EXP || ""}
          onValueChanged={e => handleChange('bdS_ADR_MAIL_EXP', e.value)}
          label="Adresse Mail Expediteur"
        />
        <TextBox
          className={`full-width-input ${isFieldRequired('bdS_TITRE') ? 'required-field' : ''}`}
          value={state.bdS_TITRE || ""}
          onValueChanged={e => handleChange('bdS_TITRE', e.value)}
          label="Titre"
        />
        <TextBox
          className={`full-width-input ${isFieldRequired('bdS_OBJET') ? 'required-field' : ''}`}
          value={state.bdS_OBJET || ""}
          onValueChanged={e => handleChange('bdS_OBJET', e.value)}
          label="Objet"
        />
        <TextArea
          className={`full-width-input ${isFieldRequired('bdS_TEXT') ? 'required-field' : ''}`}
          value={state.bdS_TEXT || ""}
          onValueChanged={e => handleChange('bdS_TEXT', e.value)}
          label="Texte"
        />
      </div>

      <div className="button-row">
        <Button onClick={() => onDel(state.bdS_ID || -1)} icon="trash" hint="Supprimer" />
        <Button onClick={() => onSave(state)} icon="save" hint="Enregistrer" />
        <Button onClick={onCancel} icon="clear" hint="Annuler" />
      </div>
    </React.Fragment>
  );
};

export default EnvoiCommandeDetailPage;
