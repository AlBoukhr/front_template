import { RetardsService } from "../../../services/RetardsService"; 
import { axiosInstance } from '../../../services/configaxios'; 
import { Retard } from '../../../models/Retard'; 
import React, { useCallback, useEffect, useMemo, useState } from "react"; 
import SegaDataGrid from "../../../components/segadevextreme/datagrid";
import { ColumnDefinition } from "../../../components/interfaces";
import RetardDetailPage from "./retardDetail";

function RetardPage() {
  const [listeRetards, setlisteRetards] = useState<Retard[] | null>(null);
  const retardService = useMemo(() => new RetardsService(axiosInstance), []); 
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [selectedRetard, setSelectedRetard] = useState<Retard | null>(null);
  const [pageIndex, setPageIndex] = useState<number | undefined>();
  const [rowIndex, setRowIndex] = useState<number | undefined>();
  
  useEffect(() => {
    if (listeRetards && listeRetards.length > 0) {
      setSelectedRetard(listeRetards[0]);
    }
  }, [listeRetards]);

  function createRetardInstance() {
    return {
      reT_ID: -1,
      reT_OFR_COM: "",
      reT_CHA_NOM: "",
      reT_NAT_LIE: "",
      reT_TYP_CMD: "",
      reT_DELAI: -1,
      reT_CHA_LBL: "",
      ofR_COM_LBL: "",
      cmD_TYP: "",
      naT_LIE_LBL: "",
    } as unknown as Retard;
  }

  const columnsDef: ColumnDefinition[] = [
    { visible: true, caption: 'Offre Commerciale', name: 'ofR_COM_LBL', required: true, typeField: 'text' },
    { visible: true, caption: 'Nature Lien', name: 'naT_LIE_LBL', editable: true, typeField: 'text' },
    { visible: true, caption: 'Type Commande', name: 'cmD_TYP', required: true, typeField: 'text' }, 
    { visible: true, caption: 'Nom Retard', name: 'reT_CHA_NOM', editable: true, typeField: 'text' },
    { visible: true, caption: 'Libellé Retard', name: 'reT_CHA_LBL', editable: true, typeField: 'text' },
    { visible: true, caption: 'Délai', name: 'reT_DELAI', editable: true, typeField: 'text' }, 
  ];

  const rafraichirListeRetards = useCallback(async () => {
    try {
      setIsLoading(true);
      setlisteRetards(await retardService.getAll());
    } catch (e) {
      console.error('Erreur lors du chargement des données', e);
    } finally {
      setIsLoading(false);
    }
  }, [retardService]);

  useEffect(() => {
    rafraichirListeRetards();
    setSelectedRetard(createRetardInstance());
  }, [rafraichirListeRetards]);

  const handleDelete = async (id: number) => {
    try {
      await retardService.remove('RET_ID', id);
      rafraichirListeRetards();
    } catch (error) {
      console.error('Erreur lors de la suppression', error);
    }
  };

  const handleclick = async (id: number) => {
    const ret = listeRetards?.find(cr => cr.reT_ID === id);
    if (ret) {
      setSelectedRetard(ret);
    }
  };

  const handleSave = async (data: Retard) => {
    try {
      if (data.reT_ID === -1 || data.reT_ID === undefined) {
        await retardService.create(data);
      } else {
        await retardService.updateByItem(data);
      }
      setSelectedRetard(null);
      rafraichirListeRetards();
    } catch (erreur) {
      console.error("Erreur lors de la sauvegarde du compte-rendu", erreur);
    }
  };

  const handleAdd = async () => {
    try {
      const newItem = createRetardInstance();
      setlisteRetards(prev => {
        const newList = [...(prev ?? []), newItem]; 
        return newList;
      });

      const newSelected = listeRetards ? listeRetards[(listeRetards.length ?? 0) - 1] : null;
      setSelectedRetard(newSelected);
      setPageIndex(Math.floor(((listeRetards?.length ?? 0) - 1) / 10));  // page size  10
      setRowIndex((listeRetards?.length ?? 0) - 1);

    } catch (error) {
      console.error('Erreur lors de la création', error);
    }
  };

  function handelCancel(): void {
    setPageIndex(undefined);
    setRowIndex(undefined);
    rafraichirListeRetards();
  }

  return (
    <React.Fragment>
      <div className="content-block dx-card responsive-paddings">
        <SegaDataGrid 
          idName="reT_ID" 
          type={createRetardInstance} 
          dataSource={listeRetards} 
          ColumnDefinition={columnsDef}
          canEdit={true}
          onAdd={handleAdd}
          canAdd={true}
          onRowClick={(id: number) => handleclick(id)}
          pageIndex={pageIndex}
          rowIndex={rowIndex}
        />
      </div>
      <div className="content-block dx-card responsive-paddings">
        {selectedRetard && (
          <RetardDetailPage
            retard={selectedRetard}
            onDel={handleDelete}
            onSave={handleSave}
            onCancel={handelCancel}
          />
        )}
        {isLoading && <div>Loading...</div>}
      </div>
    </React.Fragment>
  );
}

export default RetardPage;
