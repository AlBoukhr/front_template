import React, { useCallback, useEffect, useMemo, useState } from "react";
import 'devextreme-react/text-area';
import { Button, SelectBox,  TextBox } from "devextreme-react";
import {  ValeurService  } from "../../../services/valeurService";
import { Retard } from "../../../models/Retard";
import { Valeur } from "../../../models/Valeur";
import { axiosInstance } from '../../../services/configaxios'; // Assurez-vous du bon chemin d'importation
import { cacheData, getCachedData } from "../../../services/cacheservice";

interface RetardDetailPageProps {
    retard: Retard | null;
    onSave: (data: Retard) => Promise<void>;
   
    onDel :(P_RET_ID: number) => Promise<void>;
    onCancel: () => void;
}

const RetardDetailPage: React.FC<RetardDetailPageProps> = ({ retard, onSave,  onDel,onCancel }) => {
    const   valeurService =   useMemo(() => new ValeurService(axiosInstance), []); 

    const [state, setState] = useState<Retard>(retard || {
        reT_ID: -1,
        reT_OFR_COM: "",
        reT_CHA_NOM: "",
        reT_NAT_LIE: "",
        reT_TYP_CMD: "",
        reT_DELAI: -1,
        reT_CHA_LBL: "",
        ofR_COM_LBL: "",
        cmD_TYP: "",
        naT_LIE_LBL: "",
    });

    
      

    const [selectData, setSelectData] = useState<{ [key: string]: Valeur[] | null }>({
        ofrcom: null,
        nivesc: null,
        natsga: null,
        natgnr: null,
        natlie: null,
        natfto: null,
        natfte: null,

               retvga: null,
                  retdsl: null,
                  retdsp: null,
                  retfto: null,
                  retfte: null,
                  retcel: null,
                  retfth: null,
                  typsga : null,
                  typdsp : null, 
                  typfte : null,
                  ordvga: null,
                  ordfth : null,
                  ordsga : null,
                
 
    });
   
    const [filteredNatLieData, setFilteredNatLieData] = useState<Valeur[] | null>(null);
    const [filteredOrdreData, setFilteredOrdreData] = useState<Valeur[] | null>(null);
    const [filteredColonneData, setFilteredColonneData] = useState<Valeur[] | null>(null);
        const [isNatLieVisible, setIsNatLieVisible] = useState<boolean>(true);

        const [isDataLoaded, setIsDataLoaded] = useState<boolean>(false);

        const chargerListes = useCallback(async () => {
            try {
              const newSelectData = { ...selectData };
        
              for (const key in newSelectData) {
                const cachedData = getCachedData(key);
                if (cachedData) {
                  newSelectData[key] = cachedData;
                } else {
                  newSelectData[key] = await valeurService.getOneList(key.toUpperCase());
                  cacheData(key, newSelectData[key]);
                }
              }
        
              setSelectData(newSelectData);
              setIsDataLoaded(true); // <-- Indiquer que les données sont chargées
            } catch (erreur) {
              console.error('Erreur lors du chargement de la liste', erreur);
            }
          }, [valeurService]);
        
          useEffect(() => {
            if (!isDataLoaded) chargerListes(); 
          }, [chargerListes, isDataLoaded]); // Cha


         
        
    useEffect(() => {
        const fetchData = async () => {
            if (retard) {
                setState(retard);
                await handleChange('reT_OFR_COM', retard.reT_OFR_COM);
            }
        };
        fetchData();
    }, [retard]);

    const handleChange = async (field: keyof Retard, value: any) => {
        console.log(`Field changed: ${field}, Value: ${value}`);
      if (field === 'reT_OFR_COM') {
          // Mettre à jour filteredNatLieData en fonction de bmA_OFR_COM
          let updatedFilteredNatLieData;
          let updatedFilteredOrdreData;
          let updatedFilteredColonneData;
          switch (value) {
              case 'DSL':
                  updatedFilteredNatLieData = selectData.natlie;
                  updatedFilteredOrdreData = selectData.ordsga;
                  updatedFilteredColonneData = selectData.retdsl;
                  setIsNatLieVisible(true);
                  break;
                  case 'VGA':
                  
                    updatedFilteredOrdreData = selectData.ordvga;
                    updatedFilteredColonneData = selectData.retvga;
                        // Hide selection bmA_NAT_LIE
                        setIsNatLieVisible(false);
                        break;
                       
                            case 'FTH':
                               
                                updatedFilteredOrdreData = selectData.ordfth;
                                updatedFilteredColonneData = selectData.retfth;
                                // Hide selection bmA_NAT_LIE
                                setIsNatLieVisible(false);
                                break;
                  
             
              case 'DSP':
               
              updatedFilteredOrdreData = selectData.typdsp;
              updatedFilteredColonneData = selectData.retdsp;
                  // Hide selection bmA_NAT_LIE
                  setIsNatLieVisible(false);
                  break;
              case 'FTO':
                  updatedFilteredNatLieData = selectData.natfto;
                    updatedFilteredOrdreData = selectData.ordsga;
                  updatedFilteredColonneData = selectData.retfto;
                  setIsNatLieVisible(true);
                  break;
              case 'FTE':
                  updatedFilteredNatLieData = selectData.natfte;
                    updatedFilteredOrdreData = selectData.typfte;
                updatedFilteredColonneData = selectData.retfte;
                  setIsNatLieVisible(true);
                  break; 
              // ajout d'autres cas au besoin
              default:
                updatedFilteredNatLieData = selectData.natsga;
                updatedFilteredOrdreData = selectData.typsga;
            updatedFilteredColonneData = selectData.retcel;
              setIsNatLieVisible(true);
          }
          setFilteredNatLieData(updatedFilteredNatLieData || []); 
          setFilteredOrdreData(updatedFilteredOrdreData || []);    
          setFilteredColonneData(updatedFilteredColonneData || []);    
          }

      setState(prevState => ({
          ...prevState,
          [field]: value
      }));
  };
  
  const isFieldRequired = (field: keyof Retard): boolean => {
    // Logique pour déterminer si le champ est requis
    // Par exemple, vous pouvez définir certains champs comme requis selon l'offre commerciale sélectionnée
    switch (field) {
        case 'reT_OFR_COM':
        case 'reT_NAT_LIE':
        case 'reT_TYP_CMD':
          case 'reT_DELAI':
            case 'reT_CHA_NOM':
            
            return true;
        default:
            return false;
    }
};


    if (!retard) {
        return <div>Sélectionnez un niveau d'escalade pour voir les détails</div>;
    }

    return (
        <React.Fragment>
            <div className="settings">
                <div className="column">
                    <div className="field">
                        <div className="value">
                            <SelectBox
                                dataSource={selectData.ofrcom}
                                value={state.reT_OFR_COM}
                                valueExpr="codval"
                                displayExpr="libval"
                                text="Offre Commerciale"
                                onValueChanged={e => handleChange('reT_OFR_COM', e.value)}
                                className={isFieldRequired('reT_OFR_COM') ? 'required-field' : ''}
                                label="Offre Commerciale"
                            />
                        </div>
                    </div>
                    <div className="field">
                        <div className="value">
                            <SelectBox
                                dataSource={filteredColonneData}
                                value={state.reT_CHA_NOM}
                                valueExpr="codval"
                                displayExpr="libval"
                                text="Niveau Escalade"
                                onValueChanged={e => handleChange('reT_CHA_NOM', e.value)}
                                className={isFieldRequired('reT_CHA_NOM') ? 'required-field' : ''}
                                label="Colonne Suivi"
                            />
                        </div>
                    </div>
                </div>
                
                <div className="column">
                    <div className="field">
                            <div className="value">
                                <SelectBox
                                    dataSource={filteredOrdreData}
                                    value={state.reT_TYP_CMD}
                                    valueExpr="codval"
                                    displayExpr="libval"
                                    text="Nature Lien"
                                    onValueChanged={e => handleChange('reT_TYP_CMD', e.value)}
                                    className={isFieldRequired('reT_TYP_CMD') ? 'required-field' : ''}
                                    label="Type Commande"
                                />
                            </div>
                       

                      
                    </div>
                    <div className="field">
                            <div className="value">
                                <TextBox
                                   
                                   value={typeof state.reT_DELAI === "number" ? state.reT_DELAI.toString() : state.reT_DELAI || ""}
                                    onValueChanged={e => handleChange('reT_DELAI', e.value)}
                                    className={isFieldRequired('reT_DELAI') ? 'required-field' : ''}
                                    label="Délai"
                                />
                            </div>
                       

                      
                    </div>
                </div> 
                  {isNatLieVisible && (
                <div className="column">
                    <div className="field">

                            <div className="value">
                                <SelectBox
                                    dataSource={filteredNatLieData}
                                    value={state.reT_NAT_LIE}
                                    valueExpr="codval"
                                    displayExpr="libval"
                                    text="Nature Lien"
                                    onValueChanged={e => handleChange('reT_NAT_LIE', e.value)}
                                    className={isFieldRequired('reT_NAT_LIE') ? 'required-field' : ''}
                                    label="Nature Lien"
                                />
                            </div>
                        
                    </div>
                    
                </div> )}           
                 </div>
 

                 <div className="button-row">
           
                 <Button onClick={() => onDel(state.reT_ID || -1)} icon="trash" hint="Supprimer"/>
                <Button onClick={() => onSave(state)} icon="save" hint="Enregistrer"/>
                <Button onClick={onCancel} icon="clear" hint="Annuler"/>
            </div>
        </React.Fragment>
    );
};

export default RetardDetailPage;
