import React, { useCallback, useEffect, useMemo, useState } from "react";
import 'devextreme-react/text-area';
import { Button, SelectBox,  TextBox } from "devextreme-react";
import {  ValeurService  } from "../../../services/valeurService";
import { Dsp } from "../../../models/Dsp";
import { Valeur } from "../../../models/Valeur";
import { axiosInstance } from '../../../services/configaxios'; // Assurez-vous du bon chemin d'importation
import { cacheData, getCachedData } from "../../../services/cacheservice";

interface DspDetailPageProps {
    Dsp: Dsp | null;
    onSave: (data: Dsp) => Promise<void>;
   
    onDel :(P_RET_ID: number) => Promise<void>;
    onCancel: () => void;
}

const DspDetailPage: React.FC<DspDetailPageProps> = ({ Dsp, onSave,  onDel,onCancel }) => {
    
    const [state, setState] = useState<Dsp>(Dsp || {
        doP_ID: -1,
        codE_OPE: "",
        dsP_NOM: "",
        dsP_ID: -1,
        liB_OPE: "",
        operateur: "",
    });

     
        
    useEffect(() => {
        const fetchData = async () => {
            if (Dsp) {
                setState(Dsp);
                
            }
        };
        fetchData();
    }, [Dsp]);
 
  
    const handleChange = (field: keyof Dsp, value: any) => {
        setState(prevState => ({
          ...prevState,
          [field]: value
        }));
      };


    if (!Dsp) {
        return <div>Sélectionnez un Dsp pour voir les détails</div>;
    }

    return (
        <React.Fragment>
            <div className="settings">
              
                
                <div className="column">
                    
                    <div className="field">
                            <div className="value">
                                <TextBox
                                   
                                   value={state.dsP_NOM ?? ''}
                                    onValueChanged={e => handleChange('dsP_NOM', e.value)}
                                    className={ 'required-field'}
                                    label="Dsp"
                                />
                            </div>
                       

                      
                    </div>
                </div> 
                           
                 </div>
 

                 <div className="button-row">
           
                 <Button onClick={() => onDel(state.doP_ID || -1)} icon="trash" hint="Supprimer"/>
                <Button onClick={() => onSave(state)} icon="save" hint="Enregistrer"/>
                <Button onClick={onCancel} icon="clear" hint="Annuler"/>
            </div>
        </React.Fragment>
    );
};

export default DspDetailPage;
