 
 
 
import { Dsp, DspFilter } from '../../../models/Dsp' 
 
  
import React, { useCallback, useEffect, useMemo, useState } from "react"; 
 
import SegaDataGrid from "../../../components/segadevextreme/datagrid";
import { Valeur } from "../../../models/Valeur";
import { ColumnDefinition, FilterFieldDefinition } from "../../../components/interfaces";
import SegaFilter from "../../../components/Common/segafilter";

import {  DspService  } from "../../../services/DspService";
import {  ValeurService  } from "../../../services/valeurService";
import { axiosInstance } from '../../../services/configaxios'; // Assurez-vous du bon chemin d'importation
import DspDetailPage from './dspDetail';

function DspPage() {
    
  const [listeDsps, setlisteDsps] = React.useState<Dsp[] | null>(null)
  const  dspService  =  useMemo(() =>  new  DspService(axiosInstance), []);
  const [isLoading, setIsLoading] = React.useState<boolean>(false)
  
  const [filter, setFilter] = useState(filtreDspInstance());
  const [ofrcom, setofrcomListe] = React.useState<Dsp[] | null>(null) 
  const   valeurService = useMemo(() => new ValeurService(axiosInstance), []);
  const [selectedDsp, setSelectedDsp] = useState<Dsp | null>(null);
  const [pageIndex, setPageIndex] = useState<number | undefined>();
  const [rowIndex, setRowIndex] = useState<number | undefined>();
  const rafraichirListeDsps = useCallback(async () => {
    try {
      setIsLoading(true) 
      setlisteDsps(await dspService.getAllByFilter(`CODE_OPE=${filter.CODE_OPE}`))
    } catch (e) {
      console.error('Erreur lors du chargement des données', e)
      
    } finally {
      setIsLoading(false)
    }
  },[dspService, filter.CODE_OPE])

  useEffect(() => {
    const chargerListes = async () => {
      try {
        
        setofrcomListe(await dspService.getSpecificData("GetOperateurs")); // Stocker les données dans l'état
        
      } catch (erreur) {
        console.error("Erreur lors du chargement de la liste", erreur);
        // Handle the error appropriately in your actual app
      }
    };
    chargerListes();
    rafraichirListeDsps(); // Appel de la fonction au montage du composant
    setSelectedDsp(createDspInstance());
  }, [rafraichirListeDsps, valeurService]); // Le tableau vide [] indique que l'effet ne dépend d'aucune variable et ne s'exécutera qu'une fois

  
  useEffect(() => {
    if (listeDsps && listeDsps.length > 0) {
      setSelectedDsp(listeDsps[0]);
    }
    else
    setSelectedDsp(createDspInstance());
  }, [listeDsps]);


  function createDspInstance() {
    return {
    doP_ID: -1,
    codE_OPE: "",
    dsP_NOM: "",
    dsP_ID: -1,
    liB_OPE: "",
    operateur: "",
  } as unknown as Dsp;
}
  
 

function filtreDspInstance() {
  return { 
    CODE_OPE: "SFR", 
} as unknown as DspFilter;
}
 

  const columnsDef : ColumnDefinition[]= [
    { visible :true , caption: 'DSP', name: 'dsP_NOM', required: true, typeField:'text'},
    
  ];
  
 
  const fieldConfig: FilterFieldDefinition[] = [
    { dataField: 'CODE_OPE', caption: 'Opérateur',  dataType: 'lookup' ,optionValueField:'codE_OPE', optionLabelField:'operateur', options:ofrcom},
    
  ]; 

  const handleFilterChange = async (newFilter: DspFilter) => {
    setFilter(newFilter);
    await rafraichirListeDsps();
};

const handleAdd = async () => {
  try {
    const newItem = createDspInstance();
    
    // Ajout de l'élément et rafraîchissement de la grille en effectuant un changement d'état.
    if (listeDsps) {
      setlisteDsps([...listeDsps, newItem]);
    } else {
      setlisteDsps([newItem]);
    }

    const newSelected = listeDsps ? listeDsps[(listeDsps.length ?? 0) - 1] : null;
    setSelectedDsp(newSelected);
      setPageIndex(Math.floor(((listeDsps?.length ?? 0) - 1) / 10));  // page size  10
      setRowIndex((listeDsps?.length ?? 0) - 1);


  } catch (error) {
    console.error('Erreur lors de la création', error)
    // Gérer l'erreur ici
  }
};
const handleDelete = async (id: number) => {
  try {
    await dspService.remove('doP_ID',id);
    rafraichirListeDsps();
  } catch (error) {
    console.error('Erreur lors de la suppression', error);
  }
};

const handleClick = async (id: number): Promise<void> => {
  const selected = listeDsps?.find(cr => cr.doP_ID === id);
  if (selected) {
    setSelectedDsp(selected);
  }
};

const handleSave = async (data: Dsp) => {
  try {
    if (data.doP_ID === -1 || data.doP_ID === undefined) {
      data.codE_OPE = filter.CODE_OPE;
      await dspService.create(data);
    } else {
      await dspService.updateByItem(data);
    }
    setSelectedDsp(null);
    rafraichirListeDsps();
  } catch (erreur) {
    console.error("Erreur lors de la sauvegarde du compte-rendu", erreur);
  }
};
  
function handelCancel(): void {
  setPageIndex(undefined);
  setRowIndex(undefined);
  rafraichirListeDsps();
}


  return (

    <React.Fragment>
    {/* <h2 className={'content-block'}>DSP</h2> */}

    <div className={'content-block dx-card responsive-paddings'}>
    <SegaFilter Filter={filter} columnCount={4} onFilterChange={handleFilterChange} FilterFields={fieldConfig} /> 
    </div>

    <div className={'content-block dx-card responsive-paddings'}>
    <SegaDataGrid idName="doP_ID" 
    type={createDspInstance} 
    dataSource={listeDsps} 
    ColumnDefinition={columnsDef} 
    canEdit={true} canAdd={true}
    onAdd={handleAdd}
    onRowClick={async (id) => handleClick(id)}
    pageIndex={pageIndex}
    rowIndex={rowIndex}
    ></SegaDataGrid> 
       
    </div>
    <div className={'content-block dx-card responsive-paddings'}>
    {selectedDsp && (
          <DspDetailPage 
          onDel={handleDelete}
            Dsp={selectedDsp}
            onSave={handleSave}
            onCancel={handelCancel}
          />
        )}
         {isLoading && <div>Loading...</div>}
      </div>
    </React.Fragment>

 
 
  )
} 

export default DspPage;
