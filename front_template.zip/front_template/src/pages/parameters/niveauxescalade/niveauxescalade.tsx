 
 
 
   
import React, { useCallback, useEffect, useMemo, useState } from "react";  
import NiveauxEscaladeDetailPage from "./niveauxescaladeDetail"; 
import { NiveauxEscaladeService } from "../../../services/NiveauxEscaladeService";
import { NiveauxEscalade } from '../../../models/NiveauxEscalade';  
import SegaDataGrid from "../../../components/segadevextreme/datagrid";
import { ColumnDefinition } from "../../../components/interfaces"; 
import { axiosInstance } from '../../../services/configaxios'; // Assurez-vous du bon chemin d'importation



function NiveauxEscaladePage() {
    
  const [listeNiveauxEscalades, setlisteNiveauxEscalades] = React.useState<NiveauxEscalade[] | null>(null)
  const  niveauescaladeService  =    useMemo(() => new NiveauxEscaladeService(axiosInstance), []);  
  const [isLoading, setIsLoading] =  useState<boolean>(false)
 
  const [pageIndex, setPageIndex] = useState<number | undefined>();
  const [rowIndex, setRowIndex] = useState<number | undefined>();
  
  const [selectedNiveauEscalade, setSelectedNiveauEscalade] = React.useState<NiveauxEscalade | null>(null);  // Nouvel état
 
  const rafraichirListeNiveauxEscalades = useCallback(async () => {
    try {
      setIsLoading(true) 
      setlisteNiveauxEscalades(await niveauescaladeService.getAll())
 

    } catch (e) {
      console.error('Erreur lors du chargement des données', e)
      
    } finally {
      setIsLoading(false)
    }
  },[ niveauescaladeService])

  
  useEffect(() => {
    if (listeNiveauxEscalades && listeNiveauxEscalades.length > 0) {
      setSelectedNiveauEscalade(listeNiveauxEscalades[0]);
    }
  }, [listeNiveauxEscalades]);


  useEffect(() => {
  
    rafraichirListeNiveauxEscalades(); // Appel de la fonction au montage du composant
    setSelectedNiveauEscalade(createNiveauxEscaladeInstance());

  }, [rafraichirListeNiveauxEscalades]); // Le tableau vide [] indique que l'effet ne dépend d'aucune variable et ne s'exécutera qu'une fois
 
  
  function createNiveauxEscaladeInstance() {
    return {
      bmA_ID:-1,
      bmA_OFR_COM: "",
      bmA_NIV: "",
      bmA_NAT_LIE:"",
      bmA_TITRE: "",
      bmA_OBJET: "",
      bmA_TEXTE:"",
      bmA_ADR_MAIL: "",
      bmA_ADR_CCI: "",
      scM_ID: -1 

    } as unknown as NiveauxEscalade;
  }
 

 

  const columnsDef : ColumnDefinition[]= [
    { visible :true , caption: 'Offre Commerciale', name: 'bmA_OFR_COM', width:100, editable: true, typeField:'text'},
    { visible :true, caption: 'Niveau Escalade', name: 'bmA_NIV', editable: true, width:100,  typeField:'text' },
    { visible :true ,caption: 'Type Lien', name: 'bmA_NAT_LIE',  editable: true , width:100,  typeField:'text'}, 
    { visible :true ,caption: 'Adresse Mail', name: 'bmA_ADR_MAIL', editable: true ,  typeField:'text'},
    { visible :true ,caption: 'CCI', name: 'bmA_ADR_CCI', editable: true ,  typeField:'text'},
    { visible :true ,caption: 'Titre', name: 'bmA_TITRE', editable: true , typeField:'text'}, 
    { visible :true ,caption: 'Objet', name: 'bmA_OBJET', editable: true , typeField:'text'},  
  ];

   
 

  const handleAdd = async () => {
    try {
      const newItem = createNiveauxEscaladeInstance();
      
      setlisteNiveauxEscalades((prevListe) => {
        const updatedList = prevListe ? [...prevListe, newItem] : [newItem];
        return updatedList;
      }); 
      
      const newSelected = listeNiveauxEscalades ? listeNiveauxEscalades[(listeNiveauxEscalades.length ?? 0) - 1] : null;
      setSelectedNiveauEscalade(newSelected);
      setPageIndex(Math.floor(((listeNiveauxEscalades?.length ?? 0) - 1) / 10));  // page size  10
      setRowIndex((listeNiveauxEscalades?.length ?? 0) - 1);


    } catch (error) {
      console.error('Erreur lors de la création', error)
      // Gérer l'erreur ici
    }
  };
 

  // Handler pour la suppression
  const handleDelete = async (id: number) => {
    try {
      await niveauescaladeService.remove('BMA_ID',id);
      rafraichirListeNiveauxEscalades();
    } catch (error) {
      // Gérer l'erreur ici
    }
  };

  function handelCancel(): void {
    setPageIndex(undefined);
    setRowIndex(undefined);
    rafraichirListeNiveauxEscalades();
  }


  const handleclick = async (id: number) => {
    
    const nivesc = listeNiveauxEscalades?.find(cr => cr.bmA_ID === id);
    if (nivesc) {
      setSelectedNiveauEscalade(nivesc);
        console.info('compte rundu actuel ',nivesc.bmA_ID )
    }
  };

  const handleSave = async (data: NiveauxEscalade) => {
    try {
        if (data.bmA_ID === -1 || data.bmA_ID === undefined) {
            await niveauescaladeService.create(data);
            // showInfo({ message: "Compte-rendu créé avec succès" ,state:'message'});
        } else {
            await niveauescaladeService.updateByItem(data);
            // showInfo({ message: "Compte-rendu mis à jour avec succès" });
        }
        setSelectedNiveauEscalade(null);  // Réinitialise le compte rendu sélectionné
        rafraichirListeNiveauxEscalades();
    } catch (erreur) {
        console.error("Erreur lors de la sauvegarde du compte-rendu", erreur);
    }
};


  return (
 
    
    <React.Fragment>
    {/* <h2 className={'content-block'}>Niveaux Escalade</h2> */}

    <div className={'content-block dx-card responsive-paddings'}>
    <SegaDataGrid idName="bmA_ID" 
    type={createNiveauxEscaladeInstance} 
    dataSource={listeNiveauxEscalades} 
    ColumnDefinition={columnsDef} 
     canEdit={true}  canAdd={true} 
     onAdd={handleAdd}
   onRowClick={id => handleclick(id)}
   pageIndex={pageIndex}
   rowIndex={rowIndex}
   ></SegaDataGrid>
    </div>

    <div className={'content-block dx-card responsive-paddings'}>
    {selectedNiveauEscalade && (
                   <NiveauxEscaladeDetailPage
                       niveauxEscalade={selectedNiveauEscalade}
                       
                       onDel={handleDelete}
                       onSave={handleSave}
                       onCancel={handelCancel}
                   />
               )}
         {isLoading && <div>Loading...</div>}
    </div>
    </React.Fragment>
 

     
  )
} 

export default NiveauxEscaladePage;
