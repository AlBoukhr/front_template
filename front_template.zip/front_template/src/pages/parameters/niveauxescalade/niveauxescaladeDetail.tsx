import React, { useEffect, useMemo, useState } from "react";
import 'devextreme-react/text-area';
import { Button, SelectBox, TextArea, TextBox } from "devextreme-react";
import {  ValeurService  } from "../../../services/valeurService";
import { NiveauxEscalade } from '../../../models/NiveauxEscalade'; 
import { Valeur } from '../../../models/Valeur'; 
import { axiosInstance } from '../../../services/configaxios'; 

interface NiveauxEscaladeDetailPageProps {
    niveauxEscalade: NiveauxEscalade | null;
    onSave: (data: NiveauxEscalade) => Promise<void>; 
    onDel :(id: number) => Promise<void>;
    onCancel: () => void;
}

const NiveauxEscaladeDetailPage: React.FC<NiveauxEscaladeDetailPageProps> = ({ niveauxEscalade, onSave, onDel, onCancel }) => {
    const   valeurService =    useMemo(() => new ValeurService(axiosInstance), []);

    const [state, setState] = useState<NiveauxEscalade>(niveauxEscalade || {
        bmA_OFR_COM: '',
        bmA_NIV: '',
        bmA_NAT_LIE: '',
        bmA_ADR_MAIL: '',
        bmA_ADR_CCI: '',
        bmA_TITRE: '',
        bmA_OBJET: '',
        bmA_TEXTE: '',
    });

    const [selectData, setSelectData] = useState<{ [key: string]: Valeur[] | null }>({
        ofrcom: null,
        nivesc: null,
        natsga: null,
        natgnr: null,
        natlie: null,
        natfto: null,
        natfte: null,
    });

    const [filteredNatLieData, setFilteredNatLieData] = useState<Valeur[] | null>(null);
    const [isNatLieVisible, setIsNatLieVisible] = useState<boolean>(true);

    useEffect(() => {
        const chargerListes = async () => {
            try {
                const ofrcomData = await valeurService?.getOneList("OFRCOM");
                const nivescData = await valeurService?.getOneList("NIVESC");
                const natsgaData = await valeurService?.getOneList("NATSGA");
                const natgnrata = await valeurService?.getOneList("NATGNR");
                const natlieData = await valeurService?.getOneList("NATLIE");
                const natftoData = await valeurService?.getOneList("NATFTO");
                const natfteData = await valeurService?.getOneList("NATFTE");
                setSelectData({
                    ofrcom: ofrcomData || [],
                    nivesc: nivescData || [],
                    natsga: natsgaData || [],
                    natgnr: natgnrata || [],
                    natlie: natlieData || [],
                    natfto: natftoData || [],
                    natfte: natfteData || [],
                });
            } catch (erreur) {
                console.error("Erreur lors du chargement de la liste", erreur);
            }
        };
        chargerListes();
    }, [valeurService]);

    useEffect(() => {
        if (niveauxEscalade) {
            setState(niveauxEscalade);
        }
    }, [niveauxEscalade]);

    const handleChange = async (field: keyof NiveauxEscalade, value: any) => {
      if (field === 'bmA_OFR_COM') {
          // Mettre à jour filteredNatLieData en fonction de bmA_OFR_COM
          let updatedFilteredNatLieData;
          switch (value) {
              case 'DSL':
                  updatedFilteredNatLieData = selectData.natlie;
                  setIsNatLieVisible(true);
                  break;
              case 'VGA':
              case 'FTH':
              case 'DSP':
                  // Hide selection bmA_NAT_LIE
                  setIsNatLieVisible(false);
                  break;
              case 'FTO':
                  updatedFilteredNatLieData = selectData.natfto;
                  setIsNatLieVisible(true);
                  break;
              case 'FTE':
                  updatedFilteredNatLieData = selectData.natfte;
                  setIsNatLieVisible(true);
                  break;
              case 'GNR':
                  updatedFilteredNatLieData = selectData.natgnr;
                  setIsNatLieVisible(true);
                  break;
              // ajout d'autres cas au besoin
              default:
                  updatedFilteredNatLieData = selectData.natsga;
                  setIsNatLieVisible(true);
          }
          setFilteredNatLieData(updatedFilteredNatLieData || []);
      }

      setState(prevState => ({
          ...prevState,
          [field]: value
      }));
  };

  
  const isFieldRequired = (field: keyof NiveauxEscalade): boolean => {
    // Logique pour déterminer si le champ est requis
    // Par exemple, vous pouvez définir certains champs comme requis selon l'offre commerciale sélectionnée
    switch (field) {
        case 'bmA_OFR_COM':
        case 'bmA_NAT_LIE':
        case 'bmA_NIV':
          case 'bmA_TITRE':
            case 'bmA_OBJET':
            case 'bmA_TEXTE':
            return true;
        default:
            return false;
    }
};


    if (!niveauxEscalade) {
        return <div>Sélectionnez un niveau d'escalade pour voir les détails</div>;
    }

    return (
        <React.Fragment>
            <div className="settings">
                <div className="column">
                    <div className="field">
                        <div className="value">
                            <SelectBox
                                dataSource={selectData.ofrcom}
                                value={state.bmA_OFR_COM}
                                valueExpr="codval"
                                displayExpr="libval"
                                text="Offre Commerciale"
                                onValueChanged={e => handleChange('bmA_OFR_COM', e.value)}
                                className={isFieldRequired('bmA_OFR_COM') ? 'required-field' : ''}
                                label="Offre Commerciale"
                            />
                        </div>
                    </div>
                    <div className="field">
                        <div className="value">
                            <SelectBox
                                dataSource={selectData.nivesc}
                                value={state.bmA_NIV}
                                valueExpr="codval"
                                displayExpr="libval"
                                text="Niveau Escalade"
                                onValueChanged={e => handleChange('bmA_NIV', e.value)}
                                className={isFieldRequired('bmA_NIV') ? 'required-field' : ''}
                                label="Niveau Escalade"
                            />
                        </div>
                    </div>
                </div>
                {isNatLieVisible && (
                <div className="column">
                    <div className="field">
                            <div className="value">
                                <SelectBox
                                    dataSource={filteredNatLieData}
                                    value={state.bmA_NAT_LIE}
                                    valueExpr="codval"
                                    displayExpr="libval"
                                    text="Nature Lien"
                                    onValueChanged={e => handleChange('bmA_NAT_LIE', e.value)}
                                    className={isFieldRequired('bmA_NAT_LIE') ? 'required-field' : ''}
                                    label="Nature Lien"
                                />
                            </div>
                       

                      
                    </div>
                </div> )}
            </div>

            <div className="bottom-row">
                <TextBox
                    className="full-width-input"
                    value={state.bmA_ADR_MAIL || ""}
                    onValueChanged={e => handleChange('bmA_ADR_MAIL', e.value)}
                    label="Adresse Mail"
                   
                />
                <TextBox
                    className="full-width-input"
                    value={state.bmA_ADR_CCI || ""}
                    onValueChanged={e => handleChange('bmA_ADR_CCI', e.value)}
                    label="CCI"
                />
                  
                <TextBox
                     className={`full-width-input ${isFieldRequired('bmA_TITRE') ? 'required-field' : ''}`}
                    value={state.bmA_TITRE || ""}
                    onValueChanged={e => handleChange('bmA_TITRE', e.value)}
                    label="Titre"
                />
                  
                <TextBox
                       className={`full-width-input ${isFieldRequired('bmA_OBJET') ? 'required-field' : ''}`}
                    value={state.bmA_OBJET || ""}
                    onValueChanged={e => handleChange('bmA_OBJET', e.value)}
                    label="Objet"
                />
                  
                <TextArea
                      className={`full-width-input ${isFieldRequired('bmA_TEXTE') ? 'required-field' : ''}`}
                    value={state.bmA_TEXTE || ""}
                    onValueChanged={e => handleChange('bmA_TEXTE', e.value)}
                    label="Texte"
                />
            </div>

            <div className="button-row">
                  <Button onClick={() => onDel(state.bmA_ID || -1)} icon="trash" hint="Supprimer"/>
                <Button onClick={() => onSave(state)} icon="save" hint="Enregistrer"/>
                <Button onClick={onCancel} icon="clear" hint="Annuler"/>
            </div>
        </React.Fragment>
    );
};

export default NiveauxEscaladeDetailPage;
