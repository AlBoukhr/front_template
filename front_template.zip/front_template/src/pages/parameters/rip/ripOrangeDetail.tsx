import React, { useEffect, useMemo, useState } from "react";
import 'devextreme-react/text-area';
import { Button, SelectBox,  TextBox } from "devextreme-react"; 
import { Rip } from "../../../models/Rip"; 
import { axiosInstance } from '../../../services/configaxios'; // Assurez-vous du bon chemin d'importation
import { ListsOperateurImmeubleService } from "../../../services/ListsService";
import { OperateurImmeuble } from "../../../models/OperateurImmeuble";

interface RipOrangeDetailPageProps {
    ripInterop: Rip | null;
    onSave: (data: Rip) => Promise<void>;
    
    onDel :(id: number) => Promise<void>;
    onCancel: () => void;
}

const RipOrangeDetailPage: React.FC<RipOrangeDetailPageProps> = ({ ripInterop, onSave,onDel, onCancel }) => {
    
    const [state, setState] = useState<Rip>(ripInterop || {
        riP_ID: -1,
        codE_OI: "",
        codE_PROD: "",
        lab: "",
        controle: "",
    });
 

    const   listsService = useMemo(()=> new ListsOperateurImmeubleService(axiosInstance), []);  
    const [operateurimmeubleListe, setoperateurimmeubleListe] = useState<OperateurImmeuble[] | null>(null);

    useEffect(() => {
        const chargerListes = async () => {
            try {
                
                setoperateurimmeubleListe(await listsService.getOperateurImmeuble());

            } catch (erreur) {
                console.error("Erreur lors du chargement de la liste", erreur);
            }
        };
        chargerListes();
    }, [listsService]);
   
 

    useEffect(() => {
        if (ripInterop) {
            setState(ripInterop);
        }
    }, [ripInterop]);

    const handleChange = async (field: keyof Rip, value: any) => {
    

      setState(prevState => ({
          ...prevState,
          [field]: value
      }));
  };
  
  


    if (!ripInterop) {
        return <div>Sélectionnez un niveau d'escalade pour voir les détails</div>;
    }

    return (
        <React.Fragment>
            <div className="settings">
                <div className="column">
                    <div className="field">
                        <div className="value">
                            <SelectBox
                                dataSource={operateurimmeubleListe}
                                value={state.codE_OI}
                                  valueExpr="moD_OPR_COD"
                                displayExpr="moD_OPR_LIB"
                                text="OI"
                                onValueChanged={e => handleChange('codE_OI', e.value)}
                                label="OI"
                               
                            />
                        </div>
                    </div>

                    <div className="field">

                   
    <div className="value">
        <TextBox
           
           value={  state.codE_PROD   || ""}
            onValueChanged={e => handleChange('codE_PROD', e.value)}
        label="Code Produit"
        />
    </div>
</div>

                    
                </div>
                
                <div className="column">
                <div className="field">

                   
    <div className="value">
        <TextBox
           
           value= { state.lab  || ""}
            onValueChanged={e => handleChange('lab', e.value)} 
            label="Label"
        />
    </div>



</div>
<div className="field">

    <div className="value">
        <TextBox
           
           value={  state.controle || ""}
            onValueChanged={e => handleChange('controle', e.value)} 
            label="Contrôle"
        />
    </div>



</div>
                    
                </div> 
                  
                 </div>
 

            <div className="button-row"> 
                 <Button onClick={() => onDel(state.riP_ID || -1)} icon="trash" hint="Supprimer"/>
                <Button onClick={() => onSave(state)} icon="save" hint="Enregistrer"/>
                <Button onClick={onCancel} icon="clear" hint="Annuler"/>
                
            </div>
        </React.Fragment>
    );
};

export default RipOrangeDetailPage;
