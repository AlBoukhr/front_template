 
  
import { axiosInstance } from '../../../services/configaxios'; // Assurez-vous du bon chemin d'importation

  
import { Rip } from '../../../models/Rip' 
 
import React, { useCallback, useEffect, useMemo, useState } from "react";
 
import SegaDataGrid from "../../../components/segadevextreme/datagrid"; 
import { ColumnDefinition } from "../../../components/interfaces"; 
import {  RipOrangeService  } from "../../../services/RipOrangeService";
 
import RipOrangeDetailPage from './ripOrangeDetail';
function RipOrangePage() {
     
  const [listeRips, setlisteRips] = React.useState<Rip[] | null>(null)
  const riporangeService  = useMemo(() => new RipOrangeService(axiosInstance), []);  
  const [isLoading, setIsLoading] = React.useState<boolean>(false)
  const [selectedItem, setSelectedItem] = React.useState<Rip | null>(null);  // Nouvel état
  const [pageIndex, setPageIndex] = useState<number | undefined>();
  const [rowIndex, setRowIndex] = useState<number | undefined>();
  
   
  const rafraichirListeRips  =   useCallback(async () => {
    try {
      setIsLoading(true) 
      setlisteRips(await riporangeService.getSpecificData("GetRipOrange"));
    } catch (e) {
      console.error('Erreur lors du chargement des données', e)
     
    } finally {
      setIsLoading(false)
    }
  },[riporangeService])

  

  
  useEffect(() => {
    
    
    rafraichirListeRips(); // Appel de la fonction au montage du composant
   setSelectedItem(createRipInstance());
 }, [  rafraichirListeRips]); // Le tableau vide [] indique que l'effet ne dépend d'aucune variable et ne s'exécutera qu'une fois

   
 useEffect(() => {
   if (listeRips && listeRips.length > 0) {
     setSelectedItem(listeRips[0]);
   }
 }, [listeRips]);

  
 

  function createRipInstance() {
    return {
    riP_ID: -1,
    codE_OI: "",
    codE_PROD: "",
    lab: "",
    controle: "",
  } as unknown as Rip;
}
  

 

  const columnsDef : ColumnDefinition[]= [
    { visible :true , caption: 'OI', name: 'codE_OI', required: true, typeField:'text'},
    { visible :true, caption: 'Code Produit', name: 'codE_PROD', editable: true, typeField:'text' },
    { visible :true ,caption: 'Label', name: 'lab', required: true , typeField:'text'}, 
    { visible :true ,caption: 'Contrôle', name: 'controle', editable: true , typeField:'text'},
    
  ];
 

  const handleAdd = async () => {
    try {
      const newItem = createRipInstance();
      setlisteRips((prevListe) => {
        const updatedList = prevListe ? [...prevListe, newItem] : [newItem];
        return updatedList;
      }); 

      const newSelected = listeRips ? listeRips[(listeRips.length ?? 0) - 1] : null;
      setSelectedItem(newSelected);
      setPageIndex(Math.floor(((listeRips?.length ?? 0) - 1) / 10));  // page size  10
      setRowIndex((listeRips?.length ?? 0) - 1);

    } catch (error) {
      console.error('Erreur lors de la création', error)
      // Gérer l'erreur ici
    }
  };
 
   
  

  // Handler pour la suppression
  const handleDelete = async (id: number) => {
    try {
      await riporangeService.remove('RIP_ID',id);
      rafraichirListeRips();
    } catch (error) {
      // Gérer l'erreur ici
    }
  };


  const handleSave = async (data: Rip) => {
    try {
        if (data.riP_ID === -1) {
            await riporangeService.create(data);
            // showInfo({ message: "Compte-rendu créé avec succès" ,state:'message'});
        } else {
            await riporangeService.update(data.riP_ID || -1 , data);
            // showInfo({ message: "Compte-rendu mis à jour avec succès" });
        }
        setSelectedItem(null);  // Réinitialise le compte rendu sélectionné
        rafraichirListeRips();
    } catch (erreur) {
        console.error("Erreur lors de la sauvegarde du compte-rendu", erreur);
    }
};

function handelCancel(): void {
  setPageIndex(undefined);
  setRowIndex(undefined);
  rafraichirListeRips();
}
const handleclick = async (id: number) => {
    
  const ret = listeRips?.find(cr => cr.riP_ID === id);
  if (ret) {
    setSelectedItem(ret);
      console.info('rip interop actuel ',ret.riP_ID )
  }
};
  return (
    
    <React.Fragment>
    
    <div className={'content-block dx-card responsive-paddings'}>
    <SegaDataGrid
     idName="riP_ID" 
     type={createRipInstance} 
     dataSource={listeRips}
      ColumnDefinition={columnsDef}
      canEdit={true} canAdd={true}
     onRowClick={(id) => handleclick(id)}
     onAdd={handleAdd} />
        pageIndex={pageIndex}
        rowIndex={rowIndex}
    </div>

    <div className={'content-block dx-card responsive-paddings'}>
    {selectedItem && (
               <RipOrangeDetailPage
                   ripInterop={selectedItem}
                   onSave={handleSave} 
                   onDel={handleDelete}
                   onCancel={handelCancel}
               />
           )}
         {isLoading && <div>Loading...</div>}
    </div>
    </React.Fragment>
  
  )
} 

export default RipOrangePage;
