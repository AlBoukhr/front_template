 
import TabPanel, { Item } from "devextreme-react/tab-panel";
  
import React  from "react"; 
    // Assurez-vous du bon chemin d'importation
import RipInteropPage from "./ripInterop";
import RipOrangePage from "./ripOrange";



function RipPage() {
 

  return (

    <React.Fragment>
    {/* <h2 className={'content-block'}>RIP</h2> */}

    <div className={'content-block dx-card responsive-paddings'}>
     
     
        <TabPanel>
          
          <Item title="Rip Orange">
          <RipOrangePage/>
          </Item>
          <Item title="Rip Interop">
           <RipInteropPage/>
          </Item>
        </TabPanel>
      
    </div>

    
    </React.Fragment>

  );
}

export default RipPage;
