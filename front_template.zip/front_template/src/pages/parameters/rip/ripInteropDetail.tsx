import React, { useEffect, useMemo, useState } from "react";
import 'devextreme-react/text-area';
import { Button, SelectBox } from "devextreme-react"; 
import { RipInteropVersion } from "../../../models/RipInteropVersion";
import { axiosInstance } from '../../../services/configaxios'; // Assurez-vous du bon chemin d'importation
import { OperateurImmeuble } from "../../../models/OperateurImmeuble";
import { ListsOperateurImmeubleService } from "../../../services/ListsService";

interface RipInteropDetailPageProps {
    ripInterop: RipInteropVersion | null;
    onSave: (data: RipInteropVersion) => Promise<void>; 
    
    onDel :(id: number) => Promise<void>;
    onCancel: () => void;
}

const RipInteropDetailPage: React.FC<RipInteropDetailPageProps> = ({ ripInterop, onSave,onDel, onCancel }) => {
   
   
    const [state, setState] = useState<RipInteropVersion>(ripInterop || {
        riV_ID: -1,
    codE_OI: "",
    versioN_INTEROP: "",
    });

    
      
 
    const   listsService = useMemo(()=> new ListsOperateurImmeubleService(axiosInstance), []);  
    const [operateurimmeubleListe, setoperateurimmeubleListe] = useState<OperateurImmeuble[] | null>(null);

    useEffect(() => {
        const chargerListes = async () => {
            try {
                
                setoperateurimmeubleListe(await listsService.getOperateurImmeuble());

            } catch (erreur) {
                console.error("Erreur lors du chargement de la liste", erreur);
            }
        };
        chargerListes();
    }, [listsService]);

    useEffect(() => {
        if (ripInterop) {
            setState(ripInterop);
        }
    }, [ripInterop]);

    const handleChange = async (field: keyof RipInteropVersion, value: any) => {
    

      setState(prevState => ({
          ...prevState,
          [field]: value
      }));
  };
  
  


    if (!ripInterop) {
        return <div>Sélectionnez un niveau d'escalade pour voir les détails</div>;
    }

    return (
        <React.Fragment>
            <div className="settings">
                <div className="column">
                    <div className="field">
                        <div className="value">
                            <SelectBox
                                dataSource={operateurimmeubleListe}
                                value={state.codE_OI}
                                valueExpr="moD_OPR_COD"
                                displayExpr="moD_OPR_LIB"
                                text="OI"
                                onValueChanged={e => handleChange('codE_OI', e.value)}
                                label="OI"
                               
                            />
                        </div>
                    </div>
                    
                </div>
                
                <div className="column">
                    <div className="field">

                            <div className="value">
                                <SelectBox
                                    dataSource={operateurimmeubleListe}
                                    value={state.versioN_INTEROP}
                                    valueExpr="codval"
                                    displayExpr="libval"
                                    text="Version de Flux"
                                    onValueChanged={e => handleChange('versioN_INTEROP', e.value)}
                                    label="Version de Flux"
                                     
                                />
                            </div>
                       

                      
                    </div>
                    
                </div> 
                  
                 </div>
 

            <div className="button-row">
                  <Button onClick={() => onDel(state.riV_ID || -1)} icon="trash" hint="Supprimer"/>
                <Button onClick={() => onSave(state)} icon="save" hint="Enregistrer"/>
                <Button onClick={onCancel} icon="clear" hint="Annuler"/>
            </div>
        </React.Fragment>
    );
};

export default RipInteropDetailPage;
