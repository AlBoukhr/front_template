 
 
 
import { axiosInstance } from '../../../services/configaxios'; // Assurez-vous du bon chemin d'importation

  
import { RipInteropVersion } from '../../../models/RipInteropVersion' 
 
import React, { useCallback, useEffect, useMemo, useState } from "react"; 
 
import SegaDataGrid from "../../../components/segadevextreme/datagrid"; 
import { ColumnDefinition } from "../../../components/interfaces"; 
import {  RipInteropService  } from "../../../services/RipInteropService";
  
import RipInteropDetailPage from './ripInteropDetail'; 

function RipInteropPage() {
    
  const [listeRipInterops, setlisteRipInterops] = React.useState<RipInteropVersion[] | null>(null)
  const ripInteropService  =   useMemo(() => new RipInteropService(axiosInstance), []);  
  const [isLoading, setIsLoading] = React.useState<boolean>(false)
  const [selectedItem, setSelectedItem] = React.useState<RipInteropVersion | null>(null);  // Nouvel état
  const [pageIndex, setPageIndex] = useState<number | undefined>();
  const [rowIndex, setRowIndex] = useState<number | undefined>();
  


  
  const rafraichirListeRipInterops =   useCallback(async () => {
    try {
      setIsLoading(true) 
      setlisteRipInterops(await ripInteropService.getSpecificData("GetRipInteropVersion"))
    } catch (e) {
      console.error('Erreur lors du chargement des données', e)
     
    } finally {
      setIsLoading(false)
    }
  },[ripInteropService])
 
  useEffect(() => { 
    rafraichirListeRipInterops(); // Appel de la fonction au montage du composant
    setSelectedItem(createRipInteropInstance());
  }, [rafraichirListeRipInterops]); // Le tableau vide [] indique que l'effet ne dépend d'aucune variable et ne s'exécutera qu'une fois
  
  useEffect(() => {
    if (listeRipInterops && listeRipInterops.length > 0) {
      setSelectedItem(listeRipInterops[0]);
    }
  }, [listeRipInterops]);
 
 
  function createRipInteropInstance() {
    return {
    riV_ID: -1,
    codE_OI: "",
    versioN_INTEROP: "",
  } as unknown as RipInteropVersion;
} 

  const columnsDef : ColumnDefinition[]= [
    { visible :true , caption: 'OI', name: 'codE_OI', required: true, typeField:'text'}, 
    { visible :true ,caption: 'Version Flux', name: 'versioN_INTEROP', editable: true , typeField:'text'}, 
  ];
  

  const handleAdd = async () => {
    try {
      const newItem = createRipInteropInstance();
      setlisteRipInterops((prevListe) => {
        const updatedList = prevListe ? [...prevListe, newItem] : [newItem];
        return updatedList;
      }); 

      const newSelected = listeRipInterops ? listeRipInterops[(listeRipInterops.length ?? 0) - 1] : null;
      setSelectedItem(newSelected);
      setPageIndex(Math.floor(((listeRipInterops?.length ?? 0) - 1) / 10));  // page size  10
      setRowIndex((listeRipInterops?.length ?? 0) - 1);


    } catch (error) {
      console.error('Erreur lors de la création', error)
      // Gérer l'erreur ici
    }
  };
 
  function handelCancel(): void {
    setPageIndex(undefined);
    setRowIndex(undefined);
    rafraichirListeRipInterops();
  }


  // Handler pour la suppression
  const handleDelete = async (id: number) => {
    try {
      await ripInteropService.remove('RET_ID',id);
      rafraichirListeRipInterops();
    } catch (error) {
      // Gérer l'erreur ici
    }
  };

  const handleSave = async (data: RipInteropVersion) => {
    try {
        if (data.riV_ID === -1) {
            await ripInteropService.create(data);
            // showInfo({ message: "Compte-rendu créé avec succès" ,state:'message'});
        } else {
            await ripInteropService.update(data.riV_ID || -1 , data);
            // showInfo({ message: "Compte-rendu mis à jour avec succès" });
        }
        setSelectedItem(null);  // Réinitialise le compte rendu sélectionné
        rafraichirListeRipInterops();
    } catch (erreur) {
        console.error("Erreur lors de la sauvegarde du compte-rendu", erreur);
    }
};

  
const handleclick = async (id: number) => {
    
  const ret = listeRipInterops?.find(cr => cr.riV_ID === id);
  if (ret) {
    setSelectedItem(ret);
      console.info('rip interop actuel ',ret.riV_ID )
  }
};

  return (
     
    <React.Fragment>
      
    <div className={'content-block dx-card responsive-paddings'}>
    <SegaDataGrid idName="riV_ID"
     type={createRipInteropInstance} 
    dataSource={listeRipInterops} 
    ColumnDefinition={columnsDef}  
     canEdit={true}  
     onAdd={handleAdd} canAdd={true}
   onRowClick={(id) => handleclick (id)}/> 
           pageIndex={pageIndex}
           rowIndex={rowIndex} 
    </div>

    <div className={'content-block dx-card responsive-paddings'}>
    {selectedItem && (
               <RipInteropDetailPage
                   ripInterop={selectedItem}
                   onSave={handleSave}
                
                   onDel={handleDelete}
                   onCancel={handelCancel}
               />
           )}
         {isLoading && <div>Loading...</div>}
    </div>
    </React.Fragment>


    
        
    
 
  )
} 

export default RipInteropPage;
