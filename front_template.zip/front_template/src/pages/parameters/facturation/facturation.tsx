// FacturationPage.tsx
import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import SegaDataGrid  from "../../../components/segadevextreme/datagrid";
import { FacturationsService } from "../../../services/FacturationsService";
import { Facturation } from '../../../models/Facturation';
import FacturationDetailPage from "./facturationDetail";
import { axiosInstance } from '../../../services/configaxios';
import { ColumnDefinition } from "../../../components/interfaces";
import dxDataGrid from 'devextreme/ui/data_grid';
import {  ListsOperateurImmeubleService  } from "../../../services/ListsService";

import {  ValeurService  } from "../../../services/valeurService"; 
import { Valeur } from "../../../models/Valeur";
import { OperateurImmeuble } from "../../../models/OperateurImmeuble"; 

function FacturationPage() {
  const [listeFacturations, setListeFacturations] = useState<Facturation[] | null>(null);
  const facturationService = useMemo(() => new FacturationsService(axiosInstance), []);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [selectedFacturation, setSelectedFacturation] = useState<Facturation | null>(null); 
   
  const valeurService = useMemo(() => new ValeurService(axiosInstance), []);
  const listsService = useMemo(() => new ListsOperateurImmeubleService(axiosInstance), []);
  const [operateurimmeubleListe, setoperateurimmeubleListe] = useState<OperateurImmeuble[] | null>(null);
  const [selectData, setSelectData] = useState<{ [key: string]: Valeur[] | null }>({
    ofrcom: null
  });
  const [pageIndex, setPageIndex] = useState<number | undefined>();
  const [rowIndex, setRowIndex] = useState<number | undefined>();

  const rafraichirListeFacturations = useCallback(async () => {
    try {
      setIsLoading(true);
      setListeFacturations(await facturationService.getAll());
    } catch (e) {
      console.error('Erreur lors du chargement des données', e);
    } finally {
      setIsLoading(false);
    }
  }, [facturationService]);

  useEffect(() => {
    rafraichirListeFacturations();
    setSelectedFacturation(createFacturationInstance());
  }, [rafraichirListeFacturations]);

  useEffect(() => {
    if (listeFacturations && listeFacturations.length > 0) {
      ;
      setSelectedFacturation(listeFacturations[0] || null); 
    }
  }, [listeFacturations]);
 
  
  


  useEffect(() => {
    const chargerListes = async () => {
      try {
        setSelectData({
          ofrcom: await valeurService.getOneList("OFRCOM"),
        });
        setoperateurimmeubleListe(await listsService.getOperateurImmeuble());
      } catch (erreur) {
        console.error("Erreur lors du chargement de la liste", erreur);
      }
    };
    chargerListes();
  }, [valeurService, listsService]);

  function createFacturationInstance() {
    return {
      faC_CODE_OI: "",
      faC_DAT_CRE: null,
      faC_DAT_MDF: null,
      faC_DFT: -1,
      faC_ID: -1,
      faC_LGI_CRE: -1,
      faC_LGI_MDF: -1,
      faC_NEW: -1,
      faC_NUM: "",
      faC_OFR: "",
      faC_PRE: -1,
    } as unknown as Facturation;
  }

  const columnsDef: ColumnDefinition[] = [
    { visible: true, caption: 'N° Facturation', name: 'faC_NUM', required: true, typeField: 'text' },
    { visible: true, caption: 'Compte Par Défaut', name: 'faC_DFT', editable: true, typeField: 'checkbox' },
    { visible: true, caption: 'Nouveau Compte', name: 'faC_NEW', required: true, typeField: 'checkbox' },
    { visible: true, caption: 'Prélévement', name: 'faC_PRE', editable: true, typeField: 'checkbox' },
    { visible: true, caption: 'Offre', name: 'faC_OFR', editable: true, typeField: 'lookup', options: selectData.ofrcom, optionValueField: "codval", optionLabelField: "libval" },
    { visible: true, caption: 'OI', name: 'faC_CODE_OI', editable: true, typeField: 'lookup', options: operateurimmeubleListe, optionValueField: "moD_OPR_COD", optionLabelField: "moD_OPR_LIB" },
  ];

  const handleRowClick = async (id: number) => {
    const facturation = listeFacturations?.find(f => f.faC_ID === id);
    if (facturation) {
      setSelectedFacturation(facturation);
      const rowIndex = listeFacturations ? listeFacturations.indexOf(facturation) : -1;
   
    }
  };

   

  const handleAdd = async () => {
    try {
      const newItem = createFacturationInstance();
      setListeFacturations((prevListe) => {
        const updatedList = prevListe ? [...prevListe, newItem] : [newItem];
        return updatedList;
      }); 

      const newSelected = listeFacturations ? listeFacturations[(listeFacturations.length ?? 0) - 1] : null;
      setSelectedFacturation(newSelected);
      setPageIndex(Math.floor(((listeFacturations?.length ?? 0) - 1) / 10));  // page size  10
      setRowIndex((listeFacturations?.length ?? 0) - 1);


    } catch (error) {
      console.error('Erreur lors de la création', error)
      // Gérer l'erreur ici
    }
  };


  function handelCancel(): void {
    setPageIndex(undefined);
    setRowIndex(undefined);
    rafraichirListeFacturations();
  }


  const handleSave = async (data: Facturation) => {
    try {
      if (data.faC_ID === -1 || data.faC_ID === undefined) {
        await facturationService.create(data);
      } else {
        await facturationService.updateByItem(data);
      }
      rafraichirListeFacturations();
      
      setSelectedFacturation(null);
    } catch (erreur) {
      console.error("Erreur lors de la sauvegarde du paramètre", erreur);
    }
  };

  const handleDelete = async (id: number) => {
    try {
      await facturationService.remove('FAC_ID',id);
      rafraichirListeFacturations(); 
      setSelectedFacturation(null);
    } catch (error) {
      console.error('Erreur lors de la suppression', error);
    }
  };

  return (
    <React.Fragment>
      {/* <h2 className={'content-block'}>Facturation</h2> */}
      <div className={'content-block dx-card responsive-paddings'}>
        <SegaDataGrid 
          idName="faC_ID"
          type={createFacturationInstance}
          dataSource={listeFacturations}
          onRowClick={handleRowClick}
          ColumnDefinition={columnsDef}
          canEdit={true} 
          canAdd={true}
          onAdd={handleAdd}
          pageIndex={pageIndex}
          rowIndex={rowIndex}
        />
      </div>
      <div className={'content-block dx-card responsive-paddings'}>
        {selectedFacturation && (
          <FacturationDetailPage
            facturation={selectedFacturation}
            onSave={handleSave}
            onDel={handleDelete}
            onCancel={handelCancel}
          />
        )}
        {isLoading && <div>Loading...</div>}
      </div>
    </React.Fragment>
  );
}

export default FacturationPage;
