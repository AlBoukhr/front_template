import React, { useEffect, useMemo, useState } from "react";
import 'devextreme-react/text-area';
import { Button, CheckBox, SelectBox, TextBox } from "devextreme-react";
import {  ListsOperateurImmeubleService  } from "../../../services/ListsService";

import {  ValeurService  } from "../../../services/valeurService";
import { Facturation } from '../../../models/Facturation';
import { Valeur } from "../../../models/Valeur";
import { OperateurImmeuble } from "../../../models/OperateurImmeuble"; 
import { axiosInstance } from '../../../services/configaxios'; 
  

interface FacturationDetailPageProps {
  facturation: Facturation;
  onSave: (data: Facturation) => Promise<void>;
   
  onDel :(id: number) => Promise<void>;
  onCancel: () => void;
}

const FacturationDetailPage: React.FC<FacturationDetailPageProps> = ({ facturation, onSave,onDel, onCancel }) => {  
  const   valeurService = useMemo(()=> new ValeurService(axiosInstance),[]);
  const   listsService =  useMemo(()=>new ListsOperateurImmeubleService(axiosInstance),[]);

  const [isOIVisible, setIsOIVisible] = useState<boolean>(facturation.faC_OFR === 'FTE'); // Initialiser avec la bonne valeur
  const [operateurimmeubleListe, setoperateurimmeubleListe] = useState<OperateurImmeuble[] | null>(null);
  const [state, setState] = useState<Facturation>(facturation);

  const [selectData, setSelectData] = useState<{ [key: string]: Valeur[] | null }>({
    ofrcom: null
  });

  
  useEffect(() => {
    if (facturation) {
      setState(facturation);
      // Mettre à jour les filtres lorsque l'instance sélectionnée change
     
    }
  }, [facturation]);


  useEffect(() => {
    const chargerListes = async () => {
      try {
        setSelectData({
          ofrcom: await valeurService.getOneList("OFRCOM"),
        });
        setoperateurimmeubleListe(await listsService.getOperateurImmeuble());
      } catch (erreur) {
        console.error("Erreur lors du chargement de la liste", erreur);
      }
    };
    chargerListes();
  }, [valeurService, listsService]);

  const handleChange = (field: keyof Facturation, value: any) => {
    if (field === 'faC_OFR') {
      setIsOIVisible(value === 'FTE');
    }
    setState(prevState => ({
      ...prevState,
      [field]: value
    }));
  };



  const isFieldRequired = (field: keyof Facturation): boolean => {
    switch (field) {
      case 'faC_NUM':
      case 'faC_DFT':
      case 'faC_PRE':
      case 'faC_NEW':
        return true;
      default:
        return false;
    }
  };

  return (
    <React.Fragment>
      <div className="settings">
        <div className="column">
          <div className="field">
            <div className="value">
              <TextBox label="N° Facturation"
                value={state.faC_NUM || ""}
                onValueChanged={e => handleChange('faC_NUM', e.value)}
                className={isFieldRequired('faC_NUM') ? 'required-field' : ''}
              />
            </div>
          </div>
          <div className="field">
            <div className="label">Compte Par Défaut</div>
            <div className="value">
              <div className={isFieldRequired('faC_DFT') ? 'required-field-checkbox' : ''}>
                <CheckBox
                  value={state.faC_DFT === 1}
                  onValueChanged={e => handleChange('faC_DFT', e.value ? 1 : 0)}
                  text="" // Assurez-vous que la propriété `text` est vide
                />
              </div>
            </div>
          </div>
        </div>
        <div className="column">
          <div className="field">
            <div className="value">
              <SelectBox
                dataSource={selectData.ofrcom}
                value={state.faC_OFR}
                valueExpr="codval"
                displayExpr="libval"
                onValueChanged={e => handleChange('faC_OFR', e.value)}
                className={isFieldRequired('faC_OFR') ? 'required-field' : ''}
                label='Offre'
              />
            </div>
          </div>
          <div className="field">
            <div className="label">Prélévement</div>
            <div className="value">
              <div className={isFieldRequired('faC_PRE') ? 'required-field-checkbox' : ''}>
                <CheckBox
                  value={state.faC_PRE === 1}
                  onValueChanged={e => handleChange('faC_PRE', e.value ? 1 : 0)}
                  text="" // Assurez-vous que la propriété `text` est vide
                />
              </div>
            </div>
          </div>
        </div>
        <div className="column">
          {isOIVisible && (
            <div className="field">
              <div className="value">
                <SelectBox
                  dataSource={operateurimmeubleListe}
                  value={state.faC_CODE_OI}
                    valueExpr="moD_OPR_COD"
                                displayExpr="moD_OPR_LIB"
                  onValueChanged={e => handleChange('faC_CODE_OI', e.value)}
                  className={isFieldRequired('faC_CODE_OI') ? 'required-field' : ''}
                  label="OI"
                />
              </div>
            </div>
          )}
          <div className="field">
            <div className="label">Nouveau Compte</div>
            <div className="value">
              <div className={isFieldRequired('faC_NEW') ? 'required-field-checkbox' : ''}>
                <CheckBox
                  value={state.faC_NEW === 1}
                  onValueChanged={e => handleChange('faC_NEW', e.value ? 1 : 0)}
                  text="" // Assurez-vous que la propriété `text` est vide
                />
              </div>
            </div>
          </div>
        </div>
        </div>
        <div className="button-row">
                   <Button onClick={() => onDel(state.faC_ID || -1)} icon="trash" hint="Supprimer"/>
                <Button onClick={() => onSave(state)} icon="save" hint="Enregistrer"/>
                <Button onClick={onCancel} icon="clear" hint="Annuler"/>
            </div>
     
    </React.Fragment>
  );
};

export default FacturationDetailPage;
