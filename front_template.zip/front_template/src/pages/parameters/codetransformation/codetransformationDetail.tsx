import React, { useEffect, useState,useMemo  } from "react";
import 'devextreme-react/text-area';
import {  Button, SelectBox, TextArea } from "devextreme-react";
import {  ValeurService  } from "../../../services/valeurService";
import { CodeTransformation } from "../../../models/CodeTransformation";
import { Valeur } from "../../../models/Valeur"; 
import { axiosInstance } from '../../../services/configaxios'; // Assurez-vous du bon chemin d'importation

interface CodeTransformationDetailPageProps {
  codetransformation: CodeTransformation | null;
  onSave: (data: CodeTransformation) => Promise<void>; 
  onDel :(id: number) => Promise<void>;
  onCancel: () => void;
}

 

const CodeTransformationDetailPage: React.FC<CodeTransformationDetailPageProps> = ({ codetransformation, onSave,onDel, onCancel }) => {
 
  const valeurService = useMemo(() => new ValeurService(axiosInstance), []);
  const [state, setState] = useState<CodeTransformation | null>(codetransformation);

  const [selectData, setSelectData] = useState<{ [key: string]: Valeur[] | null }>({
    tranvg: null ,ordvga : null
  });
  
  
 


  // Mettre à jour l'état local lorsque les props changent
  useEffect(() => {
    const valeurService = new ValeurService(axiosInstance);
    setState(codetransformation);
    
    const chargerListes = async () => {
      try {
        const newSelectData = {
          tranvg: await valeurService.getOneList("TRANVG"),
          ordvga: await valeurService.getOneList("ORDVGA"),
        
        };
        setSelectData(newSelectData);
        
       
      } catch (erreur) {
        console.error("Erreur lors du chargement de la liste", erreur);
      }
    };
    chargerListes();
  }, [valeurService,  codetransformation]);

  const handleChange = async (field: keyof CodeTransformation, value: any) => {
    setState(prevState => prevState ? ({ ...prevState, [field]: value }) : null);

   
  };

  const isFieldRequired = (field: keyof CodeTransformation): boolean => {
    switch (field) {
      case 'traN_VG_COD':
        case 'cmD_ORD_COD': 
        case 'traN_VG_CMT': 
        
        return true;
      default:
        return false;
    }
  };

  if (!state) {
    return <div>Sélectionnez un compte-rendu pour voir les détails</div>;
  }

  return (
    <React.Fragment>
      <div className="settings">
        <div className="column">
          <div className="field">
            <div className="value">
            <SelectBox
                dataSource={selectData.ordvga}
                value={state.cmD_ORD_COD}
                valueExpr="codval"
                displayExpr="libval"
                text="Operateur"
                onValueChanged={e => handleChange('cmD_ORD_COD', e.value)}
                className={isFieldRequired('cmD_ORD_COD') ? 'required-field' : ''}
                label="Ordre"
              />
            </div>
          </div>
          <div className="field">
            <div className="value">
              <SelectBox
                dataSource={selectData.tranvg}
                value={state.traN_VG_COD}
                valueExpr="codval"
                displayExpr="libval"
                text="Operateur"
                onValueChanged={e => handleChange('traN_VG_COD', e.value)}
                className={isFieldRequired('traN_VG_COD') ? 'required-field' : ''}
                label="Code Transformation"
              />
            </div>
          </div>
        </div> 
       
      </div>
      <div className="bottom-row">
        <TextArea
          className={isFieldRequired('traN_VG_CMT') ? 'full-width-input required-field' : 'full-width-input'}
          value={state.traN_VG_CMT || ""}
          onValueChanged={e => handleChange('traN_VG_CMT', e.value)}
          label="Commentaire"
        />
      </div>
      <div className="button-row">
                  <Button onClick={() => onDel(state.ctV_ID ||  -1)} icon="trash" hint="Supprimer"/>
                <Button onClick={() => onSave(state)} icon="save" hint="Enregistrer"/>
                <Button onClick={onCancel} icon="clear" hint="Annuler"/>
            </div>
    </React.Fragment>
  );
};

export default CodeTransformationDetailPage;
