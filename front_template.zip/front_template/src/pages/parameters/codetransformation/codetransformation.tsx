 
 
import { CodesTransformationsService } from "../../../services/CodesTransformationsService";
import { CodeTransformation } from '../../../models/CodeTransformation'  
import { axiosInstance } from '../../../services/configaxios'; // Assurez-vous du bon chemin d'importation

  
import React, { useCallback, useEffect, useMemo, useState } from "react"; 
import SegaDataGrid from "../../../components/segadevextreme/datagrid";
import { ColumnDefinition } from "../../../components/interfaces";
import CodeTransformationDetailPage from "./codetransformationDetail";

function CodeTransformationPage() {
    
  const [listeCodeTransformations, setlisteCodeTransformations] = React.useState<CodeTransformation[] | null>(null)
   const codeTransformationService = useMemo(() => new CodesTransformationsService(axiosInstance), []);
  const [isLoading, setIsLoading] = React.useState<boolean>(false)
   
  const [selectedCodeTransformation, setSelectedCodeTransformation] = React.useState<CodeTransformation | null>(null);
  const [pageIndex, setPageIndex] = useState<number | undefined>();
  const [rowIndex, setRowIndex] = useState<number | undefined>();
  
  useEffect(() => {
    if (listeCodeTransformations && listeCodeTransformations.length > 0) {
      setSelectedCodeTransformation(listeCodeTransformations[0]);
    }
  }, [listeCodeTransformations]);

  function createCodeTransformationInstance() {
    return {
      CTV_ID:-1,
      cmD_ORD_COD: "",
      traN_VG_COD: "",
      traN_VG_CMT: "",
      cmD_ORD_LBL: "",
      traN_VG_LBL: "",
       
    } as unknown as CodeTransformation;
  }

   

 

  const columnsDef : ColumnDefinition[]= [
    { visible :true , caption: 'Code Transformation', name: 'traN_VG_LBL', required: true, typeField:'text'},
    { visible :true, caption: 'Ordre', name: 'cmD_ORD_LBL', editable: true, typeField:'text' },
    { visible :true ,caption: 'Commentaire', name: 'traN_VG_CMT', required: true , typeField:'text'},  
  ];

   
  
 
  const rafraichirListeCodeTransformations  = useCallback(async () => {
    try {
      setIsLoading(true) 
      setlisteCodeTransformations(await codeTransformationService.getAll())
    } catch (e) {
      console.error('Erreur lors du chargement des données', e)
     
    } finally {
      setIsLoading(false)
    }
  }, [codeTransformationService]);

  
 
  useEffect(() => {
  
    rafraichirListeCodeTransformations(); // Appel de la fonction au montage du composant
    setSelectedCodeTransformation(createCodeTransformationInstance());
  }, [rafraichirListeCodeTransformations]); // Le tableau vide [] indique que l'effet ne dépend d'aucune variable et ne s'exécutera qu'une fois

  
   
 
  const handleAdd = async () => {
    try {
      const newItem = createCodeTransformationInstance();
      
      // Ajout de l'élément et rafraîchissement de la grille en effectuant un changement d'état.
      if (listeCodeTransformations) {
        setlisteCodeTransformations([...listeCodeTransformations, newItem]);
      } else {
        setlisteCodeTransformations([newItem]);
      }

          
    const newSelected = listeCodeTransformations ? listeCodeTransformations[(listeCodeTransformations.length ?? 0) - 1] : null;
    setSelectedCodeTransformation(newSelected);
      setPageIndex(Math.floor(((listeCodeTransformations?.length ?? 0) - 1) / 10));  // page size  10
      setRowIndex((listeCodeTransformations?.length ?? 0) - 1);


    } catch (error) {
      console.error('Erreur lors de la création', error)
      // Gérer l'erreur ici
    }
  };
  // Handler pour la suppression
  const handleDelete = async (id: number) => {
    try {
      await codeTransformationService.remove('CTV_ID',id);
      rafraichirListeCodeTransformations();
    } catch (error) {
      // Gérer l'erreur ici
    }
  };

  const handleclick = async (id: number) => {
    const compteRendu = listeCodeTransformations?.find(cr => cr.ctV_ID === id);
    if (compteRendu) {
      setSelectedCodeTransformation(compteRendu);
      console.info('code transformation actuel ', compteRendu.traN_VG_LBL);
    }
  };
  
  const handleSave = async (data: CodeTransformation) => {
    try {
      if (data.ctV_ID === -1 ||data.ctV_ID === undefined ) {
        await codeTransformationService.create(data);
        console.info('Ajout code transformation :  commentaire ', data.traN_VG_CMT);
      } else {
        await codeTransformationService.updateByItem(data);
        console.info('Update code transformation :  commentaire ', data.traN_VG_CMT);
      }
      setSelectedCodeTransformation(null);  // Réinitialise le compte rendu sélectionné
      rafraichirListeCodeTransformations();
    } catch (erreur) {
      console.error("Erreur lors de la sauvegarde du code transformation", erreur);
    }
  };

  function handelCancel(): void {
    setPageIndex(undefined);
    setRowIndex(undefined);
    rafraichirListeCodeTransformations();
  }

  return (
    <React.Fragment>
    {/* <h2 className={'content-block'}>Codes Transformations</h2> */}

    <div className={'content-block dx-card responsive-paddings'}>
    <SegaDataGrid idName="ctV_ID" 
    type={createCodeTransformationInstance} 
    dataSource={listeCodeTransformations} 
    ColumnDefinition={columnsDef}
     onRowClick={id => handleclick(id)} 
     canAdd={true} 
       onAdd={handleAdd}
      canEdit={true} 
      pageIndex={pageIndex}
      rowIndex={rowIndex}
     ></SegaDataGrid>
    </div>

    <div className={'content-block dx-card responsive-paddings'}>
    {selectedCodeTransformation && (
        <CodeTransformationDetailPage
        
        onDel={handleDelete}
          codetransformation={selectedCodeTransformation}
          onSave={handleSave}
          onCancel={handelCancel}
        />
      )}
         {isLoading && <div>Loading...</div>}
    </div>
    </React.Fragment>
      
 
  )
} 

export default CodeTransformationPage;
