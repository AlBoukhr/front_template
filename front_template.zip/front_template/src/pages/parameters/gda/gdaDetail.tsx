import React, { useCallback, useEffect, useMemo, useState } from "react";
import 'devextreme-react/text-area';
import { Button, CheckBox, SelectBox, TextBox } from "devextreme-react";
import {  ListsOperateurImmeubleService  } from "../../../services/ListsService";

import {  ValeurService  } from "../../../services/valeurService";
import { Gda } from '../../../models/Gda';
import { Valeur } from "../../../models/Valeur";
import { OperateurImmeuble } from "../../../models/OperateurImmeuble"; 
import { axiosInstance } from '../../../services/configaxios'; 
import { GdaService } from "../../../services/GdaService";
  

interface GdaDetailPageProps {
  filterGda :Gda;
  onSave: (data: Gda) => Promise<void>; 
  onDel :(Gda: any) => Promise<void>;
  onCancel: () => void;
}

const GdaDetailPage: React.FC<GdaDetailPageProps> = ({ filterGda, onSave ,onDel, onCancel }) => {  
  
  
  function createGdaInstance() {
    return {
      aaG_ID: -1,
      codofr: filterGda.codofr,
      typlie: filterGda.typlie,
      operator: filterGda.operator,
      gdA_ID: -1,
      entite: filterGda.entite,
      gdA_NOM: "",
      operatorlib: "",
    } as Gda;
  }
  const gdaService = useMemo(() => new GdaService(axiosInstance), []);
  const [listeGdasNonAffecte, setListeGdasNonAffecte] = useState<Gda[] | null>(null);
  const [state, setState] = useState<Gda>(createGdaInstance());
  const [filterState, setfilterState] = useState<Gda>(filterGda);

 
   
  useEffect(() => {
    if (filterGda) {
      setfilterState(filterGda);
      // Mettre à jour les filtres lorsque l'instance sélectionnée change
      rafraichirListeGdasAffectes();
    }
  }, [filterGda]);


  const rafraichirListeGdasAffectes = useCallback(async () => {
    
    try {
      const gdasnonAffectes = await gdaService.getGDANonAffecte(filterState);
      setListeGdasNonAffecte(gdasnonAffectes);

      console.info("filtre GDA non affectés ; offre :" + filterState.codofr+" entitee :" +filterState.entite+" type : "  + filterState.typlie+" opr :"  + filterState.operator);

    } catch (e) {
      console.error("Erreur lors du chargement des données", e);
    } finally {
      
    }
  }, [gdaService, filterState]);

  const handleChange = (field: keyof Gda, value: any) => {
   
    setState(prevState => ({
      ...prevState,
      [field]: value
    }));
  };



  const isFieldRequired = (field: keyof Gda): boolean => {
    switch (field) {
      case 'gdA_ID': 
     
        return true;
      default:
        return false;
    }
  };

  return (
    <React.Fragment>
      <div className="settings">
        
        <div className="column">
          <div className="field">
            <div className="value">
              <SelectBox
                dataSource={listeGdasNonAffecte}
                value={state.gdA_ID}
                valueExpr="gdA_ID"
                displayExpr="gdA_NOM"
                onValueChanged={e => handleChange('gdA_ID', e.value)}
                className={isFieldRequired('gdA_ID') ? 'required-field' : ''}
                label='GDA'
              />
            </div>
          </div>
          
        </div>
      
        </div>
        <div className="button-row">
                   <Button onClick={() => onDel(state || null)} icon="trash" hint="Supprimer"/>
                <Button onClick={() => onSave(state)} icon="save" hint="Enregistrer"/>
                <Button onClick={onCancel} icon="clear" hint="Annuler"/>
            </div>
     
    </React.Fragment>
  );
};

export default GdaDetailPage;
