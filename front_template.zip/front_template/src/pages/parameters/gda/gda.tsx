import React, { useCallback, useEffect, useMemo, useState } from "react";
import { axiosInstance } from "../../../services/configaxios";
import { Gda } from "../../../models/Gda";
import SegaDataGrid from "../../../components/segadevextreme/datagrid";
import { ColumnDefinition, FilterFieldDefinition } from "../../../components/interfaces";
import { ValeurService } from "../../../services/valeurService";
import { GdaService } from "../../../services/GdaService";
import { Valeur } from "../../../models/Valeur";
import SegaFilter from "../../../components/Common/segafilter"; 
import { cacheData, getCachedData } from '../../../services/cacheservice';
import GdaDetailPage from "./gdaDetail";

function GdaPage() {
  const valeurService = useMemo(() => new ValeurService(axiosInstance), []);
  const gdaService = useMemo(() => new GdaService(axiosInstance), []);

  const [listeGdasAffecte, setListeGdasAffecte] = useState<Gda[] | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [ofrcom, setOfrcomListe] = useState<Valeur[] | null>(null);
  const [isAdding, setIsAdding] = useState<boolean>(false);
  const [filter, setFilter] = useState<Gda>(filtreGDAInstance());
  const [selectedGDA, setselectedGDA] = useState<Gda | null>(filtreGDAInstance());

  const [selectnatData, setSelectnatData] = useState<{ [key: string]: Valeur[] | null }>({
    natlie: null,
    natfto: null,
    natfte: null,
    natgnr: null,
     natsga: null
  });


  
   
 
  
  useEffect(() => {
    const chargerListes = async () => {
      try {
        const ofrcomList = await valeurService.getOneList("OFRCOM");
        
        setOfrcomListe(ofrcomList);
        
        const newSelectData = {...selectnatData};
      
        for (const key in newSelectData) {
          const cachedData = getCachedData(key);
          if (cachedData) {
            newSelectData[key] = cachedData;
          } else {
            newSelectData[key] = await valeurService.getOneList(key.toUpperCase());
            cacheData(key, newSelectData[key]);
          }
        }
  
        setSelectnatData(newSelectData);



      } catch (erreur) {
        console.error("Erreur lors du chargement de la liste", erreur);
      }
    };
    chargerListes();
  }, [valeurService]);

  const chargerOptionsDependantes = useCallback(
    
    async (filter: Gda) => {
      if (filter.codofr) {
        try {

          console.info("code offre :" + filter.codofr);

          let updatedFilteredNatLieData: Valeur[] ;
let oftlbl:string;
            
          switch (filter.codofr) {
            case 'DSL':
              updatedFilteredNatLieData = selectnatData.natlie || [];  
              oftlbl = "DSL";
              break;
            case 'DSP':
              updatedFilteredNatLieData = [];
              oftlbl = "DSP";
              break;
            case 'VGA':
              updatedFilteredNatLieData = [];
              oftlbl = "VGA";
              break;
            case 'FTH':
              updatedFilteredNatLieData = []; 
              oftlbl = "FTTH";
              break;
            case 'FTO': 
              updatedFilteredNatLieData = selectnatData.natfto|| [];  
              oftlbl = "FTTO";
            
              break;
            case 'FTE': 
              updatedFilteredNatLieData = selectnatData.natfte|| [];  
              oftlbl = "FTTE";
            
              break;
            case 'GNR': 
              updatedFilteredNatLieData = selectnatData.natgnr|| [];  
              oftlbl = "GNR";
             
              break;
            default:
              oftlbl = "CELAN";
              updatedFilteredNatLieData = selectnatData.natsga|| [];  
             
          }

          const entiteOptions = await valeurService.getAllByFilter(`CODOFR=${filter.codofr}`, "Gda", "GetAagEntite");
         
          const operatorOptions = await valeurService.getAllByFilter(`CODOFR=${oftlbl}`, "Gda", "GetAagOperator");
       
        

          return { entite: entiteOptions, operator: operatorOptions , natlie:updatedFilteredNatLieData  };
        } catch (error) {
          console.error("Erreur lors du chargement de la liste", error);
          return { entite: [], operator: [] , natlie :[] };
        }
      }
      return { entite: [], operator: [], natlie :[] };
    },
    [valeurService, filter, selectnatData]
  );

  const rafraichirListeGdasAffectes = useCallback(async () => {
    setIsLoading(true);
    try {
      const gdasAffectes = await gdaService.getGDAAffecte(filter);
      setListeGdasAffecte(gdasAffectes);
    } catch (e) {
      console.error("Erreur lors du chargement des données", e);
    } finally {
      setIsLoading(false);
    }
  }, [gdaService, filter]);

  useEffect(() => {
    rafraichirListeGdasAffectes();

    console.info("filtre GDA ; offre :" + filter.codofr+" entitee :" +filter.entite+" type : "  + filter.typlie+" opr :"  + filter.operator);

  }, [filter, rafraichirListeGdasAffectes]);

  const handleFilterChange = async (newFilter: Gda) => {
    setFilter(newFilter);
  };

  function filtreGDAInstance() {
    return {
      aaG_ID: 0,
      codofr: "CEL",
      typlie: "DSL",
      operator: "9C_",
      gdA_ID: 0,
      entite: "BTE",
      gdA_NOM: "",
      operatorlib: "",
    } as Gda;
  }

  function createGdaInstance() {
    return {
      aaG_ID: -1,
      codofr: "",
      typlie: "",
      operator: "",
      gdA_ID: -1,
      entite: "",
      gdA_NOM: "",
      operatorlib: "",
    } as Gda;
  }

  const fieldConfig: FilterFieldDefinition[] = [
    { dataField: "codofr", caption: "Offre Commerciale", dataType: "lookup", optionValueField: "libval", optionLabelField: "libval", options: ofrcom },
    { dataField: "typlie", caption: "Type Lien", dataType: "lookup", optionValueField: "libval", optionLabelField: "libval",
      options: (filter: Gda) => chargerOptionsDependantes(filter).then(res => res.natlie)  },
    {
      dataField: "entite",
      caption: "Entité",
      dataType: "lookup",
      optionValueField: "codval",
      optionLabelField: "libval",
      options: (filter: Gda) => chargerOptionsDependantes(filter).then(res => res.entite),
    },
    {
      dataField: "operator",
      caption: "Opérateur",
      dataType: "lookup",
      optionValueField: "codval",
      optionLabelField: "libval",
      options: (filter: Gda) => chargerOptionsDependantes(filter).then(res => res.operator),
    },
  ];

  const columnsDefAffecte: ColumnDefinition[] = [
    { visible: true, caption: "Nom GDA", name: "gdA_NOM", required: true, typeField: "text" }, 
  ];

  
  const handleSave = async (data: Gda) => {
    try {
      if (data.aaG_ID === -1 || data.aaG_ID === undefined) {
        await gdaService.create(data);
      } else {
        await gdaService.updateByItem(data);
      }
      setIsAdding(false);
    rafraichirListeGdasAffectes();
    } catch (erreur) {
      console.error("Erreur lors de la sauvegarde du paramètre", erreur);
    }
  };

  const handleDelete = async (Gda: any) => {
    try {
      //TODO 
      await gdaService.remove('Gda',Gda);
      rafraichirListeGdasAffectes();
    } catch (error) {
      console.error('Erreur lors de la suppression', error);
    }
  };

  const handleAffecteRowClick = async (id: number) => {
    if (listeGdasAffecte) {
      const gda = listeGdasAffecte[id];
      if (gda) {
        setselectedGDA(gda);
      }
    }
  };

  function handleAdd(): void {
    setIsAdding(true);
  }

  return (
    <React.Fragment>
      {/* <h2 className="content-block">Affectation GDA</h2> */}

      <div className="content-block dx-card responsive-paddings">
        <SegaFilter
          Filter={filter}
          columnCount={4}
          onFilterChange={handleFilterChange}
          FilterFields={fieldConfig}
        />
      </div>
      <div className="content-block dx-card responsive-paddings">
        <SegaDataGrid
          type={createGdaInstance}
          dataSource={listeGdasAffecte}
          ColumnDefinition={columnsDefAffecte}
          canEdit={true}
          canAdd={true}
          onRowClick={handleAffecteRowClick}
          onAdd={handleAdd}
           idName="gdA_ID"       />
      </div>
     
      {isAdding && (
      <div className={'content-block dx-card responsive-paddings'}>
       
          <GdaDetailPage 
            filterGda={filter}
            onSave={handleSave}
            onDel={handleDelete}
            onCancel={() => setselectedGDA(null)}
          /> 
       
      </div>)} 
      {isLoading && <div>Chargement...</div>}
    </React.Fragment>
  );
}

export default GdaPage;
