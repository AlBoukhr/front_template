import React, { useEffect, useState } from "react";
import 'devextreme-react/text-area';
import { Button, TextBox } from "devextreme-react";
import { AdminParam } from "../../../models/AdminParam";
// import { axiosInstance } from '../../../services/configaxios'; // Assurez-vous du bon chemin d'importation

interface AdminParamDetailPageProps {
  adminParam: AdminParam | null;
  onSave: (data: AdminParam) => Promise<void>;
  onCancel: () => void;
}

const AdminParamDetailPage: React.FC<AdminParamDetailPageProps> = ({ adminParam, onSave, onCancel }) => {
  const [state, setState] = useState<AdminParam | null>(adminParam);

  // Mettre à jour l'état local lorsque les props changent
  useEffect(() => {
    setState(adminParam);
  }, [adminParam]);

  const handleChange = async (field: keyof AdminParam, value: any) => {
    setState(prevState => prevState ? ({ ...prevState, [field]: value }) : null);
  };

  const isFieldRequired = (field: keyof AdminParam): boolean => {
    switch (field) {
      case 'prM_VAL':
        return true;
      default:
        return false;
    }
  };

  if (!state) {
    return <div>Sélectionnez un compte-rendu pour voir les détails</div>;
  }

  return (
    <React.Fragment>
      <div className="settings">
        <div className="column">
          <div className="field">
            
            <div className="value">
              <TextBox
                className={'disabled-field'}
                value={state.prM_LBL || ""}
                onValueChanged={e => handleChange('prM_LBL', e.value)}
                 label="Paramètre"
              />
            </div>
          </div>
          <div className="field">
            
            <div className="value">
              <TextBox
                className={isFieldRequired('prM_VAL') ? 'required-field' : ''}
                value={state.prM_VAL || ""}
                onValueChanged={e => handleChange('prM_VAL', e.value)}
                label="Valeur"
              />
            </div>
          </div>
        </div>
      </div>

      <div className="button-row">
        <Button onClick={() => onSave(state!)} icon="save" hint="Enregistrer" />
        <Button onClick={onCancel} icon="clear" hint="Annuler" />
      </div>
    </React.Fragment>
  );
};

export default AdminParamDetailPage;
