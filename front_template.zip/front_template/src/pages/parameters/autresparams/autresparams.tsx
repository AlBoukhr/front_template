import { AutresParametresService } from "../../../services/AutresParametresService";
import { axiosInstance } from '../../../services/configaxios'; // Assurez-vous du bon chemin d'importation
import { AdminParam } from '../../../models/AdminParam';
import React, { useCallback, useEffect, useMemo, useState } from "react";
import SegaDataGrid from "../../../components/segadevextreme/datagrid";
import { ColumnDefinition } from "../../../components/interfaces";
import AdminParamDetailPage from "./autresparamsDetail";

function AdminParamPage() {
  const [listeAdminParams, setlisteAdminParams] = useState<AdminParam[] | null>(null);
  const autresparametresService = useMemo(()=> new AutresParametresService(axiosInstance),[]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [selectedAdminParam, setSelectedAdminParam] = useState<AdminParam | null>(null);
  const [lastSavedId, setLastSavedId] = useState<number | null>(null);
  const [pageIndex, setPageIndex] = useState<number | undefined>();
  const [rowIndex, setRowIndex] = useState<number | undefined>();
  const columnsDef: ColumnDefinition[] = [
    { visible: false, caption: 'Clé', name: 'prM_KEY', required: true, typeField: 'text' },
    { visible: true, caption: 'Libelle', name: 'prM_LBL', editable: true, typeField: 'text' },
    { visible: true, caption: 'Valeur', name: 'prM_VAL', required: true, typeField: 'text' },
    { visible: false, caption: 'ID', name: 'prM_ID', required: true, typeField: 'text' },
  ];
 
  function createAdminParamInstance() {
    return {
      prM_VAL: "",
      prM_LBL: "",
      prM_KEY: "",
      prM_ID: -1,
    } as AdminParam;
  }

 

  const rafraichirListeAdminParams = useCallback( async () => {
    try {
      setIsLoading(true);
      setlisteAdminParams(await autresparametresService.getAll());
    } catch (e) {
      console.error('Erreur lors du chargement des données', e);
    } finally {
      setIsLoading(false);
    }
  },[autresparametresService]);

  useEffect(() => {
    rafraichirListeAdminParams();
    setSelectedAdminParam(createAdminParamInstance());
  }, [rafraichirListeAdminParams]);


  useEffect(() => {
    if (listeAdminParams != null && listeAdminParams.length > 0) {
      const toSelect = lastSavedId !== null ? listeAdminParams.find(p => p.prM_ID === lastSavedId) : listeAdminParams[0];
      setSelectedAdminParam(toSelect || null);
    }
  }, [listeAdminParams, lastSavedId]);
 
  
  const handleClick = async (id: number) => {
    const compteRendu = listeAdminParams?.find(cr => cr.prM_ID === id);
    if (compteRendu) {
      setSelectedAdminParam(compteRendu);
      console.info('param admin actuel ', compteRendu.prM_LBL);
    }
  };

  const handleSave = async (data: AdminParam) => {
    try {
      
        await autresparametresService.updateByItem(data);
        setLastSavedId(data.prM_ID || -1);
       
      setSelectedAdminParam(null);
      rafraichirListeAdminParams();
    } catch (erreur) {
      console.error("Erreur lors de la sauvegarde du paramètre", erreur);
    }
  };

  function handelCancel(): void {
    setPageIndex(undefined);
    setRowIndex(undefined);
    rafraichirListeAdminParams();
  }

  return (
    <React.Fragment>
      {/* <h2 className={'content-block'}>Autres Paramètres</h2> */}
      <div className={'content-block dx-card responsive-paddings'}>
        <SegaDataGrid
          idName="prM_ID"
          type={createAdminParamInstance}
          dataSource={listeAdminParams}
          onRowClick={handleClick}
          ColumnDefinition={columnsDef}
          canEdit={false}
          canAdd={false}
          pageIndex={pageIndex}
          rowIndex={rowIndex}
        />
      </div>
      <div className={'content-block dx-card responsive-paddings'}>
        {selectedAdminParam && (
          <AdminParamDetailPage
            adminParam={selectedAdminParam}
            onSave={(adminparam) => handleSave(adminparam)}
            onCancel={handelCancel}
          />
        )}
        {isLoading && <div>Loading...</div>}
      </div>
    </React.Fragment>
  );
}

export default AdminParamPage;
