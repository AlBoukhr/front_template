 
import TabPanel, { Item } from "devextreme-react/tab-panel";
import { Button, SelectBox, TextBox } from "devextreme-react"; 
import { ModificationAdmin } from '../../../models/ModificationAdmin'  
import React, { useEffect, useMemo, useState } from "react";  
import { Valeur } from "../../../models/Valeur";  
import {  ModificationAdminService  } from "../../../services/ModificationAdminService";
import {  ValeurService  } from "../../../services/valeurService";
import { axiosInstance } from '../../../services/configaxios'; // Assurez-vous du bon chemin d'importation



function ModificationAdminPage() {
  const   valeurService   =   useMemo(() => new ValeurService(axiosInstance), []);
  const    modificationadminService   = new ModificationAdminService(axiosInstance);

  const [modifiactionadmin, setmodifiactionadmin] = useState<ModificationAdmin>({
    cmS_NOM: '',
    cmS_STU: '',
    neW_CODEOFFRE: '',
    cmD_OFR: '',
  });

  const [ofrcom, setOfrcomListe] = useState<Valeur[] | null>(null);
  const [admstu, setAdmstuListe] = useState<Valeur[] | null>(null);

  useEffect(() => {
    const chargerListes = async () => {
      try {
        setOfrcomListe(await valeurService.getOneList("OFRCOM"));
        setAdmstuListe(await valeurService.getOneList("ADMSTU"));
      } catch (erreur) {
        console.error("Erreur lors du chargement de la liste", erreur);
      }
    };
    chargerListes();
  }, [valeurService]);

  const handleChange = (field: keyof ModificationAdmin, value: any) => {
    setmodifiactionadmin(prevState => ({
      ...prevState,
      [field]: value
    }));
  };

  const handleOkClick = async () => {
    try {
      // Api call to save the updated ModificationAdmin state
      await modificationadminService.updateByItem(modifiactionadmin); // Assurez-vous que cette méthode existe dans votre service
      console.info("Mise à jour réussie ! ", modifiactionadmin);
      
    } catch (erreur) {
      console.error("Erreur lors de la mise à jour", erreur);
      //alert("Erreur lors de la mise à jour");
    }
  };

  const isFieldRequired = (field: keyof ModificationAdmin): boolean => {
    switch (field) {
      case 'cmS_NOM':
      case 'cmD_OFR':
      case 'cmS_STU':
        return true;
      default:
        return false;
    }
  };

  return (

    <React.Fragment>
    {/* <h2 className={'content-block'}>Modification Admin</h2> */}

    <div className={'content-block dx-card responsive-paddings'}>
     
        <TabPanel>
          <Item title="MSDISDN">
            <div className="settings">
              <div className="column">
                <div className="field">
                  <div className="value">
                    <TextBox
                      className={isFieldRequired('cmS_NOM') ? 'required-field' : ''}
                      value={modifiactionadmin.cmS_NOM || ""}
                      onValueChanged={e => handleChange('cmS_NOM', e.value)}
                      label="Ancien MSISDN"
                    />
                  </div>
                </div>
                <div className="field">
                  <div className="value">
                    <TextBox
                      className={isFieldRequired('cmS_NOM') ? 'required-field' : ''}
                      value={modifiactionadmin.cmS_NOM || ""}
                      onValueChanged={e => handleChange('cmS_NOM', e.value)}
                      label="Nouveau MSISDN"
                    />
                  </div>
                </div>
                
                
              </div>
            </div>
          </Item>
          <Item title="Code Offre">
            <div className="settings">
              <div className="column">
                <div className="field">
                  <div className="value">
                    <TextBox
                      className={isFieldRequired('cmS_NOM') ? 'required-field' : ''}
                      value={modifiactionadmin.cmS_NOM || ""}
                      onValueChanged={e => handleChange('cmS_NOM', e.value)}
                      label="Nom Commande"
                    />
                  </div>
                </div>
                <div className="field">
                  <div className="value">
                    <SelectBox
                      dataSource={ofrcom}
                      value={modifiactionadmin.cmD_OFR}
                      valueExpr="codval"
                      displayExpr="libval"
                      text="Operateur"
                      onValueChanged={e => handleChange('cmD_OFR', e.value)}
                      className={isFieldRequired('cmD_OFR') ? 'required-field' : ''}
                      label="Nouvelle Offre"
                    />
                  </div>
                </div>
                
              </div>
            </div>
          </Item>
          <Item title="Statut">
            <div className="settings">
              <div className="column">
                <div className="field">
                  <div className="value">
                    <TextBox
                      className={isFieldRequired('cmS_NOM') ? 'required-field' : ''}
                      value={modifiactionadmin.cmS_NOM || ""}
                      onValueChanged={e => handleChange('cmS_NOM', e.value)}
                      label="Nom Commande"
                    />
                  </div>
                </div>
                <div className="field">
                  <div className="value">
                    <SelectBox
                      dataSource={admstu}
                      value={modifiactionadmin.cmS_STU}
                      valueExpr="codval"
                      displayExpr="libval"
                      text="Statut"
                      onValueChanged={e => handleChange('cmS_STU', e.value)}
                      className={isFieldRequired('cmS_STU') ? 'required-field' : ''}
                      label="Statut"
                    />
                  </div>
                </div>

                
                
              </div>
            </div>
          </Item>
        </TabPanel>
        <div className="button-row">
               
                  <Button onClick={() => handleOkClick} icon="save" hint="Enregistrer"/>
                
             
      </div>
    </div>

    
    </React.Fragment>

  );
}

export default ModificationAdminPage;
