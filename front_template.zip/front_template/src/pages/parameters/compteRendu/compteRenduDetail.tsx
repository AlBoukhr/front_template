import React, { useCallback, useEffect, useMemo, useState } from 'react';
import 'devextreme-react/text-area';
import { Button, CheckBox, SelectBox, TextArea, TextBox } from 'devextreme-react';
import { CompteRendu } from '../../../models/CompteRendu';
import { Valeur } from '../../../models/Valeur';
import { Cause } from '../../../models/Cause';
import { ListsCauseService } from '../../../services/ListsService';
import { ValeurService } from '../../../services/valeurService';
import { axiosInstance } from '../../../services/configaxios';
import { cacheData, getCachedData } from '../../../services/cacheservice';

interface CompteRenduDetailPageProps {
  compteRendu: CompteRendu | null;
  onSave: (data: CompteRendu) => Promise<void>; 
  onDel: (id: number) => Promise<void>;
  onCancel: () => void;
}

const CompteRenduDetailPage: React.FC<CompteRenduDetailPageProps> = ({ compteRendu, onSave, onDel, onCancel }) => {
  const valeurService = useMemo(() => new ValeurService(axiosInstance), []);
  const listsService = useMemo(() => new ListsCauseService(axiosInstance), []);

  const [state, setState] = useState<CompteRendu>(compteRendu || {
    bcR_NAT_LIE: "",
    bcR_TYP_MSG: "",
    bcR_STU_MSG: "",
    bcR_COD_MSG: "",
    bcR_TITRE: "",
    bcR_TEXTE: "",
    bcR_OFR_COM: "",
    bcR_CAU_RET: "",
    bcR_OUV_DEL: -1,
    bcR_CSE_ID: -1,
    bcR_ENT_BTE: -1,
    bcR_ENT_BTW: -1,
    bcR_TYP_MSG_LBL: "",
    bcR_STU_MSG_LBL: "",
    bcR_NAT_LIE_LBL: "",
    tyP_CSE: "",
    tyP_CSE_LIB: "",
    liB_CSE: "",
  });

  const [isLoading, setIsLoading] = useState(false);
  const [requiredFields, setRequiredFields] = useState<{ [key: string]: boolean }>({bcR_NAT_LIE :true,bcR_TYP_MSG:true,  bcR_OFR_COM :true,bcR_TITRE: true,
    bcR_CAU_RET: true,
    bcR_TEXTE: true,});
  const [readonlyFields, setReadonlyFields] = useState<{ [key: string]: boolean }>({});
  const [selectData, setSelectData] = useState<{ [key: string]: Valeur[] | null }>({
    natlie: null,
    natfto: null,
    natfte: null,
    natgnr: null,
    ofrcom: null,
    msgtyp: null,
    ar_stu: null,
    mcocel: null,
    mcovga: null,
    mcodsp: null,
    mcognr: null,
    mcofte: null,
    mcofto: null,
    mcofth: null,
    typecse: null
  });

  const [filteredNatLieData, setFilteredNatLieData] = useState<Valeur[] | null>(null);
  const [filteredCodMsgData, setFilteredCodMsgData] = useState<Valeur[] | null>(null);
  const [isNatLieVisible, setIsNatLieVisible] = useState(true);
  const [isCauseRetardVisible, setIsCauseRetardVisible] = useState(true);
  const [causesByType, setCausesByTypeListe] = useState<Cause[] | null>(null);
  const [isOuvertureDelai, setisOuvertureDelai] = useState(false);
  const [isOuvertureDelaiOK, setisOuvertureDelaiOK] = useState(false);

  const OuvDelUpdated = useCallback((ouvdel: number) => { 
    setisOuvertureDelaiOK(ouvdel === 1); 
  }, []);

  const TypMsgUpdated = useCallback((typMsg: string) => {
    let newReadonlyFields = { ...readonlyFields };
    let newRequiredFields = { ...requiredFields };

    switch (typMsg) {
      case 'CR_':
        newRequiredFields = { ...newRequiredFields, bcR_STU_MSG: true };
        newReadonlyFields = { ...newReadonlyFields, bcR_COD_MSG: true, bcR_STU_MSG: false };
        break;
      case 'AR_':
      case 'CRI':
        newRequiredFields = { ...newRequiredFields, bcR_COD_MSG: true };
        newReadonlyFields = { ...newReadonlyFields, bcR_COD_MSG: false, bcR_STU_MSG: true };
        break;
      default:
        newReadonlyFields = { ...newReadonlyFields, bcR_COD_MSG: true, bcR_STU_MSG: true };
    }

    setRequiredFields(newRequiredFields);
    setReadonlyFields(newReadonlyFields);
  }, [readonlyFields, requiredFields]);

  const CodMsgUpdated = useCallback((codmsg: string) => {
    setIsCauseRetardVisible(codmsg === 'RETARD');
  }, []);

  const OffreCommUpdated = useCallback((offCommValue: string) => {
    let updatedFilteredNatLieData: Valeur[] | null = null;
    let updatedFilteredCodMsgData: Valeur[] | null = null;

    setisOuvertureDelai(false); 

    switch (offCommValue) {
      case 'DSL':
        updatedFilteredNatLieData = selectData.natlie;
        updatedFilteredCodMsgData = selectData.mcovga;
        setIsNatLieVisible(true);
        break;
      case 'DSP':
        updatedFilteredCodMsgData = selectData.mcodsp;
        setIsNatLieVisible(false);
        break;
      case 'VGA':
        updatedFilteredCodMsgData = selectData.mcovga;
        setIsNatLieVisible(false);
        break;
      case 'FTH':
        updatedFilteredCodMsgData = selectData.mcofth;
        setIsNatLieVisible(false);
        setisOuvertureDelai(true); 
        break;
      case 'FTO':
        updatedFilteredCodMsgData = selectData.mcofto;
        updatedFilteredNatLieData = selectData.natfto;
        setIsNatLieVisible(true);
        break;
      case 'FTE':
        updatedFilteredCodMsgData = selectData.mcofte;
        updatedFilteredNatLieData = selectData.natfte;
        setIsNatLieVisible(true);
        break;
      case 'GNR':
        updatedFilteredCodMsgData = selectData.mcognr;
        updatedFilteredNatLieData = selectData.natgnr;
        setIsNatLieVisible(true);
        break;
      default:
        updatedFilteredNatLieData = selectData.natsga;
        updatedFilteredCodMsgData = selectData.mcocel;
        setIsNatLieVisible(true);
    }

    setFilteredNatLieData(updatedFilteredNatLieData || []);
    setFilteredCodMsgData(updatedFilteredCodMsgData || []);
  }, [selectData]);

  useEffect(() => {
    if (compteRendu) {
      setState(compteRendu);
      OffreCommUpdated(compteRendu.bcR_OFR_COM || '');
      // Mettre à jour les filtres lorsque l'instance sélectionnée change
    }
  }, [compteRendu]);

  const handleChange = useCallback(async (field: keyof CompteRendu, value: any) => {
    setState(prevState => ({ ...prevState, [field]: value }));

    if (field === 'tyP_CSE') {
      setCausesByTypeListe(await listsService.getCausesByType(value));
    }

    if (field === 'bcR_OFR_COM') {
      OffreCommUpdated(value);
    }

    if (field === 'bcR_TYP_MSG') {
      TypMsgUpdated(value);
    }

    if (field === 'bcR_COD_MSG') {
      CodMsgUpdated(value);
    }

    if (field === 'bcR_OUV_DEL') {
      OuvDelUpdated(value ? 1 : 0);
    }
  }, [CodMsgUpdated, OffreCommUpdated, OuvDelUpdated, TypMsgUpdated, listsService]);

  const rafraichirDetail = useCallback(async () => {
    if (compteRendu && compteRendu.tyP_CSE) {
      setCausesByTypeListe(await listsService.getCausesByType(compteRendu.tyP_CSE));
    }

    if (compteRendu) {
      OffreCommUpdated(compteRendu.bcR_OFR_COM || '');
      TypMsgUpdated(compteRendu.bcR_TYP_MSG || '');
      // OuvDelUpdated(compteRendu.bcR_OUV_DEL || 0)
    }
  }, [OffreCommUpdated, TypMsgUpdated, compteRendu, listsService]);

  const chargerListes = useCallback(async () => {
    try {
      const newSelectData = { ...selectData };

      for (const key in newSelectData) {
        const cachedData = getCachedData(key);
        if (cachedData) {
          newSelectData[key] = cachedData;
        } else {
          newSelectData[key] = await valeurService.getOneList(key.toUpperCase());
          cacheData(key, newSelectData[key]);
        }
      }

      setSelectData(newSelectData);
    } catch (erreur) {
      console.error('Erreur lors du chargement de la liste', erreur);
    } finally {
      setIsLoading(false);
    }
  }, [selectData, valeurService]);

  useEffect(() => {
    chargerListes();
  }, [chargerListes]);

  useEffect(() => {
    rafraichirDetail();
  }, [compteRendu, rafraichirDetail]);

  const isFieldRequired = useCallback((field: keyof CompteRendu) => requiredFields[field] ?? false, [requiredFields]);
  const isFieldReadonly = useCallback((field: keyof CompteRendu) => readonlyFields[field] ?? false, [readonlyFields]);

  if (isLoading || !state) {
    return <div>Chargement en cours...</div>;
  }

  return (
    <React.Fragment>
      <div className="settings">
        <div className="column">
          <div className="field">
            <div className="value">
              <SelectBox
                dataSource={selectData.ofrcom}
                value={state.bcR_OFR_COM}
                valueExpr="codval"
                displayExpr="libval"
                onValueChanged={e => handleChange('bcR_OFR_COM', e.value)}
                readOnly={isFieldReadonly('bcR_OFR_COM')}
                className={`${isFieldRequired('bcR_OFR_COM') ? 'required-field' : ''}`} 
                label="Offre Commerciale"
              />
            </div>
          </div>
          <div className="field">
            <div className="value">
              <SelectBox
                dataSource={selectData.msgtyp}
                value={state.bcR_TYP_MSG}
                valueExpr="codval"
                displayExpr="libval"
                onValueChanged={e => handleChange('bcR_TYP_MSG', e.value)}
                readOnly={isFieldReadonly('bcR_TYP_MSG')}
                className={`${isFieldRequired('bcR_TYP_MSG') ? 'required-field' : ''} ${isFieldReadonly('bcR_TYP_MSG') ? 'disabled-field' : ''}`}
                label="Type"
              />
            </div>
          </div>
        </div>
        <div className="column">
          <div className="field">
            <div className="value">
              <SelectBox
                dataSource={filteredCodMsgData}
                value={state.bcR_COD_MSG}
                valueExpr="codval"
                displayExpr="libval"
                onValueChanged={e => handleChange('bcR_COD_MSG', e.value)}
                readOnly={isFieldReadonly('bcR_COD_MSG')}
                className={`${isFieldRequired('bcR_COD_MSG') ? 'required-field' : ''} ${isFieldReadonly('bcR_COD_MSG') ? 'disabled-field' : ''}`}
                label="Code Message"
              />
            </div>
          </div>
          {isNatLieVisible && (
            <div className="field">
              <div className="value">
                <SelectBox
                  dataSource={filteredNatLieData}
                  value={state.bcR_NAT_LIE}
                  valueExpr="codval"
                  displayExpr="libval"
                  onValueChanged={e => handleChange('bcR_NAT_LIE', e.value)}
                  readOnly={isFieldReadonly('bcR_NAT_LIE')}
                  className={`${isFieldRequired('bcR_NAT_LIE') ? 'required-field' : ''} ${isFieldReadonly('bcR_NAT_LIE') ? 'disabled-field' : ''}`}
                  label="Nature Lien"
                />
              </div>
            </div>
          )}
        </div>
        <div className="column">
          <div className="field">
            <div className="value">
              <SelectBox
                dataSource={selectData.ar_stu}
                value={state.bcR_STU_MSG}
                valueExpr="codval"
                displayExpr="libval"
                onValueChanged={e => handleChange('bcR_STU_MSG', e.value)}
                readOnly={isFieldReadonly('bcR_STU_MSG')}
                className={`${isFieldRequired('bcR_STU_MSG') ? 'required-field' : ''} ${isFieldReadonly('bcR_STU_MSG') ? 'disabled-field' : ''}`}
                label="Statut"
              />
            </div>
          </div>

          {isOuvertureDelai && (
          <div className="field">
            <div className="label">Ouverture Délai</div>
            <div className="value">
              <CheckBox
                value={state.bcR_OUV_DEL === 1}
                text=""
                onValueChanged={e => handleChange('bcR_OUV_DEL', e.value)}
                readOnly={isFieldReadonly('bcR_OUV_DEL')}
                className={isFieldRequired('bcR_OUV_DEL') ? 'required-field-checkbox' : ''}
              />
            </div>
          </div>)}
        </div>
        {isOuvertureDelaiOK && (
        <div className="column">
          <div className="field">
            <div className="value">
              <SelectBox
                dataSource={selectData.typecse}
                value={state.tyP_CSE}
                valueExpr="codval"
                displayExpr="libval"
                onValueChanged={e => handleChange('tyP_CSE', e.value)}
                readOnly={isFieldReadonly('tyP_CSE')}
                className={`${isFieldRequired('tyP_CSE') ? 'required-field' : ''} ${isFieldReadonly('tyP_CSE') ? 'disabled-field' : ''}`}
                label="Type Cause"
              />
            </div>
          </div>
         
          <div className="field">
            <div className="label">BTW</div>
            <div className="value">
              <CheckBox
                value={state.bcR_ENT_BTW === 1}
                text=""
                onValueChanged={e => handleChange('bcR_ENT_BTW', e.value ? 1 : 0)}
                readOnly={isFieldReadonly('bcR_ENT_BTW')}
                className={isFieldRequired('bcR_ENT_BTW') ? 'required-field-checkbox' : ''}
              />
            </div>
          </div>
        </div>
        )}
        {isOuvertureDelaiOK && (
        <div className="column">
          <div className="field">
            <div className="value">
              <SelectBox
                dataSource={causesByType}
                value={state.bcR_CSE_ID}
                valueExpr="csE_ID"
                displayExpr="liB_CSE"
                onValueChanged={e => handleChange('bcR_CSE_ID', e.value)}
                readOnly={isFieldReadonly('bcR_CSE_ID')}
                className={`${isFieldRequired('bcR_CSE_ID') ? 'required-field' : ''} ${isFieldReadonly('bcR_CSE_ID') ? 'disabled-field' : ''}`}
                label="Cause"
              />
            </div>
          </div>
           
          <div className="field">
            <div className="label">BTE</div>
            <div className="value">
              <CheckBox
                value={state.bcR_ENT_BTE === 1}
                text=""
                onValueChanged={e => handleChange('bcR_ENT_BTE', e.value ? 1 : 0)}
                readOnly={isFieldReadonly('bcR_ENT_BTE')}
                className={isFieldRequired('bcR_ENT_BTE') ? 'required-field-checkbox' : ''}
              />
            </div>
          </div>
        </div>
        )}
      </div>
   
      <div className="bottom-row">
        {isCauseRetardVisible && (
          <TextBox 
            className={`full-width-input ${isFieldRequired('bcR_CAU_RET') ? 'required-field' : ''}`}  
            value={state.bcR_CAU_RET || ""}
            onValueChanged={e => handleChange('bcR_CAU_RET', e.value)}
            label="Cause"
          />
        )}
        <TextBox
         
          className={`full-width-input ${isFieldRequired('bcR_TITRE') ? 'required-field' : ''}`} 
          value={state.bcR_TITRE || ""}
          onValueChanged={e => handleChange('bcR_TITRE', e.value)}
          label='Titre'
        />

        <TextArea
          label='Texte'
          className={`full-width-input ${isFieldRequired('bcR_TEXTE') ? 'required-field' : ''}`}  
          value={state.bcR_TEXTE || ""}
          onValueChanged={e => handleChange('bcR_TEXTE', e.value)}
        />
      </div>
      <div className="button-row"> 
        <Button onClick={() => onDel(state.bcR_ID || -1)} icon="trash" hint="Supprimer" />
        <Button onClick={() => onSave(state)} icon="save" hint="Enregistrer" />
        <Button onClick={onCancel} icon="clear" hint="Annuler" />
      </div>
    </React.Fragment>
  );
};

export default CompteRenduDetailPage;
