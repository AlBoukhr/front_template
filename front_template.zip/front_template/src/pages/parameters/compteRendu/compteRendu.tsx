import React, { useCallback, useEffect, useMemo, useState } from "react";
import { ComptesRendusService } from "../../../services/ComptesRendusService";
import { axiosInstance } from '../../../services/configaxios';
import { CompteRendu } from '../../../models/CompteRendu';
import SegaDataGrid from "../../../components/segadevextreme/datagrid";
import { ColumnDefinition } from "../../../components/interfaces";
import CompteRenduDetailPage from "./compteRenduDetail";

function CompteRenduPage() {
  const compteRenduService = useMemo(() => new ComptesRendusService(axiosInstance), []);
  const [listeComptesRendus, setListeComptesRendus] = useState<CompteRendu[] | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedCompteRendu, setSelectedCompteRendu] = useState<CompteRendu | null>(null);
  const [pageIndex, setPageIndex] = useState<number | undefined>();
  const [rowIndex, setRowIndex] = useState<number | undefined>();
  const rafraichirComptesRendus = useCallback(async () => {
    setIsLoading(true);
    try {
      const comptesRendus = await compteRenduService.getAll();
      setListeComptesRendus(comptesRendus);
    } catch (e) {
      console.error('Erreur lors du chargement des données', e);
    } finally {
      setIsLoading(false);
    }
  }, [compteRenduService]);

  useEffect(() => {
    rafraichirComptesRendus();
    setSelectedCompteRendu(createCompteRenduInstance());
  }, [rafraichirComptesRendus]);

  useEffect(() => {
    if (listeComptesRendus && listeComptesRendus.length > 0) {
      setSelectedCompteRendu(listeComptesRendus[0]);
    }
  }, [listeComptesRendus]);

  function createCompteRenduInstance() {
    return {
      bcR_ID: -1,
      bcR_NAT_LIE: "",
      bcR_TYP_MSG: "",
      bcR_STU_MSG: "",
      bcR_COD_MSG: "",
      bcR_TITRE: "",
      bcR_TEXTE: "",
      bcR_OFR_COM: "",
      bcR_CAU_RET: "",
      bcR_OUV_DEL: -1,
      bcR_CSE_ID: -1,
      bcR_ENT_BTE: -1,
      bcR_ENT_BTW: -1,
      bcR_TYP_MSG_LBL: "",
      bcR_STU_MSG_LBL: "",
      bcR_NAT_LIE_LBL: "",
      tyP_CSE: "",
      tyP_CSE_LIB: "",
      liB_CSE: "",
    } as unknown as CompteRendu;
  }

  const columnsDef: ColumnDefinition[] = [
    { visible: false, caption: 'ID', name: 'bcR_ID', required: true, typeField: 'text' },
    { visible: true, caption: 'Offre', name: 'bcR_OFR_COM', required: true, typeField: 'text' },
    { visible: true, caption: 'Nature Lien', name: 'bcR_NAT_LIE_LBL', editable: true, typeField: 'text' }, 
    { visible: true, caption: 'Type', name: 'bcR_TYP_MSG_LBL', editable: true, typeField: 'text' }, 
    { visible: true, caption: 'Titre', name: 'bcR_TITRE', required: true, typeField: 'text' }, 
    { visible: true, caption: 'Cause Retard', name: 'bcR_CAU_RET', editable: true, typeField: 'text' }, 
    { visible: true, caption: 'Code Message', name: 'bcR_COD_MSG', editable: true, typeField: 'text' },
    { visible: true, caption: 'Statut', name: 'bcR_STU_MSG_LBL', editable: false, typeField: 'text' },
    { visible: true, caption: 'Ouverture Délai', name: 'bcR_OUV_DEL', editable: false, typeField: 'checkbox' },
    { visible: true, caption: 'BTE', name: 'bcR_ENT_BTE', editable: false, typeField: 'checkbox' },
    { visible: true, caption: 'BTW', name: 'bcR_ENT_BTW', editable: false, typeField: 'checkbox' },
    { visible: true, caption: 'Type Cause', name: 'tyP_CSE_LIB', editable: true, typeField: 'text' },
    { visible: false, caption: 'Texte', name: 'bcR_TEXTE', editable: true, typeField: 'text' }
  ];

  const handleAdd = async () => {
    try {
      const newItem = createCompteRenduInstance();
      // listeComptesRendus?.push(newItem);

         setListeComptesRendus((prevListe) => {
        const updatedList = prevListe ? [...prevListe, newItem] : [newItem];
        return updatedList;
      }); 

      
    const newSelected = listeComptesRendus ? listeComptesRendus[(listeComptesRendus.length ?? 0) - 1] : null;
    setSelectedCompteRendu(newSelected);
      setPageIndex(Math.floor(((listeComptesRendus?.length ?? 0) - 1) / 10));  // page size  10
      setRowIndex((listeComptesRendus?.length ?? 0) - 1);


    } catch (error) {
      console.error('Erreur lors de la création', error)
      // Gérer l'erreur ici
    }
  };
 
  const handleDelete = async (id: number) => {
    try {
      await compteRenduService.remove('BCR_ID',id);
      rafraichirComptesRendus();
    } catch (error) {
      console.error('Erreur lors de la suppression', error);
    }
  };

  const handleClick = async (id: number) => {
    const compteRendu = listeComptesRendus?.find(cr => cr.bcR_ID === id);
    if (compteRendu) {
      setSelectedCompteRendu(compteRendu);
      console.info('Compte rendu actuel', compteRendu.bcR_TITRE);
    }
  };
  
  const handleSave = async (data: CompteRendu) => {
    try {
      if (data.bcR_ID === -1  || data.bcR_ID === undefined) {
        await compteRenduService.create(data);
      } else {
        await compteRenduService.updateByItem( data);
      }
      setSelectedCompteRendu(null);
      rafraichirComptesRendus();
    } catch (erreur) {
      console.error("Erreur lors de la sauvegarde du compte-rendu", erreur);
    }
  };
    
  function handelCancel(): void {
    setPageIndex(undefined);
    setRowIndex(undefined);
    rafraichirComptesRendus();
  }

  return (
    <React.Fragment>
      {/* <h2 className={'content-block'}>Comptes Rendus</h2> */}
      <div className={'content-block dx-card responsive-paddings'}>
        <SegaDataGrid  
          idName="bcR_ID"
          dataSource={listeComptesRendus}
          ColumnDefinition={columnsDef}
          canEdit={true}
          canAdd={true}
          onAdd={handleAdd}
          onRowClick={(id) => handleClick(id)}
          type={createCompteRenduInstance}
          pageIndex={pageIndex}
          rowIndex={rowIndex}
        />
      </div>
      <div className={'content-block dx-card responsive-paddings'}>
        {selectedCompteRendu && (
          <CompteRenduDetailPage 
          onDel={handleDelete}
            compteRendu={selectedCompteRendu}
            onSave={handleSave}
            onCancel={handelCancel}
          />
        )}
        {isLoading && <div>Chargement en cours...</div>}
      </div>
    </React.Fragment>
  );
}

export default CompteRenduPage;
