import { withNavigationWatcher } from './contexts/navigation';
import CompteRenduPage from './pages/parameters/compteRendu/compteRendu';
import FacturationPage from './pages/parameters/facturation/facturation';
import NiveauxEscaladePage from './pages/parameters/niveauxescalade/niveauxescalade';
import RetardPage from './pages/parameters/retard/retard';
import ContactOperateurPage from './pages/parameters/contactoperateur/contactoperateur';
import CodeTransformationPage from './pages/parameters/codetransformation/codetransformation'; 
import GdaPage from './pages/parameters/gda/gda';
import DspPage from './pages/parameters/dsp/dsp';
import EnvoiCommandePage from './pages/parameters/envoicommande/envoicommande';
import EquipementsPage from './pages/parameters/equipement/equipement';
import RipPage from './pages/parameters/rip/rip'; 
import AdminParamPage from './pages/parameters/autresparams/autresparams'
import ModificationAdminPage from './pages/parameters/modificationadmin/modificationadmin';
import Dashboard from './pages/dashboard/dashboard';  
import CommandeDetailsPage from './pages/commande/commandedetailspage';
import CommandesPage from './pages/commande/recherche/searchcommandes';


const routes = [
    // {
    //     path: '/tasks',
    //     element: TasksPage
    // },
    // {
    //     path: '/profile',
    //     element: ProfilePage
    // },
    {
        path: '/dashboard',
        element: Dashboard
    },
    {
      element: CommandesPage  , // Ajoutez le nouveau chemin
      path: '/commande/recherche',
     
    },
    {
      element: CommandeDetailsPage  , // Ajoutez le nouveau chemin
      path: '/commande',
     
    },

    {
      
      element: CompteRenduPage,
      
      path:'/parameters/compteRendu', 
    },
    {
       
      element: FacturationPage,
      
      path:'/parameters/facturation', 
    },
     
    {
     
      element: NiveauxEscaladePage,
     
       path:'/parameters/niveauxescalade',
     
    },  
    {
     
      element: RetardPage,
       
      path:'/parameters/retard',
     
    },
    {
        
        element: ContactOperateurPage,
       
        path:'/parameters/contactoperateur',
     
      },
      {
        
        element: CodeTransformationPage,
         
        path:'/parameters/codetransformation',
     
      },
      {
        
        element: AdminParamPage, 
        path:'/parameters/autresparams',
     
      },
      {
        
        element: GdaPage, 
        path:'/parameters/gda',
       
          
      },
      {
        
        element: DspPage, 
        path:'/parameters/dsp',
       
      },
      {
      
        element: EnvoiCommandePage, 
        path:'/parameters/envoicommande',
       
           
      } ,
      {
        
        element: EquipementsPage, 
        path:'/parameters/equipement',
       
         
    },
    {
       
      element: RipPage, 
      path:'/parameters/rip',
     
      }, 
      {
       
        element: ModificationAdminPage, 
        path:'/parameters/modificationadmin',
       
      }
];

export default routes.map(route => {
    return {
        ...route,
        element: withNavigationWatcher(route.element, route.path)
    };
});
