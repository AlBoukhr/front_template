export interface CodeTransformation {
  ctV_ID?: number | null;
  cmD_ORD_COD?: string | null;
  traN_VG_COD?: string | null;
  traN_VG_CMT?: string | null;
  cmD_ORD_LBL?: string | null;
  traN_VG_LBL?: string | null;
}
