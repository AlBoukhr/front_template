export interface Dsp {
  doP_ID?: number | null;
  codE_OPE?: string | null;
  dsP_NOM?: string | null;
  dsP_ID?: number | null;
  liB_OPE?: string | null;
  operateur?: string | null;
}
export interface DspFilter {
  
  CODE_OPE?: string | null;
  
}


