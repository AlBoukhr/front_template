export type Valeur = {
    cmtval?: string;
    codval?: string;
    libval?: string;
    lstvaL_ID?: string;
    vaL_ID?: number;
};
export type GetValeursQueryParams = {
    P_LSTVAL_ID?: string;
};
