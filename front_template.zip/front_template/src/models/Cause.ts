export interface Cause { 
  csE_ID?: number | null;
liB_CSE?: string | null;
tycse?: string | null;
}
