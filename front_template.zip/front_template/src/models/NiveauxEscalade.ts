export interface NiveauxEscalade {
  bmA_ID?: number | null;
  bmA_OFR_COM?: string | null;
  bmA_NIV?: string | null;
  bmA_NAT_LIE?: string | null;
  bmA_TITRE?: string | null;
  bmA_OBJET?: string | null;
  bmA_TEXTE?: string | null;
  bmA_ADR_MAIL?: string | null;
  bmA_ADR_CCI?: string | null;
  scM_ID?: number | null;
}
