export interface RipInteropVersion {
  riV_ID?: number | null;
  codE_OI?: string | null;
  versioN_INTEROP?: string | null;
}
