export interface AdminParam {
  prM_ID?: number | null;
  prM_KEY?: string | null;
  prM_LBL?: string | null;
  prM_VAL?: string | null;
}
