export interface ContactOperateur {
  coP_ID?: number | null;
  cmD_ORD_COD?: string | null;
  cmD_ORD_LBL?: string | null;
  enT_ID?: number | null;
  coP_FULLNAME?: string | null;
  coP_PRENOM?: string | null;
  coP_NOM?: string | null;
  coP_NUMTEL?: string | null;
}
