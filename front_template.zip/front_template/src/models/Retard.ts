export interface Retard {
  reT_ID?: number | null;
  reT_OFR_COM?: string | null;
  reT_CHA_NOM?: string | null;
  reT_NAT_LIE?: string | null;
  reT_TYP_CMD?: string | null;
  reT_DELAI?: number | null;
  reT_CHA_LBL?: string | null;
  ofR_COM_LBL?: string | null;
  cmD_TYP?: string | null;
  naT_LIE_LBL?: string | null;
}
