export interface VersionsFluxMediation {
  versions?: string | null;
}
