export interface Equipement {
  liE_MSI?: string | null;
  equipement?: string | null;
  iS_EQUIVIDE?: number | null;
  ofR_COM?: string | null;
  cmS_STU?: string | null;
  ofR_COM_COD?: string | null;
  cmS_ID?: number | null;
  cmS_STU_LIBELLE?: string | null;
  clE_EQP?: string | null;
  datE_MAJ?: string | null;
  resulT_MAJ?: string | null;
}
