export interface Gda {
  aaG_ID?: number | null;
  codofr?: string | null;
  typlie?: string | null;
  operator?: string | null;
  gdA_ID?: number | null;
  entite?: string | null;
  gdA_NOM?: string | null;
  operatorlib?: string | null;
}
