export interface Rip {
  riP_ID?: number | null;
  codE_OI?: string | null;
  codE_PROD?: string | null;
  lab?: string | null;
  controle?: string | null;
}
