export interface EnvoiCommande {
  bdS_ID?: number | null;
  bdS_TYP?: string | null;
  codE_OPE?: string | null;
  bdS_ADR_MAIL?: string | null;
  bdS_ADR_CCI?: string | null;
  bdS_TITRE?: string | null;
  bdS_OBJET?: string | null;
  bdS_TEXT?: string | null;
  ofF_COMM?: string | null;
  naT_LIE?: string | null;
  bdS_ADR_MAIL_EXP?: string | null;
  liB_OPE?: string | null;
  liB_TYP?: string | null;
  liB_LIE?: string | null;
}

export interface EnvoiCommandeFilter {
   
  OFF_COMM?: string | null;
   
}

