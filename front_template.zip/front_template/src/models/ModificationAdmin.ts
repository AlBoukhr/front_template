export interface ModificationAdmin {
  cmS_ID?: number | null;
  cmS_NOM?: string | null;
  cmS_STU?: string | null;
  neW_CODEOFFRE?: string | null;
  cmD_OFR?: string | null;
}
