 
export interface OperateurImmeuble {
    moD_OPR_ID?: number | null; 
    moD_OPR_COD?: string | null; 
    moD_OPR_LIB?: string | null;
  }
   
  
  
  