export interface Facturation {
  faC_CODE_OI?: string | null;
  faC_DAT_CRE?: string | null;
  faC_DAT_MDF?: string | null;
  faC_DFT?: number | null;
  faC_ID?: number | null;
  faC_LGI_CRE?: string | null;
  faC_LGI_MDF?: string | null;
  faC_NEW?: number | null;
  faC_NUM?: string | null;
  faC_OFR?: string | null;
  faC_PRE?: number | null;
}
