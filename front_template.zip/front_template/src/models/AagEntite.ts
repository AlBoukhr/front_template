export interface AagEntite {
  codval?: string | null;
  libval?: string | null;
}
