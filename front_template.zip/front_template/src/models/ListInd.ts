export interface ListInd{
  enT_ID?:	number
  codfon?:	  string | null;
  soC_ID?:	number
  noment?:	  string | null;
  fullname?:	  string | null;
  fullvoi	?: string | null;
  numvoient	?: string | null;
  cmpvoient	?: string | null;
  typvoient	?: string | null;
  nomvoient	?: string | null;
  nomvoi	?: string | null;
  cmpadr	?: string | null;
  codptlent	?: string | null;
  coD_INSEE	?: string | null;
  bopent	?: string | null;
  cedent	?: string | null;
  entpaR_ID?:number
  civprs	?: string | null;
  pnmprs	?: string | null;
  emaprs	?: string | null;
  nomcmn	?: string | null;
  nomsocapp	?: string | null;
  nomusrmdf	?: string | null;
  datmdf	?: string | null;
  nomenT_SEARCH	?: string | null;
  pnmprS_SEARCH	?: string | null;
  nomsocapsearch	?: string | null;
  nomcmN_SEARCH	?: string | null;
  paycod	?: string | null;
  voI_ID?:	number
  natind	?: string | null;
  }