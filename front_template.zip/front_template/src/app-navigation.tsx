export const navigation = [
  {
    text: 'Acceuil',
    path: '/home',
    icon: 'home'
  },
  {
    text: 'Dashboard',
    path: '/dashboard',
    icon: 'dataarea'
  },
  {
    text: 'Détails',
    path: '/commande',
    icon: 'activefolder'
  },
  {
    text: 'Commades',
    path: '/commande/recherche',
    icon: 'activefolder'
  },
  {
    text: 'Administration',
    icon: 'folder',
    items: [
      // {
      //   text: 'Profile',
      //   path: '/profile'
      // },
      // {
      //   text: 'Tasks',
      //   path: '/tasks'
      // },
      {
        
        text: 'Comptes Rendus',
        
        path:'/parameters/compteRendu', 
      },
      {
         
        text: 'Facturations',
        
        path:'/parameters/facturation', 
      },
       
      {
       
        text: 'Niveaux Escalades',
       
         path:'/parameters/niveauxescalade',
       
      },  
      {
       
        text: 'Retards',
         
        path:'/parameters/retard',
       
      },
      {
          
          text: 'Contacts Opérateurs',
         
          path:'/parameters/contactoperateur',
       
        },
        {
          
          text: 'Codes Transformations',
           
          path:'/parameters/codetransformation',
       
        },
        {
          
          text: 'Autres Paramètres...', 
          path:'/parameters/autresparams',
       
        },
        {
          
          text: 'GDA', 
          path:'/parameters/gda',
         
            
        },
        {
          
          text: 'DSP', 
          path:'/parameters/dsp',
         
        },
        {
        
          text: 'Envoi Commandes', 
          path:'/parameters/envoicommande',
         
             
        } ,
        {
          
          text: 'Equipements', 
          path:'/parameters/equipement',
         
           
      },
      
        {
           
          text: 'RIP', 
          path:'/parameters/rip',
         
        },
        {
         
          text: 'Modification Admin', 
          path:'/parameters/modificationadmin',
         
        }
    ]
  }
  ];
